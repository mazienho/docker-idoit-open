--
-- i-doit system dump rev 1.4.7
-- created with: mysqldump  Ver 10.13 Distrib 5.6.19, for osx10.7 (x86_64)
-- at: Di 14 Okt 2014 16:19:21 CEST
--
-- For manual installations you need to insert your mandator connection info into
-- table isys_mandator in order to connect to a mandator.
--
-- For example: (idoit, idoit = user, pass; idoit_data = mandator db)
--
-- INSERT INTO isys_mandator 
--      VALUES(1, 'Mandator (DE)', 
--		'Mandator (DE)', 'cache_mandator', 'default', 'localhost', 3306, 'idoit_data', 
--       'idoit', 'idoit', NULL, 1, 1);
--

SET FOREIGN_KEY_CHECKS=0;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_const_get` (
  `isys_const_get__id` int(11) NOT NULL AUTO_INCREMENT,
  `isys_const_get__title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `isys_const_get__description` text COLLATE utf8_unicode_ci,
  `isys_const_get__value` text COLLATE utf8_unicode_ci,
  `isys_const_get__quoted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`isys_const_get__id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `isys_const_get` VALUES (1,'C__CMDB__GET__VIEWMODE',NULL,'viewMode',1),(2,'C__CMDB__GET__TREEMODE',NULL,'tvMode',1),(3,'C__CMDB__GET__OBJECTGROUP',NULL,'objGroupID',1),(4,'C__CMDB__GET__OBJECTTYPE',NULL,'objTypeID',1),(5,'C__CMDB__GET__OBJECT',NULL,'objID',1),(6,'C__CMDB__GET__CATTYPE',NULL,'catTypeID',1),(7,'C__CMDB__GET__CATG',NULL,'catgID',1),(8,'C__CMDB__GET__CATS',NULL,'catsID',1),(9,'C__CMDB__GET__CATD',NULL,'catdID',1),(10,'C__CMDB__GET__POPUP',NULL,'popup',1),(11,'C__CMDB__GET__CAT_MENU_SELECTION',NULL,'catMenuSelection',1),(12,'C__CMDB__GET__EDITMODE',NULL,'editMode',1),(13,'C__CMDB__GET__CAT_LIST_VIEW',NULL,'catListView',1),(14,'C__CMDB__GET__CATLEVEL',NULL,'cateID',1),(15,'C__CMDB__GET__CATLEVEL_1',NULL,'cat1ID',1),(16,'C__CMDB__GET__CATLEVEL_2',NULL,'cat2ID',1),(17,'C__CMDB__GET__CATLEVEL_3',NULL,'cat3ID',1),(18,'C__CMDB__GET__CATLEVEL_4',NULL,'cat4ID',1),(19,'C__CMDB__GET__CATLEVEL_5',NULL,'cat5ID',1),(20,'C__CMDB__GET__CATLEVEL_MAX',NULL,'5',0),(21,'C__GET__FILE_MANAGER',NULL,'file_manager',1),(22,'C__GET__MODULE_ID',NULL,'moduleID',1),(23,'C__GET__NAVMODE',NULL,'navMode',1),(24,'C__GET__FILE_NAME',NULL,'file_name',1),(25,'C__GET__AJAX_REQUEST',NULL,'ajax_request_func',1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_const_system` (
  `isys_const_system__id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isys_const_system__const` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `isys_const_system__value` int(10) unsigned DEFAULT '1',
  `isys_const_system__description` text COLLATE utf8_unicode_ci,
  `isys_const_system__store_id` int(10) unsigned NOT NULL DEFAULT '0',
  `isys_const_system__doku_cross_reference` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`isys_const_system__id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `isys_const_system` VALUES (1,'C__NAVBAR_BUTTON__DELETE',5,'element of navbar',0,NULL),(3,'C__NAVMODE__NEW',1,'Navigationsmodus \"Neu\"',0,NULL),(4,'C__NAVMODE__EDIT',2,'Navigationsmodus \"Bearbeiten\"',0,NULL),(5,'C__NAVMODE__DUPLICATE',3,'Navigationsmodus \"Duplizieren\"',0,NULL),(7,'C__NAVMODE__BACK',7,'Navigationsmodus \"Zurueck\"',0,NULL),(8,'C__NAVMODE__FORWARD',9,'Navigationsmodus \"Vorwaerts\"',0,NULL),(9,'C__NAVMODE__SAVE',10,'Navigationsmodus \"Speichern\"',0,NULL),(10,'C__NAVMODE__RESET',13,'Navigationsmodus \"Zuruecksetzen\"',0,NULL),(11,'C__NAVMODE__CANCEL',14,'Navigationsmodus \"Abbrechen\"',0,NULL),(12,'C__MAX_COUNT__GET_HISTORY',5,'Maximale Eintraege in der internen Sitzungs-URL-History',0,NULL),(13,'C__CMDB_VIEWMODE__OBJECT',0,'CMDB Baum-Anzeigemodus \"Objektsicht\"',0,NULL),(14,'C__CMDB_VIEWMODE__LOCATION',0,'CMDB Baum-Anzeigemodus \"Lokationssicht\"',0,NULL),(15,'C__CMDB_TREEMODE__GCAT',1,'CMDB Baum-Datenmodus \"Globale Kategorie\"',0,NULL),(16,'C__CMDB_TREEMODE__OBJTYPE',1,'CMDB Baum-Datenmodus \"Objekttypen\"',0,NULL),(18,'C__F_POPUP__LOCATION',1,'Location-Browser',0,NULL),(19,'C__F_POPUP__DATETIME',2,'Calendar',0,NULL),(20,'C__F_POPUP__CONTACT',3,'Contact-Browser',0,NULL),(21,'C__F_POPUP__PICTURE',4,'Picture-Browser',0,NULL),(22,'C__CMDB__CATG',1,'Identifier for a global category',0,NULL),(23,'C__CMDB__CATS',2,'Identifier for a specific category',0,NULL),(24,'C__CMDB__CATD',3,'Identifier for a dynamic category',0,NULL),(25,'C__RECORD_PROPERTY__NOT_EDITABLE',1,'if value is add to __property field - the related record is NOT editable by the user',0,NULL),(26,'C__RECORD_PROPERTY__NOT_DELETABLE',2,NULL,0,NULL),(27,'C__RECORD_PROPERTY__NOT_SEARCHABLE',4,NULL,0,NULL),(28,'C__RECORD_PROPERTY__NOT_SELECTABLE',8,NULL,0,NULL),(29,'C__RECORD_PROPERTY__NOT_SHOW_IN_LIST',16,NULL,0,NULL),(38,'C__NAVMODE__UP',8,'10',0,NULL),(40,'C__NAVBAR_BUTTON__NEW',1,'element of navbar',0,NULL),(41,'C__NAVBAR_BUTTON__EDIT',2,'element of navbar',0,NULL),(43,'C__NAVBAR_BUTTON__DUPLICATE',3,'element of navbar',0,NULL),(44,'C__NAVBAR_BUTTON__BLANK',11,'element of navbar',0,NULL),(45,'C__NAVBAR_BUTTON__BACK',7,'element of navbar',0,NULL),(46,'C__NAVBAR_BUTTON__UP',8,'element of navbar',0,NULL),(47,'C__NAVBAR_BUTTON__FORWARD',9,'element of navbar',0,NULL),(48,'C__RECORD_STATUS__BIRTH',1,'stored to the __status field by insert a new record,^before switching to the Editmode to verify th data',0,NULL),(49,'C__RECORD_STATUS__NORMAL',2,'if the Data is valid and the \"SAVE\" Button is pressed the Record becomes the __status ISYS_C__RECORD_STATUS__NORMAL',0,NULL),(50,'C__RECORD_STATUS__ARCHIVED',3,'if the Record is deleted, the __STATUS is set to ISYS_REC_STATUS_ARCHIEVED a sysop can change the __STATUS for CMDB OBJ from ISYS_REC_STATUS_ARCHIEVED to C__RECORD_STATUS__NORMAL (reactivate)',0,NULL),(51,'C__RECORD_STATUS__DELETED',4,'or to C__RECORD_STATUS__DELETED',0,NULL),(54,'C__EDITMODE__ON',1,NULL,0,NULL),(55,'C__EDITMODE__OFF',0,NULL,0,NULL),(56,'C__NAVBAR_BUTTON__RECYCLE',12,NULL,0,NULL),(57,'C__CAT_LISTVIEW__OFF',0,NULL,0,NULL),(58,'C__CAT_LISTVIEW__ON',1,NULL,0,NULL),(59,'C__RECORD_STATUS__PURGE',5,'u never find a record with the __status \r\r\nC__RECORD_STATUS__PURGE because\r\r\nthis constant is used to mark for phy. delete.',0,NULL),(60,'C__MPTT__ACTION_BEGIN',1,NULL,0,NULL),(61,'C__MPTT__ACTION_END',6,NULL,0,NULL),(62,'C__MPTT__ACTION_ADD',2,NULL,0,NULL),(63,'C__MPTT__ACTION_DELETE',3,NULL,0,NULL),(64,'C__MPTT__ACTION_MOVE',4,NULL,0,NULL),(65,'C__MPTT__ROOT_NODE',1,NULL,0,NULL),(66,'C__MPTT__ACTION_UPDATE',5,'MPTT Aktion fuer Update (Actionstack)',0,NULL),(67,'C__CHECK_PERMISSION__EDIT',1,'const for permission check in complex categories like power obj etc.',0,NULL),(68,'C__CHECK_PERMISSION__DELETE',2,'const for permission check in complex categories like power obj etc.',0,NULL),(69,'C__CHECK_PERMISSION__DUPLICATE',3,'const for permission check in complex categories like power obj etc.',0,NULL),(70,'C__CHECK_PERMISSION__APPEND',4,'const for permission check in complex categories like power obj etc.',0,NULL),(71,'C__CHECK_PERMISSION__RECYCLE',5,'const for permission check in complex categories like power obj etc.',0,NULL),(72,'C__NAVMODE__ARCHIVE',4,NULL,0,NULL),(73,'C__NAVBAR_BUTTON__ARCHIVE',4,NULL,0,NULL),(74,'C__NAVMODE__PURGE',6,NULL,0,NULL),(75,'C__NAVBAR_BUTTON__PURGE',6,NULL,0,NULL),(76,'C__NAVMODE__RECYCLE',12,NULL,0,NULL),(77,'C__LINK__OBJECT',1,'Constant for building a link to cmdb object',1,'used in class isys_component_link_cmdb_generic'),(78,'C__LINK__POBJ_FEMALE_SOCKET',1,'Constant for building a link to cmdb power-object, subcategory female socket',1,'used in class isys_component_link_cmdb_generic'),(79,'C__LINK__POBJ_MALE_PLUG',1,'Constant for building a link to cmdb power-object, subcategory male plug',1,'used in class isys_component_link_cmdb_generic'),(80,'C__LINK__CATG',1,'Constant for building a link to cmdb catg list-element',1,'used in class isys_component_link_cmdb_generic'),(81,'C__CMDB__CATEGORY__POBJ_MALE_PLUG',0,'used for the pobj_brower to show \r\nthe required plugType',0,'used in \r\nclass isys_popup_browser_pobj \r\nand\r\nisys_cmdb_dao_category_s_pobj'),(82,'C__CMDB__CATEGORY__POBJ_FEMALE_SOCKET',1,'used for the pobj_brower to show \r\nthe required plugType',0,'used in \r\nclass isys_popup_browser_pobj \r\nand\r\nisys_cmdb_dao_category_s_pobj'),(83,'C__NAVMODE__PRINT',15,'Drucken',0,NULL),(84,'C__NAVBAR_BUTTON__PRINT',15,'Print',0,NULL),(85,'C__NAVMODE__DELETE',5,'',0,NULL),(86,'C__NAVMODE__JS_ACTION',16,'Ueber JS wurde ein Submit ausgefuehrt, \r\nAenderungsdaten werden im __HIDDEN Field (array) uebergeben.\r\nWird erstmals fuer den Contactbrowser verwendet.',0,'popup.js, suche nach C__NAVMODE__JS_ACTION im code'),(87,'C__RECORD_STATUS__TEMPLATE',6,'',0,NULL),(88,'C__NAVBAR_BUTTON__COMPLETE',20,'Complete one or more tasks',0,NULL),(89,'C__NAVMODE__COMPLETE',20,'Navigationsmodus \"Abschließen\"',0,NULL),(90,'C__RECORD_STATUS__MASS_CHANGES_TEMPLATE',7,'New status for mass changes templates',0,NULL),(91,'C__NAVBAR_BUTTON__SAVE',21,'element of navbar',0,NULL),(92,'C__NAVBAR_BUTTON__CANCEL',22,'element of navbar',0,NULL),(93,'C__NAVBAR_BUTTON__QUICK_PURGE',60,'element of navbar',0,NULL),(94,'C__NAVMODE__QUICK_PURGE',60,NULL,0,NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_db_init` (
  `isys_db_init__id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isys_db_init__key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `isys_db_init__value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`isys_db_init__id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `isys_db_init` VALUES (1,'title','i-doit 1.4.7'),(2,'revision','18307'),(3,'version','1.4.7'),(4,'type','open');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_language` (
  `isys_language__id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isys_language__title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_language__short` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `isys_language__available` int(1) NOT NULL,
  `isys_language__const` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_language__sort` int(10) NOT NULL,
  PRIMARY KEY (`isys_language__id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `isys_language` VALUES (1,'All','all',0,'ISYS_LANGUAGE_ALL',0),(2,'Deutsch','de',1,'ISYS_LANGUAGE_GERMAN',1),(3,'English','en',1,'ISYS_LANGUAGE_ENGLISH',2),(4,'Portuguese','pt',1,'ISYS_LANGUAGE_PORTUGUESE',3);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_licence` (
  `isys_licence__id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isys_licence__isys_mandator__id` int(10) unsigned DEFAULT NULL,
  `isys_licence__type` int(10) NOT NULL,
  `isys_licence__key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_licence__data` text COLLATE utf8_unicode_ci,
  `isys_licence__expires` int(10) DEFAULT NULL,
  `isys_licence__datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`isys_licence__id`),
  KEY `isys_licence__isys_mandator__id` (`isys_licence__isys_mandator__id`),
  CONSTRAINT `isys_licence_ibfk_1` FOREIGN KEY (`isys_licence__isys_mandator__id`) REFERENCES `isys_mandator` (`isys_mandator__id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_mandator` (
  `isys_mandator__id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isys_mandator__title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_mandator__description` text COLLATE utf8_unicode_ci,
  `isys_mandator__dir_cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_mandator__dir_tpl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_mandator__db_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_mandator__db_port` int(11) DEFAULT '3306',
  `isys_mandator__db_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_mandator__db_user` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `isys_mandator__db_pass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_mandator__apikey` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_mandator__sort` int(10) unsigned DEFAULT NULL,
  `isys_mandator__active` int(10) unsigned DEFAULT '1',
  PRIMARY KEY (`isys_mandator__id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_registry` (
  `isys_registry__id` int(11) NOT NULL AUTO_INCREMENT,
  `isys_registry__parentid` int(11) DEFAULT NULL,
  `isys_registry__key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_registry__value` text COLLATE utf8_unicode_ci,
  `isys_registry__deletable` int(10) unsigned DEFAULT NULL,
  `isys_registry__editable` int(10) unsigned DEFAULT '1',
  PRIMARY KEY (`isys_registry__id`),
  KEY `isys_registry_parentid` (`isys_registry__parentid`,`isys_registry__key`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `isys_registry` VALUES (1,0,'[Root]',NULL,0,1),(24,1,'System','',0,1),(25,1,'Idoit','',0,1),(26,24,'Directories','',0,1),(27,24,'User','',0,1),(28,24,'Libraries','',0,1),(29,27,'Session','',0,1),(30,27,'General','',0,1),(31,28,'MySQL','',0,1),(32,28,'LDAP','',0,1),(33,28,'Smarty','',0,1),(34,25,'Constants','',0,1),(35,25,'Modules','',0,1),(36,29,'time_expirationInterval','1800',0,1),(37,29,'int_guestID','1',0,1),(38,31,'str_transactionIsolationLevel','c_isolation_level_repeatable_read',0,1),(39,26,'theme','[DIR_WWW]src/themes/default/',0,1),(40,26,'images','[DIR_WWW]images/',0,1),(41,26,'tools','[DIR_WWW]src/tools/',0,1),(42,26,'temp','[DIR_BASE]temp/',0,1),(43,26,'class','[DIR_BASE]src/classes/',0,1),(44,26,'smarty','[DIR_BASE]src/themes/default/smarty/',0,1),(45,26,'css_abs','[DIR_BASE]src/themes/default/css/',0,1),(46,26,'js_abs','[DIR_BASE]src/tools/js/',0,1),(47,26,'utils','[DIR_BASE]src/utils/',0,1),(48,32,'int_connectionTimeOut','10',0,1),(49,33,'str_debuggingControl','URL',0,1),(50,33,'bool_compileCheck','false',0,1),(51,33,'bool_caching','true',0,1),(52,33,'bool_forceCompile','false',0,1),(53,33,'str_leftDelimiter','[{',0,1),(54,33,'str_rightDelimiter','}]',0,1),(55,33,'str_functionTag','isys',0,1),(56,33,'str_blockTag','isys_group',0,1),(57,25,'General','',0,1),(58,57,'Popup','',0,1),(59,58,'int_defaultWidth','500',0,1),(60,58,'int_defaultHeight','500',0,1),(61,58,'str_varName','g_isys_popup',0,1),(62,58,'str_windowName','isysPopup',0,1),(63,24,'General','',0,1),(64,63,'str_registryRoot','[Root]',0,1),(65,63,'str_registryKeyFilter','/^[a-zA-Z0-9._-]+$/i',0,1),(75,25,'i18n','',0,1),(76,75,'const_defaultLanguage','ISYS_LANGUAGE_ENGLISH',0,1),(77,35,'CMDB','',0,1),(78,35,'System','',0,1),(80,34,'int_pageLimit','25',0,1),(81,57,'Quicksave','0',0,0),(82,81,'b_showQuickSaveButton','1',0,1),(83,27,'Workflow','',0,0),(84,83,'int_mytask_entries','10',0,1),(85,57,'b_showLoadingWait','0',0,1),(86,83,'int_notify','15',0,1),(87,34,'SYSID__READONLY','1',0,1),(88,34,'RACK_GUI_DESCENDING','1',0,1),(89,34,'INFOBOX__LENGTH','150',0,1),(90,34,'INFOBOX__DATEFORMAT','d.m.Y H:i :',0,1),(91,34,'LOCK__TIMEOUT','120',0,1),(92,34,'LOCK__DATASETS','1',0,1),(93,34,'OBJECT_DRAGNDROP','1',0,1),(94,34,'H_INVENTORY__LOGBOOK_ACTIVE','0',0,1),(95,34,'b_always_display_full_lists','0',0,1),(96,NULL,'OCS__APPLICATION_ASSIGNMENT','1',0,1),(97,34,'C__OBJTYPE__SORTING','1',0,1),(98,34,'C__CMDB__SANITIZING','1',0,1),(99,34,'TEMPLATE__COLORS','1',0,1),(100,34,'TEMPLATE__COLOR_VALUE','#CC0000',0,1),(101,34,'TEMPLATE__STATUS','0',0,1),(102,34,'TEMPLATE__SHOW_ASSIGNMENTS','1',0,1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_report` (
  `isys_report__id` int(32) NOT NULL AUTO_INCREMENT,
  `isys_report__title` varchar(255) NOT NULL,
  `isys_report__description` text NOT NULL,
  `isys_report__query` text NOT NULL,
  `isys_report__query_row` text NOT NULL,
  `isys_report__mandator` int(10) DEFAULT NULL,
  `isys_report__user` int(10) DEFAULT NULL,
  `isys_report__datetime` datetime NOT NULL,
  `isys_report__last_edited` datetime NOT NULL,
  `isys_report__type` char(1) NOT NULL,
  `isys_report__user_specific` tinyint(1) NOT NULL DEFAULT '0',
  `isys_report__querybuilder_data` text,
  `isys_report__isys_report_category__id` int(10) unsigned DEFAULT NULL,
  `isys_report__empty_values` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`isys_report__id`),
  KEY `isys_report__isys_report_category__id` (`isys_report__isys_report_category__id`),
  CONSTRAINT `isys_report__isys_report_category__id` FOREIGN KEY (`isys_report__isys_report_category__id`) REFERENCES `isys_report_category` (`isys_report_category__id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_report_category` (
  `isys_report_category__id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `isys_report_category__title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_report_category__const` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isys_report_category__description` text COLLATE utf8_unicode_ci,
  `isys_report_category__property` int(10) unsigned DEFAULT NULL,
  `isys_report_category__sort` int(10) unsigned DEFAULT NULL,
  `isys_report_category__status` int(10) unsigned NOT NULL,
  PRIMARY KEY (`isys_report_category__id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `isys_report_category` VALUES (1,'Global',NULL,NULL,NULL,0,2);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isys_settings` (
  `isys_settings__key` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `isys_settings__value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`isys_settings__key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `isys_settings` VALUES ('auth.active','1'),('cmdb.connector.suffix-schema','[\"##INPUT## - OUT\",\"- ##INPUT##\",\"(*) ##INPUT##\"]'),('cmdb.object-browser.max-objects','1500'),('cmdb.unique.hostname',''),('cmdb.unique.ip-address',''),('cmdb.unique.layer-2-net','0'),('cmdb.unique.object-title',''),('email.template.maintenance','Your maintenance contract: %s timed out.\n\n<strong>Contract information</strong>:\nStart: %s\nEnd: %s\nSupport-Url: %s\nContract-Number: %s\nCustomer-Number: %s'),('gui.forum-link','0'),('gui.wiki-url',''),('gui.wysiwyg','1'),('ldap.debug','1'),('ldap.default-group',''),('proxy.active','0'),('proxy.host',''),('proxy.password','password'),('proxy.port','8080'),('proxy.username','user'),('reports.browser-url','http://reports-ng.i-doit.org/'),('session.sso.active','0'),('session.sso.language','de'),('session.sso.mandator-id',''),('session.time','600'),('system.devmode','0'),('system.dir.file-upload','upload/files/'),('system.dir.image-upload','upload/images/'),('system.email.from','info@i-doit.de'),('system.email.name','i-doit'),('system.email.port','25'),('system.email.smtp-host',''),('system.email.subject-prefix',''),('system.show-proc-time','0'),('system.timezone','Europe/Berlin'),('tts.rt.queues','');

DELETE FROM isys_language WHERE isys_language__short NOT IN('en', 'all');
