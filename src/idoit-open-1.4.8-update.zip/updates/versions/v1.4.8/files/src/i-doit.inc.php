<?php
/**
 * i-doit
 *
 * i-doit Starter
 *
 * @package     i-doit
 * @subpackage  General
 * @author      i-doit-team
 * @version     0.9
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
try
{
	global $g_comp_registry, $g_comp_template, $g_ajax_calls, $g_dirs, $g_comp_database, $g_config;

	// Set default form-action.
	$_SERVER['QUERY_STRING'] = isys_glob_url_remove($_SERVER['QUERY_STRING'], C__GET__AJAX_CALL);

	// Assign current query string for ajax-submits to the right URL.
	$l_gets = $_GET;
	unset($l_gets[C__GET__AJAX_CALL], $l_gets[C__GET__AJAX]);

	$g_comp_template
		->assign('formAdditionalAction', 'action="?' . htmlentities($_SERVER['QUERY_STRING']) . '"')
		->assign('query_string', isys_glob_build_url((isys_glob_http_build_query($l_gets))))
		// Ajax calls enabled?
		->assign('ajax_calls', $g_ajax_calls)
		->assign('html_encoding', $g_config['html-encoding'])
		// Assign session reference.
		->assignByRef('session', $g_comp_session)
		// Assign existent viewmode to define, which GUI sections to show and which to hide.
		->assign('viewMode_mainNavi', isys_glob_get_param('viewMode_mainNavi'))
		// Assign constants, which are used in all templates.
		->assign('C__NAVMODE__SAVE', C__NAVMODE__SAVE)
		->assign('C__NAVMODE__CANCEL', C__NAVMODE__CANCEL)
		// Activate loading window (if set in registry).
		->assign('gLoadingPleaseWait', _L('LC__UNIVERSAL__LOADING'));

	$l_tmp = $g_comp_registry->{'[Root]/Idoit/General/b_showLoadingWait'};

	if ($l_tmp == "1")
	{
		$g_comp_template->assign('b_showLoadingWait', 1);
	} // if

	/**
	 * Include main navigation.
	 *
	 * @todo  isys_mainnavi need a place in the i-doit structure.
	 * @todo  isys_mainnavi is plain and not dynamic.
	 */
	if (!$g_ajax)
	{
		include_once $g_dirs['utils'] . 'isys_mainnavi.inc.php';
	} // if

	// Analyze parameters for object lists.
	if (isys_glob_get_param('sort') != false)
	{
		$g_comp_template->assign('sort', isys_glob_get_param('sort'));
	} // if

	if (isys_glob_get_param('dir') != false)
	{
		$g_comp_template->assign('dir', isys_glob_get_param('dir'));
	} // if

	// Store status array.
	if ($_POST['cmdb_status'])
	{
		$_SESSION['cmdb_status'] = $_POST['cmdb_status'];
	} // if

	if (!isset($_SESSION['cmdb_status']) || !is_array($_SESSION['cmdb_status']))
	{
		// Set default status.
		$_SESSION['cmdb_status'] = array(0, 0, 0);
	} // if

	// Write cRecStatusListView to session.
	if (isys_glob_get_param("cRecStatus"))
	{
		$_SESSION['cRecStatusListView'] = isys_glob_get_param("cRecStatus");
	}
	else
	{
		// Is there a value in the session?
		if (!isset($_SESSION['cRecStatusListView']))
		{
			// Set default value
			$_SESSION['cRecStatusListView'] = C__RECORD_STATUS__NORMAL;
		}
		else if ($_SESSION['cRecStatusListView'] > C__RECORD_STATUS__DELETED)
		{
			if ($_GET[C__CMDB__GET__VIEWMODE] == C__CMDB__VIEW__LIST_CATEGORY)
			{
				$_SESSION['cRecStatusListView'] = C__RECORD_STATUS__NORMAL;
			}
			else if ($_GET[C__CMDB__GET__VIEWMODE] == C__CMDB__VIEW__LIST_OBJECT && $_SESSION['cRecStatusListView'] != C__RECORD_STATUS__TEMPLATE)
			{
				$_SESSION['cRecStatusListView'] = C__RECORD_STATUS__NORMAL;
			} // if
		} // if
	} // if

	// CMDB-SPECIFIC - Set object-type id, if not existent in _GET parameters.
	if (empty($_GET[C__CMDB__GET__OBJECTTYPE]) && isset($_GET[C__CMDB__GET__OBJECT]))
	{
		if (class_exists("isys_cmdb_dao"))
		{
			$l_dao_cmdb = new isys_cmdb_dao($g_comp_database);

			$_GET[C__CMDB__GET__OBJECTTYPE] = $l_dao_cmdb->get_objTypeID($_GET[C__CMDB__GET__OBJECT]);
			unset($l_dao_cmdb);
		} // if
	} // if



	if ($g_modman)
	{
		$l_mod_id = $_GET[C__GET__MODULE_ID];

	 	// If no module has been selected, select the CMDB.
	 	if (!isset($_GET[C__GET__MODULE_ID]))
		{
	 		$l_mod_id = C__MODULE__CMDB;
	 	} // if

	 	// Start up module manager.
		if ($g_modman->init($g_modreq))
		{
			$g_active_modreq = &$g_modreq;

			// Removed: isys_rs_system

	 		// Check for access to the module.
			if (is_numeric($l_mod_id))
			{
				try
				{
					$g_modman->load($l_mod_id);
				}
				catch (isys_exception $e)
				{
					//isys_glob_display_error($e->getMessage());
					$GLOBALS['g_error'] = $e->getMessage();
				} // try
			}
			else
			{
				if (defined("C__MODULE__CMDB") && is_numeric(C__MODULE__CMDB))
				{
					// @todo  Translation.
					die("Error: Module ID not numeric. Check your request or constant cache.");
				}
				else
				{
					// @todo  Translation.
					die("Error: Module ID not numeric. Your constant cache is not loaded! This should be a login issue.");
				} // if
			} // if
		} // if
	} // if
}
catch(isys_exception_general $e)
{
	isys_glob_display_error($e->getMessage());
	die();
} // try