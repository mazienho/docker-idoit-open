<?php

/**
 * i-doit
 *
 * Assert handling.
 *
 * @package     i-doit
 * @subpackage  Assert
 * @author      Benjamin Heisig <bheisig@synetics.de>
 * @author      Leonard Fischer <lfischer@i-doit.org>
 * @copyright   synetics GmbH
 * @license http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */

global $g_config;


/**
 * Assert callback function.
 *
 * @param   string   $p_file     The file, at which the assertion happened.
 * @param   integer  $p_line     The line, at which the assertion is placed.
 * @param   string   $p_message  The assertion-code.
 * @author  Leonard Fischer <lfischer@i-doit.org>
 */
function isys_glob_assert_callback($p_file, $p_line, $p_message)
{
	global $g_error;

	// End the output buffering.
	ob_end_clean();

    // Configuration
    $l_prev_lines = 3;
    $l_next_lines = 3;

    // Read the file in a Array for display purpose.
    $l_file_data = file($p_file);

    // Define the start point of viewing the code.
    $l_start = $p_line - $l_prev_lines;
    if ($l_start < 0)
    {
        $l_start = 0;
    } // if

    // Define the end point of viewing the code.
    $l_end = $p_line + $l_next_lines;
    if ($l_end > count($l_file_data))
    {
        $l_file_data[] = '- End of file';
        $l_end = count($l_file_data);
    } // if

	// Preparing the error style.
	$g_error .= '<style type="text/css">pre.error {background-color:#ddd; border:1px solid #aaa; color:#444; overflow:auto; padding:10px;} pre.error span {display:block;}</style>';

    // Start echo'ing the formatted error-message.
    $g_error .= '<pre class="error"><b>Assertion Error in file "' . $p_file . '" (l.' . $p_line . '): "' . $p_message . '"</b>' . PHP_EOL;

    for ($i = $l_start; $i <= $l_end; $i ++)
    {
	    $g_error .= '<span ' . (($i == $p_line) ? 'style="background:#ffff00;"' : '') . '>' . (($i != count($l_file_data)) ? $i . ': ' : '') . isys_glob_htmlentities(str_replace(PHP_EOL, '', $l_file_data[($i - 1)])) . '</span>';
    } // for

	$l_bt = debug_backtrace();

    $l_class = $l_bt[3]['class'];
    $l_function = $l_bt[3]['function'];
    $l_file = $l_bt[2]['file'];
    $l_line = $l_bt[2]['line'];

	$g_error .= PHP_EOL . "Called in: {$l_class}::{$l_function} in {$l_file} at {$l_line}</pre>";
} // function

// Set our assert handler to display a nice message on failed asserts.
assert_options(ASSERT_ACTIVE, 0);
assert_options(ASSERT_WARNING, 0);
assert_options(ASSERT_BAIL, 0);
assert_options(ASSERT_CALLBACK, 'isys_glob_assert_callback');
