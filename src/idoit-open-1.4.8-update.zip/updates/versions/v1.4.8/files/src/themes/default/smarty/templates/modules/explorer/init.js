// Start the whole explorer, when the complete window-element is loaded (IE fix).
window.initExplorer = function() {
    window.explorer = new idoit.Explorer({
            container:		'cmdb-explorer',
			orientation:	'top',
            levelsToShow:   '[{$smarty.get.rl|default:1}]',
            multitree:      [{$explorer.multitree|default:"false"}],
            json: [{$spacetree_json|default:"{name: '', data: {objectType:'CMDB-Explorer'}, children: []}"}],
            contextTemplate: [
                {content:'[{isys type="lang" ident="LC__CMDB_EXPLORER__SET_AS_ROOT"}]', href:'?viewMode=[{$smarty.const.C__CMDB__VIEW__EXPLORER}]&objID=#{objectID}', image:'images/icons/tree/base.gif', target:'_self', constraint:'objID'},
                {content:'[{isys type="lang" ident="LC__UNIVERSAL__OPEN"}]', href:'?objID=#{objectID}', image:'images/icons/updates.gif', constraint:'objID'},
                {content:'[{isys type="lang" ident="LC__CMDB_EXPLORER__OPEN_IN_NEW_WINDOW"}]', href:'?objID=#{objectID}', image:'images/icons/announcements.gif', target:'_new', constraint:'objID'},
                {content:'[{isys type="lang" ident="LC__NAVIGATION__NAVBAR__DUPLICATE"}]', href:'javascript:explorer.duplicate(explorer._st.graph.nodes[#{nodeID}])',image:'images/icons/navbar/duplicate_icon.png', constraint:'objID'},
                {content:'[{isys type="lang" ident="LC__NAVIGATION__NAVBAR__ARCHIVE"}]', href:'javascript:explorer.archive(explorer._st.graph.nodes[#{nodeID}])',image:'images/icons/navbar/archive_icon.png', constraint:'objID'}
                //,{content:'Node debuggen', href:'javascript:console.log(explorer._st.graph.nodes[#{nodeID}]);', image:'images/icons/conf-ico.gif'},
            ]
        },
        {
            node:		'<div class="otype">#{contextMenu} <span>#{image} #{objecttype}</span></div>' +
                        '<div class="content"><div class="fr gradient statusButton" style="background-color:##{statusColor};"></div>#{link}</div>',
            image:		'<img src="#{image}" height="13" alt="-" />',
            checkbox:	'<input type="checkbox" name="ocheck" value="#{id}" /> ',
            link:		'#{name}'
        }
    );

    /* Set explorer specific language constants */
    window.explorer.lang = {
        reallyArchive: '[{isys type="lang" ident="LC__CMDB_EXPLORER__REALLY_ARCHIVE"}] ?',
        noSubNodes: '[{isys type="lang" ident="LC__CMDB_EXPLORER__REQEUST__NO_SUBNODES"}]',
        minimize: '[{isys type="lang" ident="LC__UNIVERSAL__MINIMIZE"}]'
    };

    /* Resize canvas on tree fold */
    /*new Event.observe($('treeSwitch').down(), 'click', function(){
        explorer.getCanvas().resize($('explorer').getWidth() + $('menuTreeOn').getWidth(), explorer.getCanvas().getSize().height);
    });*/

    /* Remove context menu on an explorer "anywhere" click */
    new Event.observe('cmdb-explorer', 'click',  explorer.hideContextMenu.bindAsEventListener());
};