/**
 * Special CMDB explorer nodetype implementation.
 *
 * @author  Dennis Stücken <dstuecken@synetics.de>
 */
$jit.ST.Plot.NodeTypes.implement({
	'roundrect': {
		'render': function (node, canvas, animating) {
			var pos = node.pos.getc(true),
				ctx = canvas.getCtx(),
				ort = this.config.orientation,
				algnPos = this.getAlignedPos(pos, this.node.width, this.node.height),
				halfNodeWidth = (this.node.width / 2),
				halfNodeHeight = (this.node.height / 2),
				subExists = node.anySubnode("exist");

			ctx.beginPath();

			var r = 20, x = algnPos.x, y = algnPos.y, h = this.node.height, w = this.node.width;

			// Set red stroke color for root object in root-mode.
			if (node.id == 0) {
				ctx.strokeStyle = '#FF0000';
			} else {
				ctx.strokeStyle = '#555555';
			}

			ctx.moveTo(x + r, y);

			// Top-right.
			ctx.lineTo(x + w, y);
			ctx.lineTo(x + w, y + r);

			if (subExists && ort == 'left') {
				ctx.lineTo(x + w, y + halfNodeHeight - 2);
				ctx.lineTo(x + w + 2, y + halfNodeHeight);
				ctx.lineTo(x + w, y + halfNodeHeight + 2);
			}

			// Bottom-right.
			ctx.lineTo(x + w, y + h - r);
			ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);

			if (subExists && ort == 'top') {
				ctx.lineTo(x + (halfNodeWidth) + 2, y + h);
				ctx.lineTo(x + (halfNodeWidth), y + h + 2);
				ctx.lineTo(x + (halfNodeWidth) - 2, y + h);
			}

			// Bottom-left.
			ctx.lineTo(x + r, y + h);
			ctx.quadraticCurveTo(x, y + h, x, y + h - r);

			// Top-left.
			ctx.lineTo(x, y + r);
			ctx.lineTo(x, y);

			ctx.closePath();
			ctx.stroke();
			ctx.fill();
		}
	}
});

/**
 * i-doit CMDB explorer class.
 *
 * @author  Dennis Stücken <dstuecken@synetics.de>
 */
idoit.Explorer = Class.create(null, {
	_st: {},

	_options: {
		// Ajax-URL for loading nodes.
		loadNodeURL: null,
		ajaxLoadingId: null
	},

	_debug: false,

	// Context menu enabled?
	enableContextMenu: true,
	contextTemplate: '<li><a href="?objID=#{objectID}"><img src="images/icons/updates.gif" />#{objectName}</a></li>',

	// Language parameters.
	lang: {
		reallyArchive: 'Wirklich archivieren?',
		noSubNodes: 'Keine Subnodes vorhanden.'
	},

	// Images.
	images: {
		contextMenu: 'images/multiselect.gif'
	},

	// Info Widget enabled?
	enableInfoWidget: true,
	infoWidgetId: 'infoWidgetWrapper',

	currentNode: {},

	// Wrapper Element of the explorer items.
	explorerWrapperId: 'explorerWrapper',

	// Maxlen of node content.
	nodeMaxLen: 75,

	initialize: function (p_options, p_nodeTemplates) {
		var that = this;

		// Initialize options.
		this._options = Object.extend({
				container: 'explorer',
				orientation: 'top',
				ajaxLoadingId: 'cmdb-explorer-loading',
				json: {},
				loadNodeURL: document.location.href || 'index.php',
				resultSorter: function (p_result) {
					var l_children = Object.clone(p_result.children),
						i,
						l_tmp_arr = $H(),
						s_objectType = "";

					for (i in l_children) {
						// l_children.hasOwnProperty() won't work here.
						if (typeof l_children[i] != 'function') {
							s_objectType = l_children[i].data.objectType;
							if (!l_tmp_arr.get(s_objectType)) {
								l_tmp_arr.set(s_objectType, []);
							}

							l_tmp_arr.get(s_objectType).push(l_children[i]);
						}
					}

					l_tmp_arr = l_tmp_arr.toObject();
					var l_sorted_objectTypes = Object.getOwnPropertyNames(l_tmp_arr).sort();
					p_result.children = [];

					for (i = 0; i < l_sorted_objectTypes.length; i++) {
						p_result.children = p_result.children.concat(l_tmp_arr[l_sorted_objectTypes[i]]);
					}

					return p_result;
				}
			},
			p_options || {});

		// Extract contextTemplate and infoWidgetId.
		if ('contextTemplate' in p_options && p_options.contextTemplate) this.contextTemplate = p_options.contextTemplate;
		if ('infoWidgetId' in p_options && p_options.infoWidgetId) this.infoWidgetId = p_options.infoWidgetId;

		// Initialize nodeTemplate.
		this._nodeTemplates = {
			node: new Template(p_nodeTemplates.node),
			image: new Template(p_nodeTemplates.image),
			checkbox: new Template(p_nodeTemplates.checkbox),
			link: new Template(p_nodeTemplates.link)
		};

		this._st = new $jit.ST({
			injectInto: this._options.container,
			orientation: this._options.orientation,
			levelsToShow: this._options.levelsToShow || 1,
			constrained: false, // open up everything at the same time?
			levelDistance: this._options.levelDistance || 35,
			transition: $jit.Trans.Sine.easeInOut,
			duration: 40,
			multitree: this._options.multitree,

			Node: {
				type: 'roundrect',
				height: 75,
				width: 125,
				color: '#eee',
				lineWidth: 1,
				overridable: true,
				CanvasStyles: {
					shadowColor: '#999',
					shadowBlur: 10
				}
			},
			Tips: {
				enable: false,
				offsetX: 10,
				offsetY: 10,
				onShow: function (tip, node, isLeaf) {
					tip.update('ID: <strong>' + node.id + '</strong><br />' + node.data.objectType + ': ' + node.name);
					tip.className = 'explorer_tooltip';
				}
			},
			Edge: {
				type: 'bezier',
				lineWidth: 1,
				color: '#23A4FF',
				overridable: true
			},
			Navigation: {
				enable: true,
				panning: true,
				zooming: false
			},

			onBeforeCompute: Prototype.emptyFunction,
			onAfterCompute: function (node) {
                if (that._options.ajaxLoadingId && $(that._options.ajaxLoadingId)) $(that._options.ajaxLoadingId).hide();
			},
			Events: {
				enable: true,
				onRightClick: Prototype.emptyFunction,
				onMouseEnter: Prototype.emptyFunction,
				onMouseLeave: Prototype.emptyFunction
			},

			onCreateLabel: function (label, node) {
				// Initialization.
				var l_contextMenu = '',
					l_name = node.name.length > this.nodeMaxLen ? node.name.substr(0, this.nodeMaxLen) + '..' : node.name;

				if (node.id) label.id = node.id;

				// Prepare context menu image.
				if (node._depth > 0) {
					l_contextMenu = '<img src="' + this.images.contextMenu + '" class="fr" height="15" />';
				}

				// Show info widget, on mouse over.
				label.onmouseover = function (e, win) {
					this.showInfoWidget(node, e);
				}.bind(this);

				// Display element information.
				label.innerHTML = this._nodeTemplates.node.evaluate({
					checkbox: (node.id) ? this._nodeTemplates.checkbox.evaluate({id: node.data.objID}) : '',
					image: (node.data.image) ? this._nodeTemplates.image.evaluate({image: node.data.image}) : '',
					link: this._nodeTemplates.link.evaluate({id: node.data.objID, name: l_name}),
					statusColor: node.data.statusColor ? node.data.statusColor : '#FFF',
					contextMenu: l_contextMenu,
					objecttype: node.data.objectType
				});

				var expandNode = function (e) {
					if (node.collapsed) {
						this.expandNode(node);
					} else {
						if (!node.loaded) this.loadNode(node);
						else {
							this._st.onClick(node.id, { Move: {
								enable: true, offsetX: this._st.canvas.translateOffsetX, offsetY: this._st.canvas.translateOffsetY + 150
							}});
						}
					}
				}.bind(this);

				if (label.down) {
					// Remove status icon if unavailable.
					if (!node.data.statusColor) {
						label.down('.statusButton').remove();
					}

					// Enable context menu.
					if (node._depth > 0) {
						label.down().down().onclick = function (e, win) {
							if (this.enableContextMenu) this.showContextMenu(node.id, e);
						}.bind(this);
					}

					// Bind onclick handling for opening the nodes.
					label.down().next().onclick = expandNode;

				} else {
					label.onclick = expandNode;
				}

                // Bind double click to node header.
                label.ondblclick = function (e) {
                    this.foldNode(node);
                }.bind(this);

			}.bind(this),

			onBeforePlotNode: function (node) {
				// Style every node.
				node.className = 'node';

				// and change color of special nodes.
				if (node.selected) {
					node.data.$color = "#ff7";
				} else {
					node.data.$color = (node.data.color) ? node.data.color : "#E3FBE9";
				}

			},

			onBeforePlotLine: function (adj) {
				if (adj.nodeFrom.selected && adj.nodeTo.selected) {
					adj.data.$color = "#cc6666";
				}
			}
		});

		this._st.loadJSON(this._options.json);
		this._st.compute();
		this._st.onClick(this._st.root);
	},

	toggleOrientation: function () {
		this._st.switchPosition(this._st.config.orientation == 'top' ? 'left' : 'top', "animate");
	},

	nodeCount: function () {
		if (this._st.graph.nodes.__count__ === undefined) {
			return Object.keys(this._st.graph.nodes).length;
		}

		return this._st.graph.nodes.__count__;
	},

	expandNode: function(node) {

		$jit.Graph.Util.eachSubgraph(node, function(n) {
          if (n.id != node.id) {
            Object.extend(n, {
                'drawn': true,
                'exist': true
            });
          }
        });

		this._st.op.expand(node, {
		  type: 'animate',
		  duration: 150,
		  hideLabels: false,
		  transition: $jit.Trans.Quart.easeOut,
		  onComplete: function() {
		  	this._st.onClick(node.id, { Move: { enable: false }});
		  }.bind(this)
		});

	},

	foldNode: function (node) {
        /*
		this._st.op.contract(node, {
			type: 'animate',
			duration: 150,
			hideLabels: true,
			transition: $jit.Trans.Quart.easeOut,
			onComplete: Prototype.emptyFunction
		});
		*/

        //this._st.removeSubtree(node.id, false, 'animate');
	},

	loadNode: function (node, onComplete) {
		if (!node.anySubnode("exist") && (typeof node.loaded == 'undefined' || node.loaded == false) && this._options.loadNodeURL != false) {

			var rTypes = [];
			$A(document.getElementsByName('relation_type[]')).each(function (i) {
				if (!i.checked) rTypes.push(i.value);
			});

			// Show loading message.
			$(this._options.ajaxLoadingId).show();

			// No subnode exists, try to get them via AJAX.
			new Ajax.Request(this._options.loadNodeURL, {
				method: 'post',
				parameters: {
					ajax: 1,
					objID: node.data.objID,
					objTypeID: node.data.objTypeID,
					nodeID: node.id,
					counter: this.nodeCount(),
					hideRelations: Object.toJSON(rTypes),
					orientation: node.data.$orn ? node.data.$orn : null
				},
				onComplete: function (t) {
					// Hide loading screen.
					$(this._options.ajaxLoadingId).fade();

					if (t.responseJSON) {
						var json = t.responseJSON;
						json.id = node.id;
						json = this._options.resultSorter(json);

						if (json.children.length > 0) {
							this._st.addSubtree(json, 'animate', {
								onComplete: function () {
									this._st.onClick(node.id, { Move: {
										enable: false
									}});
								}.bind(this),
								hideLabels: false
							});
						} else {
                            idoit.Notify.info(this.lang.noSubNodes);
							node.data.subNodes = 0;
							this._st.viz.refresh(true);
						}

						node.loaded = true;
					} else {
						if (t.responseText.search('login_error') <= -1) {
                            idoit.Notify.message(t.responseText.stripTags());
						} else {
							// The session timed out: Reload.
							document.location.href = new String(document.location);
						}
					}
				}.bind(this)
			});
		}
	},

	showContextMenu: function (nodeID, e) {
		if ($('eContextMenu')) this.hideContextMenu();

		var node = this._st.graph.nodes[nodeID];

		if (((node && node.id) || typeof node.id == "number") && node.data.objID != 1) {

			var nodeName = (node.name.length > 26 ? node.name.substr(0, 26) + '..' : node.name),
				a,
				templateContent = new Element('div').update(new Element('li', {className: 'head bold p5'}).update('<span>' + nodeName + '</span>')).innerHTML;

			this.contextTemplate.each(function (i) {

				if (i.constraint && !$H(node.data).get(i.constraint)) return;

				a = new Element('a', {
					className: '', href: i.href, target: (i.target) ? i.target : ''
				}).update('<img src="' + i.image + '" alt="+" width="15" /> ' + i.content);

				/* @todo ds: find a way to extend a string by an element!! the second way is not that elegant.. */
				if (Element.outerHTML) {
					templateContent += (new Element('li').update(a)).outerHTML;
				} else {
					templateContent += new Element('div').update(new Element('li').update(a)).innerHTML;
				}
			});

			var contextMenu = new Element('ul', {id: 'eContextMenu'}).update(new Template(templateContent.replace(/%7B/g, '{').replace(/%7D/g, '}')).evaluate({
				objectID: node.data.objID,
				nodeID: node.id
			})).setStyle('display:none;');

			var y = Event.pointerY(e), x = Event.pointerX(e);

			window.setTimeout(function () {
				$('contextWrapper').update(contextMenu).setStyle('top:' + y + 'px;left:' + x + 'px;');
				new Effect.Appear('eContextMenu', {duration: 0.2});
			}, 150);

			delete a, templateContent, contextMenu, nodeName, x, y;
		}

	},

	hideContextMenu: function() {
		if ($('eContextMenu')) $('eContextMenu').remove();
	},

	showInfoWidget: function (node, e) {

		var wdgtHTML = '';

		if (this.enableInfoWidget && node._depth > 0) {

			if (typeof node.data.relation != 'undefined' && node.data.relation) {
				var parent = node.getParents(),
					relation,
					relation_type,
					relation_object = parent[0].name,
					cmdb_status;

				relation_object = (relation_object.length > 70) ? relation_object.substr(0, 70) + '..' : relation_object;

				wdgtHTML = new Element('table', {'class': 'infoTable'});

				if (node.data.relation.object_title) relation_object = node.data.relation.object_title;

				if (parent.length > 0) {
					relation = node.data.relation.text + ' <u>' + relation_object + '</u>';
					relation_type = node.data.relation.type;
					cmdb_status = node.data.cmdb_status;
				} else {
					relation = '-';
					relation_type = '-';
					cmdb_status = '-';
				}

				var subNodes = node.data.subNodes ? node.data.subNodes : '0';

				wdgtHTML.update(
					'<tr>' +
						'<td class="bold">[{isys type="lang" ident="LC__CATG__RELATION__RELATION_TYPE"}]:</td><td>' + relation_type + '</td>' +
					'</tr><tr>' +
						'<td class="bold">[{isys type="lang" ident="LC__UNIVERSAL__RELATION"}]:</td><td>' + relation + '</td>' +
					'</tr><tr>' +
						'<td class="bold">[{isys type="lang" ident="C__CMDB_EXPLORER__INFO_WIDGET__NUM_RELATIONS"}]:</td><td>~' + subNodes + '</td>' +
					'</tr><tr>' +
						'<td class="bold">[{isys type="lang" ident="LC__UNIVERSAL__STATUS"}]:</td><td>' + cmdb_status + '</td>' +
					'</tr>');
			}
		}

        var category = node.data.objectCategory ? node.data.objectCategory : node.data.objectType;

		if (node.data.image) {
			if ($(this.infoWidgetId)) {
				$(this.infoWidgetId)
					.update('<div class="fl mr5"><img style="border:1px solid #333;" src="' + node.data.image + '" height="60" alt="" /></div>')
					.insert('<h2 class="text-shadow fr" style="text-align:right;text-overflow: ellipsis;width:35%;overflow: hidden;">' + node.name + '<br />' + category + '</h2>')
					.insert(wdgtHTML);
			}
		} else {
			if ($(this.infoWidgetId)) {

				$(this.infoWidgetId)
					.update('<h2 class="text-shadow fr" style="text-align:right;">' + node.name + '<br />' + category + '</h2>')
					.insert(wdgtHTML);
			}
		}
	},

    print: function() {

        var img = this.exportPNG();

        if (img)
        {
            var myWindow = window.open("","ExportWindow","width=1024,height=1024,toolbar=no,scrollbars=yes,resizable=yes");
            myWindow.document.write('<img src="'+img+'"/>');
            myWindow.print();
        }
        else alert('Error getting canvas context.');

    },

    exportPNG: function() {
        if ($(this._st.config.injectInto + '-canvas'))
        {
            return $(this._st.config.injectInto + '-canvas').toDataURL("image/png");
        }
        return false;
    },

	center: function () {
		this._st.onClick(this._st.root, {
			Move: {
				enable: true,
				offsetX: this._st.canvas.translateOffsetX,
				offsetY: this._st.canvas.translateOffsetY + 250 }
		});
	},

	duplicate: function(node) {
		this.hideContextMenu();
		this.currentNode = node;

		get_popup('duplicate', 'editMode=1&objTypeID=' + node.data.objTypeID + '&objID=' + node.data.objID + '&objTitle=' + node.name, 480, 500);
	},

	archive: function(p_node) {
		this.hideContextMenu();

		/**
		  * @todo own confirmation dialog?
		  */
		if (confirm(this.lang.reallyArchive))
        {
			new Ajax.Request(document.location.href, {
			 	parameters: {
			 		request:'archive', objID:p_node.data.objID
				},
			 	method:'post',
			 	onComplete:function(r) {
                    idoit.Notify.message(r.responseText);

                    this.foldNode(p_node);
                    this._st.op.removeNode(p_node.id, { type: 'fade:con', duration: 450, hideLabels: false, onComplete: function() {

                        var parents = p_node.getParents();
                        if (parents.length > 0 && parents[0].id) this._st.onClick(parents[0].id, {Move:{enable: false}});

                    }.bind(this) });
				}.bind(this)
			});
		}

	},

	showMessage: function(p_message) {
        idoit.Notify.message(p_message);
	},

	hideInfoWidget: function() {
		if ($(this.infoWidgetId)) $(this.infoWidgetId).update();
	},

	setInfoWidget: function(p_enabled) {
		this.infoWidgetEnabled = p_enabled;

		new Effect.toggle(this.infoWidgetId, 'blind', {
			duration:0.1
		});
	},

	getCanvas: function() {
		return this._st.canvas;
	},

	minimize: function() {
		$(this._options.container).style.position = 'absolute';
        $('downarrow').show();
		new Effect.Morph(this._options.container, {
			style:'left:0;top:63px;right:0;',
			duration:0.1
		});
	},

	maximize: function() {
        $(this._options.container).style.position = 'fixed';
        $('downarrow').hide();

		new Effect.Morph(this._options.container, {
			style:'margin:0;top:0;left:0;right:0;bottom:0;',
			duration:0.1
		});

		var a = new Element('a', {href:'javascript:;',style:'position:absolute;top:45px;right:5px;', className: 'button slim'}).observe('click', function(e) {
			e.element().remove();
			this.minimize();
		}.bind(this));

		$(this._options.container).insert(a.update('<img class="vam" src="images/icons/silk/arrow_in_longer.png" /> ' + this.lang.minimize));
		this.getCanvas().resize($(this._options.container).getWidth() + 5, $(this._options.container).getHeight() + 160);
	}
});