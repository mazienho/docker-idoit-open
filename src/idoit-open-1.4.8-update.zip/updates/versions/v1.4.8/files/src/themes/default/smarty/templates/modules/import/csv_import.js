/*[{* Smarty template for csv imports
 @ author: Selcuk Kekec <skekec@synetics.de>
 @ author: Benjamin Heisig <bheisig@synetics.de>
 @ copyright: synetics GmbH
 @ license: <http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3>
 *}]*/

/**
 * Delete an uploaded CSV file from file system.
 */
function delete_import(p_file) {
    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=delete_import', {
        method: 'post',
        parameters: {
            filename: p_file
        },
        onSuccess: function(transport) {
            if (transport.responseText == "true") {
                showMsgBox('[{isys type="lang" ident="LC__UNIVERSAL__FILE_DELETED" p_bHtmlEncode="1"}] (' + p_file + ')', 'info');
                new Effect.SlideUp(p_file);
            } else {
                showMsgBox('[{isys type="lang" ident="LC__UNIVERSAL__FILE_NOT_DELETED" p_bHtmlEncode="1"}] (' + p_file + ')', 'error');
            }
        }
    });
}

/**
 * Delete a log file from file system.
 */
function delete_log_file(p_file) {
    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=delete_log_file', {
        method: 'post',
        parameters: {
            filename: p_file
        },
        onSuccess: function(transport) {
            if (transport.responseText == "true") {
                $('log_info').hide();
                $('log_info').textContent = '[{isys type="lang" ident="LC__UNIVERSAL__FILE_DELETED" p_bHtmlEncode="1"}] (' + p_file + ')';
                new Effect.Appear('log_info');
                new Effect.SlideUp(p_file);
            } else {
                $('log_error').hide();
                $('log_error').textContent = '[{isys type="lang" ident="LC__UNIVERSAL__FILE_NOT_DELETED" p_bHtmlEncode="1"}] (' + p_file + ')';
                new Effect.Appear('log_error');
                new Effect.SlideUp(p_file);
            }
        }
    });
}

/**
 * Print a message box.
 */
function showMsgBox(p_message, p_status) {
    $("file_" + p_status).hide();
    $("file_" + p_status).textContent = p_message;
    new Effect.Appear("file_" + p_status);
}

/**
 * Select an uploaded CSV file as import candidate.
 */
function select_import(p_file) {
    if (!($('import-next').visible())) {
        $('import-next').show();
    }
    $('selected_file').value = p_file;
    $('import-filename').textContent = p_file;
    showMsgBox('[{isys type="lang" ident="LC__UNIVERSAL__CHOOSEN_FILE" p_bHtmlEncode="0"}]: ' + p_file, 'info');
}

/**
 * Submit import candidate.
 */
function submit_import() {
    var l_file = $('selected_file');
    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=file_exist', {
        method: 'post',
        parameters: {
            filename: l_file.value
        },
        onSuccess: function(transport) {
            if (transport.responseText == 'true') {
                document.forms[0].submit();
            } else {
                $('submit_error').innerHTML = '[{isys type="lang" ident="LC__UNIVERSAL__FILE_DOES_NOT_EXIST" p_bHtmlEncode="1"}]';
                $('submit_error').style.display = 'block';
            }
        }
    });
}

/**
 * Load the list of properties specified for a category.
 */
function load_properties(p_catgID, p_index, p_catName, p_auto) {
    if (isNaN(p_catgID) == false) {
        if (p_catgID != 0) {
            var l_loadAni = $("load_prop_" + p_index);
            l_loadAni.style.display = 'block';
            new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_properties', {
                method: 'post',
                parameters: {
                    catgID: p_catgID
                },
                onSuccess: function(transport) {
                    if ($('csv_assignment_table').rows[p_index + 1].cells[2].style.backgroundColor == '#C2FFBC')
                    {

                        $('csv_assignment_table').rows[p_index + 1].cells[2].style.backgroundColor = 'white';
                        $('csv_assignment_table').rows[p_index + 1].cells[3].style.backgroundColor = 'white';
                    }
                    if (transport.responseText != '')
                    {
                        $("prop_" + p_index).stopObserving();
                        if($("prop_" + p_index).next())
                        {
                            $("prop_" + p_index).next().remove();
                        }
                        show_properties(transport, p_index, p_catName, p_auto);
                        $("prop_" + p_index).disabled = false;
                    }
                    else
                    {
                        $("prop_" + p_index).innerHTML = '';
                    }

                    l_loadAni.style.display = 'none';
                },
                onComplete: function() {
                    if (Ajax.activeRequestCount == 1) {
                        hide_overlay();
                    }
                    l_loadAni.style.display = 'none';
                }
            });
        } else {
            $("prop_" + p_index).disabled = true;
            $("prop_" + p_index).innerHTML = '';
        }
    } else {
        $("prop_" + p_index).disabled = true;
        $("prop_" + p_index).innerHTML = '';
    }
}

/**
 * Print a list of properties.
 */
function show_properties(p_JSON, p_index, p_catName, p_auto) {
    var json = $H(p_JSON.responseText.evalJSON());
    var target = $('prop_' + p_index).update('');

    json.each(function(e) {
        var option = new Element('option', {
            'value': e[0].replace(/\s/g, '')
        });

        if (e[1].search("[*]") != -1) {
            e[1] = e[1].replace("[*]", '');
            option.setStyle({backgroundColor: '#CADBFF'});
        }

        option.update(e[1]);

        if (p_catName != undefined) {
            if ((option.innerHTML == p_catName || option.innerHTML.toLowerCase().search(p_catName.toLowerCase()) != -1) && p_auto) {
                option.setAttribute('selected', 'selected');
            }
        }

        target.insert(option);

        if (option.getAttribute('selected')) {
            target.up('td').setStyle({backgroundColor: '#C2FFBC'});
        }
    }.bind(this));

    /**
     * Extra selection type location
     */
    add_additional_select(target, p_index);
}

function add_additional_select(p_target, p_index, p_simulate, p_selected_index)
{
    /**
     * Extra selection type location
     */
    p_target.on('change', function(){
        var prop_id = this.value;
        additional_select_request(p_target, p_index, prop_id);
    });

    if(p_simulate){
        additional_select_request(p_target, p_index, p_target.value, p_selected_index);
    }
}

function additional_select_request(p_target, p_index, p_prop_index, p_selected_index)
{
    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_additional_check', {
        method: 'post',
        parameters: {
            catgID: $('catg_'+p_index).value,
            propertyID: p_prop_index
        },
        onSuccess: function(transport) {
            var json = transport.responseJSON;

            if(json.length == 0)
            {
                if(p_target.next())
                {
                    p_target.next().remove();
                }
            }
            else
            {
                var search_target = new Element('select',
                    {
                        className: 'inputDialog optgroup_fix',
                        style:'display:inline; width: 200px;',
                        name:'prop_search['+$('catg_'+p_index).value+'_'+p_prop_index+']',
                        id:'prop_search_'+p_index+'_'+p_prop_index
                    }
                );

                for(i in json)
                {
                    if(json.hasOwnProperty(i))
                    {
                        if(i == p_selected_index)
                        {
                            l_option_params = {value: i, selected: true};
                        }
                        else
                        {
                            l_option_params = {value: i};
                        }
                        search_target.insert(new Element('option', l_option_params).insert(json[i]));
                    }
                }
                p_target.up().insert(search_target);
            }
        }
    });
}

/**
 * Load specific categories.
 */
function load_specific_categories(p_Object) {
    if (p_Object.value == 0) {
        load_categories();
    } else {
        var l_loadAni = $('load')
        l_loadAni.style.display = 'block';
        new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_specific_categories', {
            method: 'post',
            parameters: {
                objecttypeID: p_Object.value,
                multivalue: $('multivalue').value
            },
            onSuccess: function(transport) {
                show_categories(transport.responseJSON);
                l_loadAni.style.display = 'none';
                if ($('auto_matching').value == 'on') {
                    auto_match();
                }
            }
        });
    }
}

/**
 * Print specific categories.
 */
function show_specific_categories(json) {
    var options = '',
            option;

    for (var opt_group in json) {
        if (json.hasOwnProperty(opt_group)) {
            option = new Element('optgroup', {label: opt_group});

            if (json[opt_group].length != 0 && json[opt_group].length != 'undefined') {
                for (var catg in json[opt_group]) {
                    if (json[opt_group].hasOwnProperty(catg)) {
                        option.insert(new Element('option', {value: (catg.replace(/\s/g, ''))}).update(json[opt_group][catg]));
                    }
                }
            }

            options += option.outerHTML;
        }
    }

    $$('select.catg').each(function(select) {
        select.setStyle({backgroundColor: '#fff'}).update(options);
    });
}

/**
 * Load the list of categories.
 */
function load_categories() {
    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_categories', {
        method: 'post',
        parameters: {
            multivalue: $('multivalue').value
        },
        onSuccess: function(transport) {
            show_categories(transport.responseJSON);
            if ($('auto_matching').value == 'on') {
                auto_match();
            }
        }
    });
}

/**
 * Print the list of categories.
 */
function show_categories(json) {
    var options = '',
            option;

    for (var opt_group in json) {
        if (json.hasOwnProperty(opt_group)) {
            option = new Element('optgroup', {label: opt_group});

            if (json[opt_group].length != 0 && json[opt_group].length != 'undefined') {
                for (var catg in json[opt_group]) {
                    if (json[opt_group].hasOwnProperty(catg)) {
                        option.insert(new Element('option', {value: (catg.replace(/\s/g, ''))}).update(json[opt_group][catg]));
                    }
                }
            }

            options += option.outerHTML;
        }
    }

    $$('select.catg').each(function(select) {
        select.setStyle({backgroundColor: '#fff'}).update(options);
    });
}

/**
 * Create important import information.
 */
function create_information(p_boxID) {
    var l_type = 'hidden',
            l_counter = 0,
            l_target = $('csv_information').update();

    while ($("catg_" + l_counter)) {
        if (isNaN($("catg_" + l_counter).value) == false && $("catg_" + l_counter).value != 0) {
            var l_catg = $('catg_' + l_counter);
            var l_prop = $('prop_' + l_counter);
            if ($('multivalue').value == 'row') {
                var input_element = document.createElement('input');
                input_element.type = l_type;
                input_element.name = 'assignment[' + l_catg.value + '][' + l_prop.value + ']';
                input_element.value = l_counter;
                l_target.appendChild(input_element);
            }
            else {
                var input_catg = document.createElement('input');
                var input_property = document.createElement('input');
                input_catg.type = l_type;
                input_property.type = l_type;

                input_catg.name = 'assignment[' + l_counter + '][catg]';
                input_property.name = 'assignment[' + l_counter + '][property]';

                input_catg.value = l_catg.value;
                input_property.value = l_prop.value;

                l_target.appendChild(input_catg);
                l_target.appendChild(input_property);
            }
        }
        else if ($('catg_' + l_counter).value == 'separator') {
            var input_element = document.createElement('input');
            input_element.type = l_type;
            input_element.name = 'assignment[' + l_counter + '][catg]';
            input_element.value = 'separator';

            l_target.appendChild(input_element);
        } else {
            var input_custom = document.createElement('input');
            input_custom.name = $("catg_" + l_counter).value;
            input_custom.value = l_counter;
            input_custom.type = l_type;
            l_target.appendChild(input_custom);
        }
        l_counter++;
    }
    if (object_title() && object_type()) {
        $('status_before_import').style.display = 'none';
        $('import_button_container_' + p_boxID).setAttribute('style', 'font-weight:bold;padding:4px;margin-bottom:5px;background-color:#ffdddd;border:1px solid #ff4343;text-align:center');
        $('import_button_container_' + p_boxID).innerHTML = '[{isys type="lang" ident="LC__UNIVERSAL__IMPORT_IN_PROGRESS" p_bHtmlEncode="1"}]';
        document.forms[0].submit();
    } else {
        $('status_before_import').innerHTML = '[{isys type="lang" ident="LC__UNIVERSAL__CSV_IMPORT_NO_OBJECT_TITLE" p_bHtmlEncode="1"}]';
        $('status_before_import').style.display = 'block';
    }
}

/**
 * Make a rapid submit.
 */
function rapid_submit() {
    $('csv_information').innerHTML = '<input type="hidden" name="object_title" value="0"><input type="hidden" name="2[csvindex]" value="2"><input type="hidden" name="2[catg]" value="1"><input type="hidden" name="2[prop]" value="1"><input type="hidden" name="3[csvindex]" value="3"><input type="hidden" name="3[catg]" value="1"><input type="hidden" name="3[prop]" value="2"><input type="hidden" name="4[csvindex]" value="4"><input type="hidden" name="4[catg]" value="1"><input type="hidden" name="4[prop]" value="3"><input type="hidden" name="5[csvindex]" value="5"><input type="hidden" name="5[catg]" value="38"><input type="hidden" name="5[prop]" value="59"><input type="hidden" name="6[csvindex]" value="6"><input type="hidden" name="6[catg]" value="38"><input type="hidden" name="6[prop]" value="60"><input type="hidden" name="7[csvindex]" value="7"><input type="hidden" name="7[catg]" value="38"><input type="hidden" name="7[prop]" value="61"><input type="hidden" name="8[csvindex]" value="8"><input type="hidden" name="8[catg]" value="38"><input type="hidden" name="8[prop]" value="193"><input type="hidden" name="9[csvindex]" value="9"><input type="hidden" name="9[catg]" value="4"><input type="hidden" name="9[prop]" value="13"><input type="hidden" name="10[csvindex]" value="10"><input type="hidden" name="10[catg]" value="4"><input type="hidden" name="10[prop]" value="14"><input type="hidden" name="11[csvindex]" value="11"><input type="hidden" name="11[catg]" value="4"><input type="hidden" name="11[prop]" value="15"><input type="hidden" name="12[csvindex]" value="12"><input type="hidden" name="12[catg]" value="4"><input type="hidden" name="12[prop]" value="16"><input type="hidden" name="13[csvindex]" value="13"><input type="hidden" name="13[catg]" value="44"><input type="hidden" name="13[prop]" value="77"><input type="hidden" name="14[csvindex]" value="14"><input type="hidden" name="14[catg]" value="44"><input type="hidden" name="14[prop]" value="78"><input type="hidden" name="15[csvindex]" value="15"><input type="hidden" name="15[catg]" value="44"><input type="hidden" name="15[prop]" value="79"><input type="hidden" name="16[csvindex]" value="16"><input type="hidden" name="16[catg]" value="44"><input type="hidden" name="16[prop]" value="80"><input type="hidden" name="17[csvindex]" value="17"><input type="hidden" name="17[catg]" value="45"><input type="hidden" name="17[prop]" value="81"><input type="hidden" name="18[csvindex]" value="18"><input type="hidden" name="18[catg]" value="45"><input type="hidden" name="18[prop]" value="82"><input type="hidden" name="19[csvindex]" value="19"><input type="hidden" name="19[catg]" value="45"><input type="hidden" name="19[prop]" value="83"><input type="hidden" name="20[csvindex]" value="20"><input type="hidden" name="20[catg]" value="45"><input type="hidden" name="20[prop]" value="84"><input type="hidden" name="21[csvindex]" value="21"><input type="hidden" name="21[catg]" value="45"><input type="hidden" name="21[prop]" value="85"><input type="hidden" name="22[csvindex]" value="22"><input type="hidden" name="22[catg]" value="3"><input type="hidden" name="22[prop]" value="8"><input type="hidden" name="23[csvindex]" value="23"><input type="hidden" name="23[catg]" value="3"><input type="hidden" name="23[prop]" value="10"><input type="hidden" name="24[csvindex]" value="24"><input type="hidden" name="24[catg]" value="3"><input type="hidden" name="24[prop]" value="11"><input type="hidden" name="25[csvindex]" value="25"><input type="hidden" name="25[catg]" value="3"><input type="hidden" name="25[prop]" value="12"><input type="hidden" name="26[csvindex]" value="26"><input type="hidden" name="26[catg]" value="3"><input type="hidden" name="26[prop]" value="217"><input type="hidden" name="27[csvindex]" value="27"><input type="hidden" name="27[catg]" value="35"><input type="hidden" name="27[prop]" value="56"><input type="hidden" name="28[csvindex]" value="28"><input type="hidden" name="28[catg]" value="35"><input type="hidden" name="28[prop]" value="57"><input type="hidden" name="29[csvindex]" value="29"><input type="hidden" name="29[catg]" value="35"><input type="hidden" name="29[prop]" value="58"><input type="hidden" name="30[csvindex]" value="30"><input type="hidden" name="30[catg]" value="47"><input type="hidden" name="30[prop]" value="88"><input type="hidden" name="31[csvindex]" value="31"><input type="hidden" name="31[catg]" value="47"><input type="hidden" name="31[prop]" value="89"><input type="hidden" name="32[csvindex]" value="32"><input type="hidden" name="32[catg]" value="47"><input type="hidden" name="32[prop]" value="90"><input type="hidden" name="33[csvindex]" value="33"><input type="hidden" name="33[catg]" value="47"><input type="hidden" name="33[prop]" value="91"><input type="hidden" name="34[csvindex]" value="34"><input type="hidden" name="34[catg]" value="47"><input type="hidden" name="34[prop]" value="92"><input type="hidden" name="35[csvindex]" value="35"><input type="hidden" name="35[catg]" value="47"><input type="hidden" name="35[prop]" value="93"><input type="hidden" name="36[csvindex]" value="36"><input type="hidden" name="36[catg]" value="47"><input type="hidden" name="36[prop]" value="94"><input type="hidden" name="37[csvindex]" value="37"><input type="hidden" name="37[catg]" value="2"><input type="hidden" name="37[prop]" value="4"><input type="hidden" name="38[csvindex]" value="38"><input type="hidden" name="38[catg]" value="2"><input type="hidden" name="38[prop]" value="5"><input type="hidden" name="39[csvindex]" value="39"><input type="hidden" name="39[catg]" value="2"><input type="hidden" name="39[prop]" value="7"><input type="hidden" name="40[csvindex]" value="40"><input type="hidden" name="40[catg]" value="2"><input type="hidden" name="40[prop]" value="6"><input type="hidden" name="41[csvindex]" value="41"><input type="hidden" name="41[catg]" value="40"><input type="hidden" name="41[prop]" value="69"><input type="hidden" name="42[csvindex]" value="42"><input type="hidden" name="42[catg]" value="40"><input type="hidden" name="42[prop]" value="70"><input type="hidden" name="43[csvindex]" value="43"><input type="hidden" name="43[catg]" value="40"><input type="hidden" name="43[prop]" value="71"><input type="hidden" name="44[csvindex]" value="44"><input type="hidden" name="44[catg]" value="40"><input type="hidden" name="44[prop]" value="72"><input type="hidden" name="45[csvindex]" value="45"><input type="hidden" name="45[catg]" value="40"><input type="hidden" name="45[prop]" value="73"><input type="hidden" name="46[csvindex]" value="46"><input type="hidden" name="46[catg]" value="33"><input type="hidden" name="46[prop]" value="54"><input type="hidden" name="47[csvindex]" value="47"><input type="hidden" name="47[catg]" value="33"><input type="hidden" name="47[prop]" value="55"><input type="hidden" name="48[csvindex]" value="48"><input type="hidden" name="48[catg]" value="5"><input type="hidden" name="48[prop]" value="17"><input type="hidden" name="49[csvindex]" value="49"><input type="hidden" name="49[catg]" value="5"><input type="hidden" name="49[prop]" value="18"><input type="hidden" name="50[csvindex]" value="50"><input type="hidden" name="50[catg]" value="5"><input type="hidden" name="50[prop]" value="19"><input type="hidden" name="51[csvindex]" value="51"><input type="hidden" name="51[catg]" value="5"><input type="hidden" name="51[prop]" value="21"><input type="hidden" name="52[csvindex]" value="52"><input type="hidden" name="52[catg]" value="9"><input type="hidden" name="52[prop]" value="22"><input type="hidden" name="53[csvindex]" value="53"><input type="hidden" name="53[catg]" value="9"><input type="hidden" name="53[prop]" value="23"><input type="hidden" name="54[csvindex]" value="54"><input type="hidden" name="54[catg]" value="9"><input type="hidden" name="54[prop]" value="24"><input type="hidden" name="55[csvindex]" value="55"><input type="hidden" name="55[catg]" value="14"><input type="hidden" name="55[prop]" value="40"><input type="hidden" name="56[csvindex]" value="56"><input type="hidden" name="56[catg]" value="14"><input type="hidden" name="56[prop]" value="41"><input type="hidden" name="57[csvindex]" value="57"><input type="hidden" name="57[catg]" value="14"><input type="hidden" name="57[prop]" value="42">';
    document.forms[0].submit();
}

/**
 * Check whether parameter object title exists in CSV file.
 */
function object_title() {
    var l_counter = 0;
    while ($("catg_" + l_counter)) {
        if ($("catg_" + l_counter).value == 'object_title') {
            return true;
        }
        l_counter++;
    }
    return false;
}

function object_type() {
    var l_counter = 0,
            el;

    if ($('object_types').value != 0) {
        return true;
    } else {

        while (el = $('catg_' + l_counter)) {
            if (el.value == 'object_type_dynamic') {
                return true;
            }

            l_counter++;
        }
    }

    return false;
}

/**
 * Reset category/property matching.
 */
function reset_line(p_line) {
    var l_line = $("catg_" + p_line);
    l_line.selectedIndex = 0;
    l_line.parentNode.style.backgroundColor = 'white';
    l_line.parentNode.parentNode.cells[3].style.backgroundColor = 'white';

    if ($("prop_" + p_line)) {
        $("prop_" + p_line).update().disabled = true;
        if($("prop_" + p_line).next())
        {
            $("prop_" + p_line).next().remove();
        }
    }
}

function auto_match() {
    var l_counter = 0,
            l_catg,
            l_header,
            l_catg_header,
            l_prop_header;

    togglePreloadPage(true);

    while (l_catg = $("catg_" + l_counter))
    {
        l_header = l_catg.up('tr').down('td').innerHTML.split('-');

        l_catg_header = l_header[0];
        l_prop_header = l_header[1];

        if (l_header.length == 3) {
            l_prop_header = l_header[1] + "-" + l_header[2];
        }

        if (walk_sbox_catg(l_catg, l_catg_header) && $("prop_" + l_counter)) {
            load_properties(l_catg.value, l_counter, l_prop_header, true);
        } else {
            $('catg_' + l_counter).up().setStyle({backgroundColor: '#fff'});
            $('prop_' + l_counter).update().up().setStyle({backgroundColor: '#fff'});
            if($('prop_' + l_counter).next()){
                $('prop_' + l_counter).next().remove();
            }
        }

        l_counter++;
    }

    setTimeout("hide_overlay_after_ajax()", 5000);
}

function hide_overlay_after_ajax() {
    if (Ajax.activeRequestCount == 0) {
        togglePreloadPage();
    }
}

function walk_sbox_catg(p_sbox, p_catg) {
    var l_options = p_sbox.options,
            s_index;

    for (s_index = 0; s_index < p_sbox.options.length; s_index++)
    {
        if (p_sbox.options[s_index].text == p_catg) {
            p_sbox.options[s_index].selected = true;
            p_sbox.parentNode.style.backgroundColor = '#C2FFBC';
            return true;
        }
    }

    return false;
}

/**
 * DEP
 */
function walk_sbox_prop(p_sbox, p_prop) {
    var l_options = p_sbox.options,
            s_index;
    for (s_index  in  l_options) {
        if (p_sbox.options[s_index].text == p_prop) {
            p_sbox.options[s_index].selected = true;
            p_sbox.parentNode.style.backgroundColor = '#C2FFBC';
            return true;
        }
    }
    return false;
}


/**
 * Loads existing profiles and 
 * adds them to our selectbox
 * 
 * @param {type} p_id
 * @returns {undefined}
 */
function load_csvprofiles(p_id) {
    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_profiles', {
        method: 'post',
        onSuccess: function(transport) {
            if (transport.responseText) {
                $('profile_sbox').innerHTML = "";
                var l_profiles = transport.responseText.evalJSON();
                for (var prop in l_profiles) {
                    if (l_profiles.hasOwnProperty(prop)) {
                        $('profile_sbox').appendChild(new Element('option', {value: l_profiles[prop].id, 'data-profile': l_profiles[prop].data}).update(l_profiles[prop].title));
                    }
                }

                if (p_id) {
                    if (isNaN(p_id))
                        $('profile_sbox').selectedIndex = $('profile_sbox').options.length - 1;
                    else
                        $('profile_sbox').value = p_id;
                }
            } else {
                $('submit_error').innerHTML = '[{isys type="lang" ident="LC__UNIVERSAL__FILE_DOES_NOT_EXIST" p_bHtmlEncode="1"}]';
                $('submit_error').style.display = 'block';
            }
        }
    });
}


/**
 * Create/Overwrite a profile
 * 
 * @param {type} p_id
 * @returns {undefined}
 */
function save_profile(p_id) {

    if ($('profile_title').value == '' && isNaN(p_id))
        return idoit.Notify.error('[{isys type="lang" ident="LC__MODULE__IMPORT__CSV__MSG__SAVE_MSG_EMPTY"}]');
    
    var l_profileData = {
        title: $('profile_title').value + "  ("+$('csv_filename').value+")",
        data: {
            assignments: {},
            globalObjectType: null,
            identificationKeys: {},
            additionalPropertySearch: {}
        }
    };

    l_profileData.data.globalObjectType = $('object_types').value;

    $$('.catg').forEach(function(e, i) {
        l_profileData.data.assignments[i] = {
            category: e.value,
            property: $('prop_' + i).value
        };
        //l_profileData.data.propsearch[1] = ;
        if($('prop_search_'+i+'_'+$('prop_' + i).value))
        {
            l_profileData.data.additionalPropertySearch[i] = JSON.parse($('prop_search_'+i+'_'+$('prop_' + i).value).value);
        }
    })

    var l_identificators = $('identificators').children;
    var l_identificators_len = l_identificators.length;

    for(i = 1; i < l_identificators_len; i++)
    {
        l_first_select = l_identificators[i].down('select');
        l_second_select = l_first_select.next('select');
        l_profileData.data.identificationKeys[i-1] = {
            csvIdent: l_first_select.value,
            localIdent: l_second_select.value
        };
    }

    /* Save multuvalue-update-mode in profile */
    l_profileData.data.multivalueUpdateMode = $$('input:checked[type=radio][name=multivalue_mode]')[0].value;

    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=save_profile', {
        method: 'post',
        parameters: {
            profileData: JSON.stringify(l_profileData),
            profileID: p_id
        },
        onSuccess: function(transport) {
            if (isNaN(p_id))
                p_id = 'last';
            $('profile_title').value = "";
            load_csvprofiles(p_id);

        }
    });
}


/**
 * Load a selected profile
 * 
 * @returns {load_profile}
 */
function load_profile() {

    try {
        var l_option = $('profile_sbox').options[$('profile_sbox').selectedIndex].getAttribute('data-profile').evalJSON();

        /* Reset all lines */
        $$('#csv_assignment_table tbody tr').forEach(function(e, i) {
            reset_line(i);
        });

        var l_identificators = $('identificators').children;
        var l_identificators_len = l_identificators.length;

        if(l_identificators_len > 1)
        {

            for(i = l_identificators_len-1; i >= 1; i--)
            {
                l_identificators[i].remove();
            }
        }

        queue([
            /* Reset all identification keys */
            function(p_callback){
                var l_identificators = $('identificators').children;
                var l_identificators_len = l_identificators.length;
                if(l_identificators_len > 1)
                {
                    for(i = l_identificators_len; i >= 1; i--)
                    {
                        l_identificators[i].remove();
                    }
                }
                p_callback();
            },
            /* Reloads identification keys */
            function(p_callback){
                var ident_length = l_option.identificationKeys.length;
                var l_identificators = $('identificators').children;

                l_first_select_len = $('identificators_hidden').children[0].down('select').length;
                l_second_select_len = $('identificators_hidden').children[0].down('select').next('select').length;

                for(i = 0; i < ident_length; i++)
                {
                    var localIdent = l_option.identificationKeys[i].localIdent;
                    var csvIdent = l_option.identificationKeys[i].csvIdent;

                    add_new_identificator();
                    l_identificators = $('identificators').children;

                    l_first_select = l_identificators[i+1].down('select');
                    l_second_select = l_first_select.next('select');

                    for(j = 0; j < l_first_select_len; j++)
                    {
                        if(l_first_select[j].value == csvIdent)
                        {
                            l_first_select.selectedIndex = j;
                            break;
                        }
                    }
                    for(j = 0; j < l_second_select_len; j++)
                    {
                        if(l_second_select[j].value == localIdent)
                        {
                            l_second_select.selectedIndex = j;
                            break;
                        }
                    }
                }

                p_callback();
            },
            /* Reset all lines */
            function(p_callback) {
                $$('#csv_assignment_table tbody tr').forEach(function(e, i) {
                    reset_line(i);
                });

                p_callback();
            },
            function(p_callback) {
                /* Global objecttype handling */
                $('object_types').value = l_option.globalObjectType;
                if (!l_option.globalObjectType) {
                    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_categories', {
                        method: 'post',
                        parameters: {
                            multivalue: $('multivalue').value
                        },
                        onSuccess: function(transport) {
                            show_categories(transport.responseJSON);
                            p_callback();
                        }
                    });
                } else {
                    var l_loadAni = $('load')
                    l_loadAni.style.display = 'block';
                    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_specific_categories', {
                        method: 'post',
                        parameters: {
                            objecttypeID: l_option.globalObjectType,
                            multivalue: $('multivalue').value
                        },
                        onSuccess: function(transport) {
                            show_categories(transport.responseJSON);
                            l_loadAni.style.display = 'none';
                            p_callback();
                        }
                    });
                }
            },
            function(p_callback) {
                l_option.assignments.forEach(function(e, i) {
                    var p_catgID = e.category;
                    var p_property = e.property;
                    var p_index = i;

                    $('catg_' + p_index).value = p_catgID;

                    if (isNaN(p_catgID) == false) {
                        if (p_catgID != 0) {
                            var l_loadAni = $("load_prop_" + p_index);
                            l_loadAni.style.display = 'block';
                            new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=load_properties', {
                                method: 'post',
                                parameters: {
                                    catgID: p_catgID
                                },
                                onSuccess: function(transport) {
                                    if ($('csv_assignment_table').rows[p_index + 1].cells[2].style.backgroundColor == '#C2FFBC')
                                    {

                                        $('csv_assignment_table').rows[p_index + 1].cells[2].style.backgroundColor = 'white';
                                        $('csv_assignment_table').rows[p_index + 1].cells[3].style.backgroundColor = 'white';
                                    }
                                    if (transport.responseText != '')
                                    {
                                        /* ------------------------------------------------------ */
                                        var json = $H(transport.responseText.evalJSON());
                                        var target = $('prop_' + p_index).update('');
                                        var prop_index = null;
                                        var prop_additional_search = null;

                                        $("prop_" + p_index).stopObserving();
                                        if($('prop_' + p_index).next())
                                        {
                                            $('prop_' + p_index).next().remove();
                                        }

                                        json.each(function(e) {
                                            var option = new Element('option', {
                                                'value': e[0].replace(/\s/g, '')
                                            });

                                            if (e[1].search("[*]") != -1) {
                                                e[1] = e[1].replace("[*]", '');
                                                option.setStyle({backgroundColor: '#CADBFF'});
                                            }

                                            option.update(e[1]);

                                            target.insert(option);

                                            if (option.value == p_property)
                                            {
                                                option.setAttribute('selected', 'selected');
                                                prop_index = option.value;
                                            }

                                        }.bind(this));

                                        if(prop_index !== null)
                                        {
                                            if(l_option.additionalPropertySearch[p_index]){
                                                prop_additional_search = l_option.additionalPropertySearch[p_index];
                                            }
                                            add_additional_select(target, p_index, true, prop_additional_search);
                                        }
                                        /* ------------------------------------------------------ */
                                        $("prop_" + p_index).disabled = false;
                                    }
                                    else
                                    {
                                        $("prop_" + p_index).innerHTML = '';
                                    }

                                    l_loadAni.style.display = 'none';
                                },
                                onComplete: function() {
                                    if (Ajax.activeRequestCount == 1) {
                                        hide_overlay();
                                    }
                                    l_loadAni.style.display = 'none';
                                }
                            });
                        } else {
                            $("prop_" + p_index).disabled = true;
                            $("prop_" + p_index).innerHTML = '';
                        }
                    } else {
                        $("prop_" + p_index).disabled = true;
                        $("prop_" + p_index).innerHTML = '';
                    }
                });
                p_callback();
            },
            function(p_callback) {
                /* Load multivalue-update-mode */
                $$('input[type=radio][value='+l_option.multivalueUpdateMode+']')[0].checked=1;
                p_callback();
            },
            function() {
                idoit.Notify.success('[{isys type="lang" ident="LC__MODULE__IMPORT__CSV__MSG__LOAD"}]');
                $('profile_loaded').value = 1;
            }
        ])
    } catch (e) {
        idoit.Notify.error('[{isys type="lang" ident="LC__MODULE__IMPORT__CSV__MSG__LOAD_FAIL"}]');
    }
}

function delete_profile(p_id) {
    new Ajax.Request('?[{$smarty.const.C__GET__MODULE_ID}]=[{$smarty.const.C__MODULE__IMPORT}]&param=[{$smarty.const.C__IMPORT__GET__CSV}]&ajax=1&request=call_csv_handler&[{$smarty.const.C__CMDB__GET__CSV_AJAX}]=delete_profile', {
        method: 'post',
        parameters: {
            profileID: p_id
        },
        onSuccess: function(transport) {
            load_csvprofiles();
        }
    });
}

function add_new_identificator()
{
    if(!$('identificators').visible()) $('identificators').show();

    $('identificators').insert($('identificators_hidden').innerHTML);
}