<?php

/**
 * i-doit
 *
 * Hypergate
 *
 * Responsible for login, logout and general tasks
 *
 * @package    i-doit
 * @subpackage General
 * @copyright  synetics GmbH
 * @license    http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
global $g_comp_session, $g_comp_database, $g_comp_template, $g_comp_template_language_manager, $g_template;

// Login procedure.
if (isset($_POST['login_username']))
{
	// Load mandants template, because this is an ajax request.
	if (isset($_POST['login_submit']))
	{
		$g_template['start_page'] = 'content/mandants.tpl';
	} // if

	// Check if username and password was entered.
	if (empty($_POST['login_username']))
	{
		$l_error = 'No username specified!<br />';
	} else if (empty($_POST['login_password']))
	{
		$l_error = 'No password specified!<br />';
	} else
	{
		// Check if mandator ID is set.
		if (isset($_POST['login_mandant_id']))
		{
			// Instantiate $g_comp_database.
			if (($g_mandator_info = $g_comp_session->connect_mandator($_POST['login_mandant_id'])))
			{
				// Insert Session Entry to database.
				if ($g_comp_session->start_dbsession() != NULL)
				{
					$g_comp_session->delete_expired_sessions();

					// Do the real login.
					$l_loginres = $g_comp_session->login(
						$g_comp_database,
						$_POST['login_username'],
						$_POST['login_password'],
						false // Write new userID to session
					);

					if ($l_loginres)
					{
						unset($_GET["logout"]);

						// Prepare module request, because a module dao is needed in ->checkLicense method and $g_modman->init
						$g_modreq = isys_module_request::build(
							$g_menutree,
							$g_comp_template,
							$_GET,
							$_POST,
							isys_component_template_navbar::getInstance(),
							$g_comp_database,
							$g_modman
						);

						/* Check if licence check exists */
						if (class_exists('isys_ajax_handler_licence_check'))
						{
							$l_lic = new isys_ajax_handler_licence_check($_GET, $_POST);
							$l_lic->checkLicense();
						} // if

						$g_modman->init($g_modreq);
						$g_modman->module_loader();

						// Delete temp tables.
						try
						{
							$l_dao_tables = new isys_component_dao_table($g_comp_database);
							$l_dao_tables->clean_temp_tables();
						} catch (isys_exception_dao $l_e)
						{
							; // Ignore it...
						} // try

						// Update user's preferred language:
						$l_user_id      = $g_comp_session->get_user_id();
						$g_loc          = isys_locale::get($g_comp_database, $l_user_id);
						$l_old_language = intval($g_loc->get_setting(LC_LANG));

						if (empty($_POST['login_language']))
						{
							$l_error = 'Language not set. Please try again.';
						} else
						{
							$l_new_language = $g_loc->resolve_language_constant_by_short_tag($_POST['login_language']);

							if ($l_old_language !== $l_new_language)
							{
								if ($g_loc->set_setting(LC_LANG, $l_new_language) === false)
								{
									$l_error = sprintf('Login attempt failed. Language "%s" [%s] is not configured as valid locale.', $_POST['login_language'], $l_new_language);
								} else
								{
									$g_loc->save_settings($l_user_id);
								} // if
							} // if
						} // if
					} else
					{
						$l_error = "Login attempt failed. Please try again.";
					} // if
				} else
				{
					$l_error = "Could not add session to database.";
				} // if
			} else
			{
				$l_error = "Could not connect to mandator database.";
			} // if
		} else
		{
			// PREPARE MANDATOR LIST FOR LOGIN

			// Decode login information, because the login is an utf8 ajax request.
			$_POST["login_username"] = isys_glob_utf8_decode($_POST["login_username"]);
			$_POST["login_password"] = isys_glob_utf8_decode($_POST["login_password"]);

			// This block is executed after the initial login. User entered username password and we fetch the available mandantors for him now.
			$l_mandator_data = $g_comp_session->fetch_mandators($_POST["login_username"], $_POST["login_password"], false, true);

			if (count($l_mandator_data) > 0)
			{
				$l_mandants = array();
				$l_preferred_language = null;

				if (count($l_mandator_data) === 1)
				{
					$g_comp_template->assign('directlogin', true);
				} // if

				foreach ($l_mandator_data as $l_mandator)
				{
					$l_mandants[$l_mandator['id']] = isys_glob_utf8_decode($l_mandator['title']);
					$l_user_id                     = $l_mandator['user_id'];
					if($l_preferred_language === null)
					{
						$l_preferred_language = $l_mandator['preferred_language'];
					} // if
				} // foreach

				asort($l_mandants);

				// Show available mandators in SELECT and disable text fields.
				$g_comp_template
						->assign("mandant_options", $l_mandants)
						->assign("languages", $g_comp_template_language_manager->fetch_available_languages())
						->assign('preferred_language', $l_preferred_language);
			} // if

			$l_session_errors = $g_comp_session->get_errors();

			if (count($l_session_errors) > 0 && count($l_mandator_data) <= 0)
			{
				// Removed: Check for rights -> isys_rs_system
			} else
			{
				if (is_null($l_mandator_data))
				{
					$l_error = "No mandators found in system database!";
				} else if (count($l_mandator_data) == 0)
				{
					$l_error = "Invalid username or password!";

					// Clear all sessions, because this login failed!
					$g_comp_session->logout();
				} // if
			} // if

			// Reset intilized user locales for catching the ones from the right mandator.
			isys_locale::reset_cache();

			if (!isset($l_error))
			{
				// If no error occurred - load clients.
				$g_comp_template->fetch($g_template["start_page"], NULL, NULL, NULL, true);
				exit;
			} // if
		} // if
	} // if
} else if (!$g_comp_session->is_logged_in() && isys_settings::get('session.sso.active', false) && isys_settings::get('session.sso.mandator-id', '1') > 0 && (isset($_SERVER['REMOTE_USER']) && $_SERVER['REMOTE_USER'] != ''))
{
	if (isset($_GET['logout']))
	{
		/* Display SSO-Message after logout and prevent endless redirections */
		$l_error = "Re-Login with user: <a href='?'>" . $_SERVER['REMOTE_USER'] . "</a>";

	} else
	{
		if ($g_comp_session->connect_mandator(isys_settings::get('session.sso.mandator-id')))
		{
			if (is_object($g_comp_database))
			{
				$l_sso_user = $_SERVER['REMOTE_USER'];
				if (strstr($l_sso_user, '\\'))
				{
					$l_sso_user = substr($l_sso_user, 0, strpos($l_sso_user, '\\'));
				} elseif (strstr($l_sso_user, '@'))
				{
					$l_sso_user = substr($l_sso_user, 0, strpos($l_sso_user, '@'));
				}

				if ($l_sso_user)
				{
					$l_dao_user  = new isys_component_dao_user($g_comp_database);
					$l_userarray = $l_dao_user->get_user(NULL, $l_sso_user)->__to_array();

					if ($l_userarray)
					{
						$g_comp_session->delete_current_session();
						$g_comp_session->start_dbsession();

						if (!$g_comp_session->login(
							$GLOBALS['g_comp_database'],
							$l_sso_user,
							$l_userarray['isys_cats_person_list__user_pass'],
							true,
							true
						)
						)
						{
							$l_error = "Single sign on login failed. Either username (" . $l_sso_user . "), password or " .
									"mandator (" . isys_settings::get('session.sso.mandator-id') . ") information is not correct.";
						} else
						{
							/* Check and populate current licence */
							if (class_exists('isys_module_licence'))
							{
								$l_licence = new isys_module_licence();
								$l_licence->verify();
							} // if

							header('Location: index.php');
						}

						$g_comp_session->set_language(isys_settings::get('session.sso.language', 'en'));
					} else
					{
						$l_error = "Single-Sign-On User '" . $l_sso_user . "' not found in i-doit! Login manually.";

						// Clear all sessions, because this login failed!
						$g_comp_session->logout();
					} // if
				}
			} // if
		} // if
	} // if
} // if

// Logout.
if (isset($_GET["logout"]))
{
	if ($g_comp_session->is_logged_in())
	{
		$g_comp_session->logout();
		header('Location: ?logout');
	} // if
} // if
/**
 * --------------------------------------------------------------------------------------------------------------------------
 *
 * SHOW LOGIN PAGE IF NOT LOGGED IN
 *
 * --------------------------------------------------------------------------------------------------------------------------
 */

// If not logged in, show login dialog, otherwise forward to main include (i-doit.inc.php).
if (!$g_comp_session->is_logged_in())
{
	if (!isset($g_config['devmode']))
	{
		// Check for i-doit code / database version conflicts.
		$g_idoit      = new isys_component_dao_idoit($g_comp_database_system);
		$l_db_version = $g_idoit->get_version();
		if ($l_db_version != "" && $l_db_version != $g_product_info["version"] && $_GET["load"] != "update" && !isset($_POST["login_submit"]))
		{
			isys_glob_display_error("The version of your i-doit database does not match the version of your program code. Please update your databases to <strong>i-doit " . $g_product_info["version"] . "</strong> using the <a href=\"" . $g_config["www_dir"] . "updates\">updater</a> or revert/update your i-doit source code to version " . $l_db_version . ".<br /><br />System Database Version: " . $l_db_version . "<br />Source Code Version: " . $g_product_info["version"]);
			die;
		} // if
	}

	// Check for session timeouts.
	if ($_SESSION["session_data"]["isys_user_session__isys_obj__id"] > 0 && empty($l_error))
	{
		$l_login_header = "i-doit session manager";
		$l_error        = "Your session timed out! (<strong>" . $g_config["sess_time"] . "</strong> secs) <br />Login again, please.";
	} // if

	// User is not logged in.
	$g_comp_template->assign("bloggedIn", "false");

	// Destroy session, because the login attempt failed, or session is timed out.
	$g_comp_session->destroy();

	if (isset($l_error))
	{
		if ($l_login_header)
		{
			$g_comp_template->assign("login_header", $l_login_header);
		} // if

		$g_comp_template
				->assign("login_error", str_replace("'", "\'", $l_error))
				->display($g_template["start_page"]); // Display error.

		die;
	} else
	{
		$g_template["start_page"] = "main.tpl";
	} // if

	$index_includes = array("contentarea" => "content/login.tpl");
} else
{
	/**
	 * --------------------------------------------------------------------------------------------------------------------------
	 *
	 * USER IS LOGGED IN
	 *  - Get mandator cache
	 *  - initialize user settings
	 *
	 * --------------------------------------------------------------------------------------------------------------------------
	 */

	/* Restore mandator id on failure */
	if (!isset($_SESSION["user_mandator"]))
	{
		/* If there is no user mandator saved in users session, it could be
		   possible that it was unsetted. The
		   mandator-ID is restored here. :-) */
		$l_mandator = $g_comp_session->get_current_mandator_as_id();

		if ($l_mandator != NULL)
		{
			$_SESSION["user_mandator"] = $l_mandator;
		} // if
	} else
	{
        global $g_dirs;

		/* User is not logged in. Do some directory checks: */
		$g_cache_dirs = array(
			"temp"            => $g_absdir . "/temp",
			"file upload"     => $g_dirs["fileman"]["target_dir"],
			"image upload"    => $g_dirs["fileman"]["image_dir"],
			"template cache"  => $g_absdir . "/src/themes/default/smarty/templates_c"
		);

		$g_not_writable = array();
		foreach ($g_cache_dirs as $l_dir)
		{
			if (!is_writeable($l_dir))
			{
				$g_not_writable[] = $l_dir;
			}
		}

		if (count($g_not_writable) > 0)
		{
			isys_glob_display_error(
                "Temp/Cache Problem: The apache process is not able to write inside the following " .
                "temporary i-doit directories: <br /><br />" . implode(",<br />", $g_not_writable) .
                "<br /><br />" .
                "Please provide the appropriate permissions (e.g. \"chmod 777 path\").<br /><br />".
                "<button onclick=\"location.reload(true);\">Refresh</button>"
            );
			die;
		}
	}

	/**
	 * --------------------------------------------------------------------------------------------------------------------------
	 * HANDLE SESSION BASED STUFF
	 *  - Checks if a user is logged in and a mandator id is set in session
	 * --------------------------------------------------------------------------------------------------------------------------
	 */
	if ($g_comp_session->is_logged_in() && isset($_SESSION["user_mandator"]))
	{
		// Assign current mandant name.
		$g_mandator_name = isys_glob_get_mandant_name_as_string($_SESSION["user_mandator"]);

		$g_comp_session->start_dbsession();

		// Include mandator-specific constant cache.
		$l_dcm = new isys_component_constant_manager();

		// If not exist, create the constant file (so delete the cachefile to rebuild it).
		$l_dcm_file = $l_dcm->set_subdir($g_mandator_info["isys_mandator__dir_cache"]);

		if (!file_exists($l_dcm_file))
		{
			$l_dcm->create_dcm_cache();
		} // if

		include_once($l_dcm_file);

		// Load update engine.
		if (isset($_GET["load"]) && $_GET["load"] == "update")
		{
			include_once("updates/update.inc.php");
			die;
		} // if
	} // if

	/**
	 * Initialize user settings
	 */
	isys_usersettings::initialize($g_comp_database);
	isys_tenantsettings::initialize($g_comp_database);

	// Handle nag screen.
	if (class_exists('isys_module_licence'))
	{
		isys_module_licence::show_nag_screen();
	} // if

	if (!$g_comp_session->get_session_id())
	{
		$g_sessionid = $g_comp_session->get_session_id();
	} // if

	// Read session data.
	$_SESSION["session_data"] = $g_comp_session->get_session_data();

	if (is_array($_SESSION["session_data"]))
	{
		foreach ($_SESSION["session_data"] as $l_key => $l_val)
		{
			if (is_numeric($l_key))
			{
				unset($_SESSION["session_data"][$l_key]);
			} // if
		} // foreach
	} // if

	// Load Event manager.
	$g_mod_event_manager = isys_event_manager::getInstance();

	/* Assign navbar template */
	$index_includes['navbar'] = 'content/navbar/main.tpl';

	// User is logged in.
	include_once("i-doit.inc.php");

	// Show navbar.
	isys_component_template_navbar::getInstance()->show_navbar();

	// Assign infobox.
	if (!is_object($g_comp_template_infobox))
	{
		$g_comp_template_infobox = new isys_component_template_infobox();
	} // if

	if (!isset($_SESSION[isys_locale::C__SESSION_CACHE_KEY]['menu_width']))
	{
		$l_menu_width = $g_loc->get_setting('menu_width');
	} else
	{
		$l_menu_width = $_SESSION[isys_locale::C__SESSION_CACHE_KEY]['menu_width'];
	} // if

	// Assign the collected data.
	$g_comp_template
			->assign("g_mandant_name", isys_glob_utf8_decode($g_mandator_name))
			->assignByRef("infobox", $g_comp_template_infobox)
			->assign('menu_width', $l_menu_width);
} // if

// Show loaded and initialized modules.
if (isset($_GET['modules']) && isys_auth::factory(C__MODULE__SYSTEM)->is_allowed_to(isys_auth::SUPERVISOR, 'SYSTEM'))
{
	$g_modman->enum();
	$l_modules = $g_modman->get();
	ksort($l_modules);

	$g_comp_template
			->assign('init_modules', $g_modman->get_initialized_modules())
			->assign('modules', $l_modules);

	$index_includes = array("contentbottomcontent" => "content/modules.tpl");
} // if

// The hypergate is doing the final Smarty template processing.
$g_comp_template
		->assign("index_includes", $index_includes)
		->assign("config", $g_config); // Assign configuration

// Exception handling.
if (!empty($g_error))
{
	if (!is_object($g_error))
	{
		$g_error = str_replace("\\n", "<br />", $g_error);
	} // if

	$g_comp_template->assign("g_error", $g_error);
} // if

/**
 * --------------------------------------------------------------------------------------------------------------------------
 * PRINT OUT THE I-DOIT SITE
 * --------------------------------------------------------------------------------------------------------------------------
 */
if (!$g_output_done)
{
	$g_comp_template->assign("bugreport", array("referrer" => urlencode(base64_encode(($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING'])))));

	if (!empty($g_dirs["smarty"]))
	{
		if (!empty($g_template["start_page"]))
		{
			if (file_exists($g_dirs["smarty"] . "templates/" . $g_template["start_page"]))
			{
				global $g_comp_signals;

				$g_comp_signals->emit('system.gui.beforeRender');
				$g_comp_template->display("file:" . $g_dirs["smarty"] . "templates/" . $g_template["start_page"]);
				$g_comp_signals->emit('system.gui.afterRender');
			} else
			{
				isys_glob_display_error("Error: Template " . $g_dirs["smarty"] . "templates/" . $g_template["start_page"] . ' does not exist.');
			} // if
		} else
		{
			isys_glob_display_error("Error while displaying template: g_template[start_page] is not set!");
		} // if
	} else
	{
		isys_glob_display_error("Error while displaying template: g_dirs[smarty] is empty. " . "This could be a registry problem. Directories are located in registry key: " . "[Root]/System/Directories (\"isys_registry\" in system database)");
	} // if
} // if