<?php
/**
 * i-doit
 *
 * Call stylesheet data through cache/smarty.
 *
 * @package     i-doit
 * @subpackage  General
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
header("Content-Type: text/css");

global $g_dirs, $g_comp_signals;

// Read every file from this directory.
$l_dir = $g_dirs["css_abs"];

// Set CSS variables to use.
$g_comp_template
	->assign("dir_images", $g_dirs["images"])
	->assign("dir_theme_images", $g_dirs["theme_images"])
	->assign("gBrowser", _get_browser());

$g_comp_signals->emit('mod.css.beforeProcess');

/**
 * Cache lifetime of one week
 */
//isys_core::expire(isys_convert::WEEK);

try
{
	if (is_dir($l_dir))
	{
        $g_comp_template->loadFilter('output','TrimWhiteSpaceEnhanced');

		if (($l_dir_handle = opendir($l_dir)))
		{
			while ($l_filename = readdir($l_dir_handle))
			{
				if ($l_filename == 'print.css') {
					continue;
				}

				$l_filename_full = $l_dir . "/" . $l_filename;
				if (is_file($l_filename_full) && preg_match("/\.css$/i", $l_filename))
				{
					$l_out .= $g_comp_template->fetch($l_filename_full) . "\n";
				} // if
			} // while

			closedir($l_dir_handle);
		} // if
	}
	else
	{
		throw new isys_exception_filesystem('"' . $l_dir . '" is not a directory!', 'The given directory "' . $l_dir . '" is no directory or does not exist.');
	} // if
}
catch (isys_exception $l_e)
{
	die("Error while creating CSS: " . $l_e->getMessage());
} // try


// Output CSS.
header("Content-Type: text/css");

$g_comp_signals->emit('mod.css.processed', $l_out);

$l_attachCSS = $g_comp_signals->emit('mod.css.attachStylesheet');
if (is_array($l_attachCSS))
{
	foreach ($l_attachCSS as $l_css)
	{
		if (file_exists($l_css))
		{
			$l_out .= file_get_contents($l_css);
		}
	}
}

echo $l_out;
die;