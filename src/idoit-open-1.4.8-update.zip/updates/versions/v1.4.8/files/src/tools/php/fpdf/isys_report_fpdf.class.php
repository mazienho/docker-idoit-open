<?php
/**
 * PDF style class for Report Manager export.
 *
 * @package     i-doit
 * @subpackage  Reports
 * @author      Dennis Blümer <dbluemer@synetics.de>
 * @author      Steven Bohm <sbohm@synetics.de>
 * @copyright   Copyright 2007 - synetics GmbH
 */

require_once('src/tools/php/fpdf/fpdf.php');

class isys_report_fpdf extends FPDF
{
	/**
	 * Page header
	 */
	public function Header ()
	{
		// Arial bold 15.
		$this->SetFont('Arial', 'B', 15);

		// Title.
		$this->Cell(0, 10, "i-doit Report   -   " . $this->title, 1, 0, 'C');

		//Line break.
		$this->Ln(20);
	} // function


	/**
	 * Render the footer.
	 */
	public function Footer ()
	{
		// Position at 1.5 cm from bottom.
		$this->SetY(-15);

		// Arial italic 8.
		$this->SetFont('Arial', 'I', 8);

		// Page number.
		$this->Cell(0, 10, $this->PageNo() . '/{nb}', 0, 0, 'C');
	} // function


	/**
	 * Render the colored table.
	 *
	 * @param  array  $p_header
	 * @param  array  $p_data
	 */
	public function reportTable($p_header, $p_data)
	{
		// Colors, line width and bold font
	    $this->SetFillColor(204, 204, 204);
	    $this->SetTextColor(0, 0, 0);
	    $this->SetDrawColor(128, 128, 128);
	    $this->SetLineWidth(.3);
	    $this->SetFont('', 'B');
		$l_sum = 0;

        // Width of the cells.
        $l_header_width = array();

		foreach ($p_data as $l_row)
		{
			$i = 0;
			foreach ($l_row as $l_table => $l_value)
			{
				if (!preg_match("/^__[\w]+__$/i", $l_table))
				{
					$l_width = $this->GetStringWidth(_L($l_value)) + 5;

					if ($l_header_width[$i] < $l_width)
					{
						$l_header_width[$i] = $l_width;
					} // if

					$i++;
				} // if
			}
		}

	    // Header
	    for($i=0;$i<count($p_header);$i++) {
	        $this->Cell($l_header_width[$i], 7, $p_header[$i], 1, 0, 'C', 1);
	        $l_sum += strlen($p_header[$i])*10;
	    }
	    $this->Ln();

	    // Color and font restoration
	    $this->SetFillColor(250, 250, 250);
	    $this->SetTextColor(0);
	    $this->SetFont('');

	    $j = 0;
		foreach ($p_data as $l_row)
		{
			$i = 0;
			foreach ($l_row as $l_table => $l_value)
			{
				if (!preg_match("/^__[\w]+__$/i", $l_table))
				{
					$this->Cell($l_header_width[$i], 6, _L($l_value), 'LR', 0, 'L', 1);
					$i++;
				} // if
			} // foreach

			$this->Ln();

			if ($j % 2 != 0)
			{
				$this->SetFillColor(250, 250, 250);
			}
			else
			{
				$this->SetFillColor(238, 238, 238);
			} // if

			$j++;
		} // foreach

	    $this->Cell($l_sum, 0, '', 'T');
	} // function
} // class