<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage Components
 * @author     Van Quyen Hoang
 * @copyright  synetics GmbH
 */
class isys_rt_redirection
{
	// @todo  Check if this class is needed and maybe remove it.
}