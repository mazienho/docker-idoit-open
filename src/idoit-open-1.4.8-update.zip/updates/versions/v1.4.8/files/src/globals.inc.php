<?php
/**
 * i-doit
 *
 * Global definitions.
 *
 * This file provides basic functionalities needed by all source files.
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Andre Woesten <awoesten@i-doit.de>
 * @version     Dennis Stücken <dstuecken@i-doit.de>
 * @version     1.2
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
include_once('version.inc.php');

// Get localization class
include_once __DIR__ . '/locales.inc.php';

$g_config = array(
	"base_dir"          => $g_absdir . DIRECTORY_SEPARATOR,
	"www_dir"           => str_replace('src/jsonrpc.php', '', str_replace('index.php', '', @$_SERVER['SCRIPT_NAME'])),
	"override_host"     => false,
	"theme"             => "default",
	"theme_selectable"  => true,
	"startpage"         => "index.php",
	"smarty_debug_host" => 'localhost',
	"show_barcodes"     => true,
	"html-encoding"     => "utf-8",
	"ajax_calls"        => true
);

/**
 * @desc Directory configuration
 * -------------------------------------------------------------------------
 *       Array of required global directory structure, the rest is read
 *       and set by the system registry. NOTE: You should NOT modify this!
 *
 *       FILE MANAGER SETTINGS
 *
 *       Modify them in order to control the file manager, downloads and
 *       uploads. target_dir must be absolute and tailed by /, furthermore,
 *       your apache-user (normally www-data) needs full access rights (RWX)
 *       to this directory. temp_dir is /tmp/ on UNIX systems, otherwise
 *       configure it here manually for Win.
 *       The image_dir is used for the uploaded object images www-data needs also
 *       full access here
 */
$g_dirs = array(
	"css_abs"      => $g_config["base_dir"] . "src/themes/" . $g_config["theme"] . "/css/",
	"js_abs"       => $g_config["base_dir"] . "src/tools/js/",
	"temp"         => $g_config["base_dir"] . "temp/",
	"class"        => $g_config["base_dir"] . "src/classes/",
	"import"       => $g_config["base_dir"] . "src/classes/import/",
	"temp_www"     => $g_config["www_dir"] . "temp/",
	"images"       => $g_config["www_dir"] . "images/",
	"theme_images" => $g_config["www_dir"] . "src/themes/" . $g_config["theme"] . "/images/",
	"handler"      => $g_config["base_dir"] . "src/handler/"
);

// Global error/exception message.
$g_error = "";

// Active/Deactivate ajax calls.
$g_ajax_calls = true;

// Internal smarty/template config.
$g_template = array(
	"start_page" => "main.tpl",
	"ajax"       => "ajax.tpl"
);

/* ------------------------------------------------------------------------- */
/* -------------------------------------------- INCLUDE CLASS AUTOLOADER --- */
include_once("autoload.inc.php");
/* ------------------------------------------------------------------------- */
/* ---------------------------------------------- FUNCTIONS & CONSTANTS ---- */
include_once("functions.inc.php");
include_once("constants.inc.php");
include_once("assert.inc.php");
/* ------------------------------------------------------------------------- */
/* -------------------------------------------- INCLUDE CONVERTER CLASS ---- */
include_once("convert.inc.php");

// Get global converter.
$g_convert = new isys_convert();

/* ------------------------------------------------------------------------- */
/* -------------------------------------------------- GENERAL COMPONENTS --- */

/* Set custom warnings handler */
set_error_handler(array('isys_core', 'warning_handler'), E_WARNING);

// Available PDO drivers.
if (class_exists("PDO"))
{
	$g_pdo_drivers = PDO::getAvailableDrivers();
} else
{
	$g_pdo_drivers = array();
} // if

/* Create database connection for idoit_system */
try
{
	$g_comp_database_system = isys_component_database::get_database(
		$g_db_system["type"],
		$g_db_system["host"],
		$g_db_system["port"],
		$g_db_system["user"],
		$g_db_system["pass"],
		$g_db_system["name"]
	);

	// Initialize i-doit registry and configure data source.
	$g_comp_registry = new isys_component_dao_registry(
		$g_comp_database_system,
		"isys_registry",
		"isys_registry__id",
		"isys_registry__parentid",
		"isys_registry__key",
		"isys_registry__value",
		"isys_registry__deletable",
		"isys_registry__editable"
	);

	/**
	 * Initialize settings
	 */
	isys_settings::initialize($g_comp_database_system);

	/* Set default timezone */
	date_default_timezone_set(isys_settings::get('system.timezone', 'Europe/Berlin'));

	/* Attaches LDAP users automatically to these group ids (comma-separated)
		- Only one group is also possible
		- Only group IDs will work, e.g. 15 for admin. Contacts->Groups for more */
	define("C__LDAP__GROUP_IDS", isys_settings::get('ldap.default-group', '14'));

	/* Activate LDAP Debugging into i-doit/temp/ldap_debug.txt:
	   - http://doc.i-doit.org/wiki/LDAP#Debug */
	define("C__LDAP__DEBUG", (bool) isys_settings::get('ldap.debug', true)); // true/false

	/* Maximum  amount of objects which are loaded into the tree of the object browser,
	   the browser will not load at all if limit is reached. */
	define("C__TREE_MAX_OBJECTS", isys_settings::get('cmdb.object-browser.max-objects', 1500)); // Numeric value

	$g_config["sess_time"]      = isys_settings::get('session.time', 300);
	$g_config["forum"]          = isys_settings::get('gui.forum-link', 0);
	$g_config["show_proc_time"] = isys_settings::get('system.show-proc-time', 0);
	$g_config["wiki_url"]       = isys_settings::get('gui.wiki-url', '');
	$g_config["wysiwyg"]        = isys_settings::get('gui.wysiwyg', '1');
	$g_config["use_auth"]       = isys_settings::get('auth.active', '1');
	$g_config['devmode']        = isys_settings::get('system.devmode', '0');

	$g_dirs["fileman"] =
			array(
				"target_dir" => isys_settings::get('system.dir.file-upload', $g_config["base_dir"] . 'upload/files/'),
				"temp_dir"   => $g_config["base_dir"] . 'temp/',
				"image_dir"  => isys_settings::get('system.dir.image-upload', $g_config["base_dir"] . 'upload/images/')
			);

	/**
	 * (Workflow)-Notifications , HTML allowed
	 */
	/* Message for an outdated maintenance contract */
	define("C__WORKFLOW_MSG__MAINTENANCE",
	isys_settings::get('email.template.maintenance',
	                   "Your maintenance contract: %s timed out.\n\n" .
	                   "<strong>Contract information</strong>:\n" .
	                   "Start: %s\n" .
	                   "End: %s\n" .
	                   "Support-Url: %s\n" .
	                   "Contract-Number: %s\n" .
	                   "Customer-Number: %s"
	)
	);

	/**
	 * Password message
	 *
	 * Variables:
	 *    %FIRSTNAME%, %LASTNAME%, %PASSWORD%, %EMAIL%, %COMMENT%, %USERNAME%, %USERID%
	 */
	define("C__CONTACT_MSG__PASSWORD",
	isys_settings::get(
		'email.template.password',
		"Hello %FIRSTNAME% %LASTNAME%, \n\n" .
		"Your password has been changed to: %PASSWORD%\n" .
		"\n\n" .
		"Regards,\n" .
		"i-doit system"
	)
	);

} catch (Exception $e)
{
	isys_glob_display_error(stripslashes($e->getMessage()));
	die();
}

/* Read registry data */
$l_sysid_readlony = $g_comp_registry->__get("[Root]/Idoit/Constants/SYSID__READONLY");
$l_rack_desc      = $g_comp_registry->__get("[Root]/Idoit/Constants/RACK_GUI_DESCENDING");

/* SYS-ID Readonly? */
define("C__SYSID__READONLY", ($l_sysid_readlony == "1" || $l_sysid_readlony == "yes" || $l_sysid_readlony == "true") ? true : false);

/* Defines, if the rack gui positions are counted descending (true) or ascending (false) */
define("C__RACK_GUI_DESCENDING", ($l_rack_desc == "1") ? true : false);

/* How many chars should be visible in the infobox/logbook message (numeric) */
define("C__INFOBOX__LENGTH", $g_comp_registry->__get("[Root]/Idoit/Constants/INFOBOX__LENGTH", 150));

/* Default date format (php-dateformat: http://php.net/date) */
define("C__INFOBOX__DATEFORMAT", $g_comp_registry->__get("[Root]/Idoit/Constants/INFOBOX__DATEFORMAT", "d.m.Y H:i :"));

// Enable locking of datasets (objects)?
$l_lock_datasets = ($g_comp_registry->__get("[Root]/Idoit/Constants/LOCK__DATASETS", false) == "1") ? true : false;
define("C__LOCK__DATASETS", $l_lock_datasets);

// Timeout of locked datasets in seconds
define("C__LOCK__TIMEOUT", $g_comp_registry->__get("[Root]/Idoit/Constants/LOCK__TIMEOUT", 120));
define("C__TEMPLATE__COLORS", $g_comp_registry->__get("[Root]/Idoit/Constants/TEMPLATE__COLORS", 1));
define("C__TEMPLATE__COLOR_VALUE", $g_comp_registry->__get("[Root]/Idoit/Constants/TEMPLATE__COLOR_VALUE", "#cc0000"));
define("C__TEMPLATE__STATUS", $g_comp_registry->__get("[Root]/Idoit/Constants/TEMPLATE__STATUS", 0));
define("C__TEMPLATE__SHOW_ASSIGNMENTS", $g_comp_registry->__get("[Root]/Idoit/Constants/TEMPLATE__SHOW_ASSIGNMENTS", 1));

// Configurable list view, default preset.
$g_lists = array(
	"isys_cmdb_dao_list_objects_all"         => array(
		"object_id"       => "LC__UNIVERSAL__ID",
		"object_title"    => "LC__UNIVERSAL__TITLE",
		"object_location" => "LC__CMDB__CATG__LOCATION",
		"created"         => "LC__TASK__DETAIL__WORKORDER__CREATION_DATE",
		"updated"         => "LC__CMDB__LAST_CHANGE",
		"purpose"         => "LC__CMDB__CATG__PURPOSE",
		"cmdb_status"     => "CMDB-Status",
	),
	'isys_cmdb_dao_list_objects_layer_3_net' => array(
		'object_id'     => 'ID',
		'object_title'  => 'LC__UNIVERSAL__TITLE',
		'address_type'  => 'LC__CMDB__CATS__NET__TYPE',
		'address'       => 'LC__CMDB__CATG__NETWORK__ADDRESS',
		'address_range' => 'LC__CMDB__CATS__NET__DHCP_RANGE',
		'subnet'        => 'LC__CATP__IP__SUBNETMASK',
		'assigned_ips'  => 'LC__CMDB__CATG__NETWORK__ASS_IP',
		'cmdb_status'   => 'CMDB-Status',
	)
);

// Load list-view config, if exists.
if (file_exists($g_absdir . DIRECTORY_SEPARATOR . "src/config_lists.inc.php"))
{
	include_once($g_absdir . DIRECTORY_SEPARATOR . "src/config_lists.inc.php");
} // if

$l_dirres = $g_comp_registry->get_by_path("[Root]/System/Directories");

if (is_object($l_dirres) && $l_dirres->num_rows())
{
	$l_dirrow = $l_dirres->get_row();

	$l_dirres = $g_comp_registry->get_by_parentid(
		$g_comp_registry->get_id_by_array($l_dirrow)
	);

	while ($l_direntry = $l_dirres->get_row())
	{
		$l_key = $g_comp_registry->get_key_by_array($l_direntry);
		$l_dir = isys_glob_str_replace(
			$g_comp_registry->get_value_by_array($l_direntry),
			array(
			     "DIR_BASE" => $g_config["base_dir"],
			     "DIR_WWW"  => $g_config["www_dir"]
			)
		);

		$g_dirs[$l_key] = $l_dir;
	} // while
} else
{
	isys_glob_display_error("Could not find directory entries in registry!");
} // if

/* ------------------------------------------------------------------------- */
/* ----------------------------------------------------------- CONSTANTS --- */

// Include Global constant cache.
$g_dcs      = new isys_component_constant_manager();
$l_dcs_file = $g_dcs->set_subdir('');

if (!file_exists($l_dcs_file))
{
	/* Creates temp/const_cache.inc.php */
	$g_dcs->create_dcs_cache();
} // if

include_once($l_dcs_file);

/* ------------------------------------------------------------------------- */
/* ---------------------------------------------------------------- MISC --- */

// Initialize signal slot collection.
$g_comp_signals = isys_component_signalcollection::get_instance();

// Menutree.
$g_menutree = new isys_component_tree("menu_tree");

/* Load module manager */
$g_modman = isys_module_manager::instance();

/* ------------------------------------------------------------------------- */
/* ------------------------------------------------------- SESSION START --- */

// Do session management and initialize guest user.
if (class_exists('isys_module_ldap'))
{
	$g_comp_session = new isys_component_session(new isys_module_ldap());
} else
{
	$g_comp_session = new isys_component_session();
}

if ($g_comp_session->start_session())
{

	// Check for language change requests.
    if (file_exists($g_absdir . '/src/classes/modules/pro/'))
    {
        if (isset($_GET["lang"]) || isset($_POST["login_language"]))
        {
            $_GET["lang"] = (isset($_POST["login_language"])) ? $_POST["login_language"] : $_GET["lang"];
            if (strlen($_GET["lang"]) > 1)
            {
                $g_comp_session->set_language($_GET["lang"]);
            } // if
        } // if
    }
    else
    {
        $g_comp_session->set_language('en');
    }

	// Look if mandator is set yet and instantiate $g_comp_database for current mandator.
	if (isset($_SESSION["user_mandator"]))
	{
		$g_mandator_info = $g_comp_session->connect_mandator($_SESSION["user_mandator"]);
	} // if
	else $g_mandator_info = NULL;;

	// Initialize template language manager.
	$g_comp_template_language_manager = new isys_component_template_language_manager($g_comp_session->get_language());

	// Initialize Template library with SMARTY as backend.
	$g_comp_template = new isys_component_template($g_comp_template_language_manager);

	if ($g_mandator_info && is_object($g_comp_database))
	{

		/* ------------------------------------------------------------------------- */
		/* ------------------------------------------------ OVERRIDE USER CONFIG --- */
		$l_overrider = isys_glob_override_user_settings();

		/* ------------------------------------------------------------------------- */
		/* -------------------------------------------------------- BASE CLASSES --- */

		// Use quick safe without log comment or not:
		$l_save_mode = $g_comp_registry->{"[Root]/Idoit/General/Quicksave/b_showQuickSaveButton"} ? 'quick' : 'log';

		/* ------------------------------------------------------------------------- */
		/* ------------------------------------------------ INIT MODULE MANAGER ---- */

		// Prepare module request.
		$g_modreq = isys_module_request::build(
			$g_menutree,
			$g_comp_template,
			$_GET,
			$_POST,
			isys_component_template_navbar::getInstance(),
			$g_comp_database,
			$g_modman);

		$g_modman->init($g_modreq);
		$g_modman->module_loader();

		/* ------------------------------------------------------------------------- */

		// Obtain page limit from system registry.
		$g_page_limit = $g_comp_registry->{"[Root]/Idoit/Constants/int_pageLimit"};

		/**
		 * Show default tooltips in the navigation bar.
		 * @var $g_bDefaultTooltips bool
		 */
		$g_bDefaultTooltips = true;

		// Initialize navbar.
		$g_comp_template_navbar = isys_component_template_navbar::getInstance()
				->set_save_mode($l_save_mode);

		// Initialize infobox.
		$g_comp_template_infobox = new isys_component_template_infobox();

		// Global array for URL parameters which mustn't get deleted.
		$g_arSaveURLParameters = array(
			"mNavID",
			"SMARTY_DEBUG",
			"bvMode"
		);

		// Some global variables.
		$g_output_done = false;

		// Global variable for sanitizing input data
		$g_sanitize_data = $g_comp_registry->{"[Root]/Idoit/Constants/C__CMDB__SANITIZING"};
	} // if
	else
	{
		/* Initialize Pro module, if existent */
		if (file_exists(__DIR__ . '/classes/modules/pro/init.php'))
		{
			include_once(__DIR__ . '/classes/modules/pro/init.php');
		}
	}

	// Assign the default theme and the product info and some directories:
	$g_comp_template
			->assign("theme", $g_config["theme"])
			->assign("gProductInfo", $g_product_info)
			->assign("dir_tools", $g_config["www_dir"] . "src/tools/")
			->assign("dir_browser", $g_config["www_dir"] . "src/tools/browser/")
			->assign("dir_tree_images", $g_dirs["images"] . "dtree/")
			->assign("dir_images", $g_dirs["images"])
			->assign("dir_theme_images", $g_dirs["theme_images"])
			->assign("dir_theme", $g_dirs["theme"])
			->assign("dirs", $g_dirs)
			->assign("gLang", $g_comp_session->get_language());
} else
{
	$l_err = "Unable to start session !";
	if (headers_sent())
	{
		$l_err .= "<br />Headers already sent. There should not be any output before the session starts!";
	} // if

	isys_glob_display_error($l_err);
	die();
} // if

/* Instantiate a dummy class in case we are not logged in*/
if (!$g_loc)
{
    $g_loc = isys_locale::dummy();
}