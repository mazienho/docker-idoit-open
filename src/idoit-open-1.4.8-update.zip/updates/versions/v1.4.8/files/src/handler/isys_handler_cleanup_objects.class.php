<?php

/**
 * i-doit
 *
 * Handler: Cleanup objects
 *
 * @package     i-doit
 * @subpackage  Handler
 * @author      Van Quyen Hoang <qhoang@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
if (!isset($g_absdir))
{
	die("This program is a part of the i-doit framework and can't be executed standalone.");
} // if

class isys_handler_cleanup_objects extends isys_handler
{
	private function cleanup ($p_type)
	{
		global $g_comp_database;

		verbose("Starting cleanup... ");

		try
		{
			$l_module_system = isys_factory::get_instance('isys_module_system', $g_comp_database);
			$l_count = $l_module_system->cleanup_objects($p_type);

			verbose(sprintf(_L("LC__SYSTEM__REMOVE_BIRTH_OBJECTS_DONE"), $l_count));
		}
		catch (Exception $e)
		{
			throw new Exception($e);
		} // try

		verbose("Done", false, false);
	} // function


	public function init ()
	{
		global $argv;

		if (array_search('-t', $argv) === false)
		{
			echo "!! Missing Parameter !!\n" .
				"You have to use the following parameters to start the clean-up:\n\n" .
				"  -t  " . C__RECORD_STATUS__BIRTH . " for 'unfinished' objects, " . C__RECORD_STATUS__ARCHIVED . " for 'archived' objects and " . C__RECORD_STATUS__DELETED . " for 'deleted' objects.";
			return;
		} // if

		$l_slice = array_search('-t', $argv) + 1;
		$l_cmd = array_slice($argv, $l_slice);
		$l_type = trim($l_cmd[0]);

		verbose("Setting up system environment");

		try
		{
			$this->cleanup($l_type);
		}
		catch (Exception $e)
		{
			verbose($e->getMessage());
		} // try

		return true;
	} // function
} // class
?>