<?php
/**
 * i-doit
 *
 * Version definition
 *
 * @package     i-doit
 * @subpackage  General
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
$g_product_info = array
(
	"version" => "1.4.8",
	"step"    => '',
	"type"    => "OPEN"
);