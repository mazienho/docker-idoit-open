<?php

/**
 * i-doit
 *
 * System Controller
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Dennis Stücken <dstuecken@i-doit.de>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */

// Controller version.
define("VERSION", "1.0");

// Set error reporting.
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);

// Set maximal execution time.
set_time_limit(0);

// Reserve 256MB as maximal memory usage for this PHP session.
if ((int) ini_get("memory_limit") < 256)
{
	ini_set("memory_limit", "256M");
} // if

// Get current directory.
$g_absdir = dirname(__FILE__);
chdir($g_absdir);

if (substr(php_uname(), 0, 7 ) == "Windows")
{
	define("C__WINDOWS", true);
}
else
{
	define("C__WINDOWS", false);
} // if

// Bash colors.
define("C__COLOR__WHITE",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;37m");
define("C__COLOR__BLACK",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;30m");
define("C__COLOR__BLUE",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;34m");
define("C__COLOR__GREEN",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;32m");
define("C__COLOR__CYAN",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;36m");
define("C__COLOR__RED",				(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;31m");
define("C__COLOR__PURPLE",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;35m");
define("C__COLOR__BROWN",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;33m");
define("C__COLOR__LIGHT_GRAY",		(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0;37m");
define("C__COLOR__DARK_GRAY",		(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;30m");
define("C__COLOR__LIGHT_BLUE",		(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;34m");
define("C__COLOR__LIGHT_GREEN",		(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;32m");
define("C__COLOR__LIGHT_CYAN",		(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;36m");
define("C__COLOR__LIGHT_RED",		(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;31m");
define("C__COLOR__LIGHT_PURPLE",	(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;35m");
define("C__COLOR__YELLOW",			(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[1;33m");
define("C__COLOR__NO_COLOR",		(C__WINDOWS||$_SERVER["HTTP_HOST"])?"":"\033[0m");

// Console logos.
define("C__CONSOLE_LOGO__IDOIT", C__COLOR__WHITE . "i-do" . C__COLOR__LIGHT_RED . "it" . C__COLOR__NO_COLOR);

// This is plain text. And UTF-8.
header("Content-Type: text/plain");
header("Content-Type: UTF-8");

// Globalize g_controller.
$g_controller = NULL;

if (file_exists($g_absdir . "/src/config.inc.php"))
{
	// Get config file.
	include_once $g_absdir . "/src/config.inc.php";


	/**
	 * Display loading points (progress).
	 *
	 * @param  boolean  $p_newline
	 * @param  string   $p_str
	 */
	function loading($p_newline = false, $p_str=".")
	{
		if (defined("ISYS_VERBOSE"))
		{
			echo $p_str;

			if ($p_newline == true)
			{
				echo "\n";
			} // if
		} // if
	} // function


	/**
	 * Display message in verbose mode.
	 *
	 * @param  string   $p_message
	 * @param  boolean  $p_newline
	 * @param  string   $p_star
	 */
	function verbose($p_message, $p_newline = true, $p_star = "*")
	{
		if (defined("ISYS_VERBOSE"))
		{
			if ($p_newline)
			{
				if ($p_star != false)
				{
					echo "\n[" . $p_star . "] " . $p_message;
				}
				else
				{
					echo $p_message;
				} // if
			}
			else
			{
				echo $p_message;
			} // if
		} // if
	} // function


	/**
	 * Display error message and die
	 *
	 * @param  string  $p_message
	 */
	function error($p_message)
	{
		$l_message = "\n" . $p_message;

		if (!defined("ISYS_VERBOSE"))
		{
			$l_message .= "\nTry verbose mode to get more information (-v)\n";
		}

		echo $l_message;
		die();
	} // function


	/**
	 * Get product information
	 *
	 * @return  string
	 */
	function get_info()
	{
		return "i-doit cl-controller v" . VERSION . "\n\n";
	} // function


	/**
	 * Parse installed handlers and register them
	 *
	 * @global  array  $g_dirs
	 * @global  array  $g_controller
	 */
	function get_handlers()
	{
		global $g_dirs, $g_controller;

		if (!isset($g_controller["handler"]) || !is_array($g_controller["handler"]))
		{
			$g_controller["handler"] = array();
		} // if

		$l_dir = opendir($g_dirs["handler"]);
		if (is_resource($l_dir))
		{
			while ($l_file = readdir($l_dir))
			{
				if (is_file($g_dirs["handler"] . DIRECTORY_SEPARATOR . $l_file) && preg_match("/^(isys_handler_(.*))\.class\.php$/i", $l_file, $l_register))
				{
					$g_controller["handler"][$l_register[2]] = array("class" => $l_register[1]);
				} // if
			} // while
		} // if

		closedir($l_dir);
	} // function


	/**
	 * Get usage information
	 *
	 * @global  array  $g_controller
	 * @param   string  $p_message
	 * @return  string
	 */
	function get_usage($p_message = NULL)
	{
		global $g_controller;
		ksort($g_controller["handler"]);

		if (is_array($g_controller["handler"]))
		{
			$l_handlers = implode(', ', array_keys($g_controller["handler"]));
		}
		else
		{
			$l_handlers = "Currently there are no handlers installed.";
		} // if

		$l_usage = get_info();

		if (!empty($p_message))
		{
			$l_usage .= $p_message . "\n\n";
		} // if

		return "Usage: " . $_SERVER["PHP_SELF"] . " [OPTION] [PARAMETERS]\n" .
				"e.g.:  " . $_SERVER["PHP_SELF"] . " -v -m workflow\n" .
				"Options:\n" .
				"  -m HANDLER   Load handler HANDLER module.\n" .
				"  -u username  i-doit username\n" .
				"  -p password  i-doit password\n" .
				"  -i mandator  ID of mandator to connect to\n" .
				"  -h           This help text\n" .
				"  -v           Verbose mode\n" .
				"  -d           Displays ALL debug messages\n" .
				"\n" .
				"HANDLER can be one of the following availlable handlers:\n" .
				$l_handlers . "\n";
	} // function

	// Globalize _get and _post variables.
	$g_get  = $_GET;
	$g_post = $_POST;

	// Get globals.
	include_once("src/globals.inc.php");

	global $g_comp_session;

	try
	{
		// Get available handler modules and make them accessable in $g_controller["handler"].
		get_handlers();

        // @todo May be removed because session is already initiated via globals.inc.php.
        if (($g_comp_session instanceof isys_component_session) === false) {
		    $g_comp_session = new isys_component_session();
        } //if

		// Works only if handler specific options are not in between these options
		$l_opt = getopt("u:p:i:vm:hd");

        // Because i-doit's XML import uses this controller in the WebGUI (WTF?) getopt will fail:
        if ($l_opt === false) {
            // Enforce empty array:
            $l_opt = array();
        } //if

		if (isset($g_get["load"]))
		{
			$g_load = $g_get["load"];

			if (isset($g_get["verbose"]))
			{
				define("ISYS_VERBOSE", true);
			} // if

			if (!isset($argv))
			{
				$argv = array();
			} // if
		}
		else if (isset($argv))
		{
            /*
			$l_new_opt = $l_new_argv = array();
			// Controller options which are only usable for the controller
			$l_controller_options = array('u', 'p', 'i', 'v', 'm', 'h', 'd');

			// Separate controller options and handler options
			foreach($argv AS $l_key => $l_val)
			{
				if($l_key === 0) continue;

				if($l_val == '-v' || $l_val == '-d' || $l_val == '-h')
				{
					$l_new_opt[str_replace('-', '', $l_val)] = true;
				}
				elseif(strpos($l_val, '-') === 0 || in_array($l_val, $l_controller_options))
				{
					$l_opt_key = str_replace('-', '', $l_val);
					// Last element
					if(!isset($argv[$l_key+1]))
					{
						$l_new_argv[] = $l_opt_key;
					} // if
				}
				elseif($l_opt_key && in_array($l_opt_key, $l_controller_options))
				{
					$l_new_opt[$l_opt_key] = $l_val;
					unset($l_opt_key);
				}
				else
				{
					if(isset($l_opt_key))
					{
						$l_new_argv[] = $l_opt_key;
					} // if
					$l_new_argv[] = $l_val;
				} // if
			} // foreach
			$l_opt = $l_new_opt;
			$argv = $l_new_argv;
            */

			if (isset($l_opt["d"]))
			{
				define("ISYS_DEBUG", true);
			} // if

			$g_load = $l_opt["m"];

			if (isset($l_opt["u"]) && !isset($l_opt["p"]))
			{
				$l_error = ("The password cannot be empty! Define a password with -p in order to login.");
			} // if

            // Remove login info from arguments.
			$l_test = strtolower(implode(" ", array_slice($argv, 1)));
			$l_test = preg_replace('/\-u[ ]?\w* /', '', $l_test);
			$l_test = preg_replace('/\-p[ ]?\w* /', '', $l_test);
			$l_test = preg_replace('/\-i[ ]?[0-9]* /', '', $l_test);
			$l_test = preg_replace('/\-v /', '', $l_test);
			$l_test = preg_replace('/\-m[ ]?[a-z]+[ ]?/', '', $l_test);
			$argv = explode(" ", $l_test);
		}
		else
		{
			die("Missing parameter: 'load'.");
		} // if

		// Encapsulate handler.
		$l_handler_class = $g_controller["handler"][$g_load]["class"];
		$g_handler_config = $g_dirs["handler"] . "config/" . $l_handler_class . ".inc.php";

		// If handler config exists, include it.
		if (file_exists($g_handler_config))
		{
			include_once $g_handler_config;
		} // if

		if (isset($l_opt["v"]) && !defined('ISYS_VERBOSE'))
		{
			define("ISYS_VERBOSE", true);
		} // if

		if (isset($g_userconf['user']) && isset($g_userconf['pass']))
		{
			$l_opt = $l_opt + array(
					'u' => $g_userconf['user'],
					'p' => $g_userconf['pass'],
					'i' => $g_userconf['mandator_id'],
				);
		}

		if (isset($l_opt["u"]) && !isset($l_opt["p"]))
		{
			$l_error = ("The password cannot be empty! Define a password with -p in order to login.");
		} // if

		if (isset($l_opt["u"]) && !isset($l_opt["i"]))
		{
			if (C__WINDOWS)
			{
				$l_mandator_exec = "php.exe controller.php -v -m mandator";
			}
			else
			{
				$l_mandator_exec = "./mandator";
			} // if

			$l_error = ("Don't forget to specify your mandator id (-i). You can view the current ids with \"".$l_mandator_exec." ls\"\n");
		} // if

		if (isset($l_opt["u"]) && isset($l_opt["p"]) && !isset($l_error))
		{
			verbose('Logging in..');
			$g_comp_session->weblogin($l_opt['u'], $l_opt['p'], $l_opt['i']);
			verbose("Connected to mandator: " . $g_userconf["mandator_id"] . " (" . $g_comp_session->get_mandator_name() . ")" . PHP_EOL);
		} // if

        global $g_comp_database;
		// Initialize module manager.
		$g_modman = isys_module_manager::instance();
		$g_modman->init(isys_module_request::build(
			new isys_component_tree("menu_tree"),
			new isys_component_template(),
			$_GET,
			$_POST,
			isys_component_template_navbar::getInstance(),
			$g_comp_database,
			$g_modman
		));
		$g_modman->module_loader(true);

		if (empty($l_handler_class))
		{
			$l_handler_class = $g_controller["handler"][$g_load]["class"];
			$g_handler_config = $g_dirs["handler"] . "config/" . $l_handler_class . ".inc.php";
		}

		if (isset($l_error))
		{
			error($l_error);
		} // if

		if (!$g_load)
		{
			die(get_usage());
		} // if

		$g_mandator = $l_opt["i"];
	}
	catch (Exception $e)
	{
		verbose($e->getMessage());
	} // try

	try {
		// Include handler.
		if (@class_exists($l_handler_class))
		{
			// Get handler class.
			$l_object = new $l_handler_class();

			if ($l_object->needs_login() && !$g_comp_session->is_logged_in())
			{
				error("Login failed.\n");
			} // if

	        // Get faked module request.
			$l_menutree	= new isys_component_tree("menu_tree");
	        $g_active_modreq = isys_module_request::build(
	            $l_menutree,
	            $g_comp_template,
	            $_GET,
	            $_POST,
	            isys_component_template_navbar::getInstance(),
	            $g_comp_database,
	            isys_module_manager::instance());

	        // Include mandator-specific constant cache.
	        $g_dcm = new isys_component_constant_manager();

			if ($g_comp_session->is_logged_in())
			{
				// Load mandator specific cache.
				$g_comp_session->include_mandator_cache();

				if (!isys_auth::factory(C__MODULE__SYSTEM)->is_allowed_to(isys_auth::EXECUTE, 'CONTROLLERHANDLER/'.strtoupper($l_handler_class)))
				{
					throw new isys_exception_auth('No rights to execute controller handler \''.$g_load.'\'.');
				}

			} // if

			// Include constants.
			include_once($g_dcm->get_fullpath_name());

			// Initialize handler.
			$l_object->init();
		}
		else
		{
			die(get_usage("Handler: " . $g_load . " is not installed."));
		} // if
	}
	catch (Exception $e)
	{
		die($e->getMessage());
	}
}
else
{
	die(C__COLOR__RED . $g_absdir."/src/config.inc.php not found.".C__COLOR__NO_COLOR."\nYou need to install i-doit first.\n");
} // if