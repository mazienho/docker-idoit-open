<?php
/**
 * @author      Dennis Stuecken
 * @package     i-doit
 * @subpackage  General
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */

/**
 * @param  $p_tenant_id
 */
function connect_mandator($p_tenant_id)
{
	global $g_comp_database, $l_dao_mandator, $l_licence_mandator, $g_db_system;

	$l_licence_mandator = $l_dao_mandator->get_mandator($p_tenant_id, 0);
	$l_dbdata           = $l_licence_mandator->get_row();

	// Create connection to mandator DB.
	$g_comp_database = isys_component_database::get_database(
		$g_db_system["type"],
		$l_dbdata["isys_mandator__db_host"],
		$l_dbdata["isys_mandator__db_port"],
		$l_dbdata["isys_mandator__db_user"],
		$l_dbdata["isys_mandator__db_pass"],
		$l_dbdata["isys_mandator__db_name"]
	);
} // function

/**
 * Install a module zip file.
 *
 * @param   string  $p_moduleFile
 * @param   string  $p_tenant    Input '0' for all.
 * @throws  Exception
 * @return  boolean
 */
function install_module($p_moduleFile, $p_tenant = '0')
{
	global $g_absdir, $g_product_info, $l_dao_mandator, $g_comp_database_system, $g_comp_database,$g_dcs;
	$l_module_manager = new isys_module_manager();
	$l_db_update      = new isys_update_xml();
	$l_files          = new isys_update_files();

	// Checking for zlib and the ZipArchive class to solve #4853
	if (class_exists("ZipArchive") && extension_loaded('zlib'))
	{
		if ($l_files->read_zip($p_moduleFile, $g_absdir, false, true))
		{
			if (file_exists($g_absdir . '/package.json'))
			{
				$l_package   = json_decode(file_get_contents($g_absdir . '/package.json'), true);
				$l_tenants = array();

				if (isset($l_package['requirements']['core']))
				{
					$l_requirements = explode(' ', $l_package['requirements']['core']);

					if (!isset($l_requirements[1]))
					{
						throw new Exception('Invalid package.json format. Could not read requirements');
					} // if

					$l_current_version     = $g_product_info['version'];
					$l_version_requirement = $l_requirements[1];
					$l_operator            = $l_requirements[0];

					if (!version_compare($l_current_version, $l_version_requirement, $l_operator))
					{
						switch ($l_requirements[0])
						{
							case '>=':
								throw new Exception(sprintf('Error: i-doit Version requirement for this module does not match: Core %s. Update to version %s and try again.', $l_package['requirements']['core'], $l_requirements[1]));
								break;
							case '<=':
								throw new Exception(sprintf('Error: i-doit Version requirement for this module does not match: Core %s. Update to version %s and try again.', $l_package['requirements']['core'], $l_requirements[1]));
								break;
						} // switch
					} // if
				}
				else
				{
					throw new Exception('Invalid package.json format. Core requirement missing');
				} // if

				if (isset($l_package['dependencies']['php']) && is_array($l_package['dependencies']['php']))
				{
					foreach ($l_package['dependencies']['php'] as $l_dependency)
					{
						if (!extension_loaded($l_dependency))
						{
							throw new Exception(sprintf('Error: PHP extension %s needed for this module. Please install the extension and try again.', $l_dependency));
						} // if
					} // foreach
				} // if

				// Prepare mandator array.
				if ($p_tenant != '0')
				{
					$l_tenants = array($p_tenant);
				}
				else
				{
					$l_tenant_result = $l_dao_mandator->get_mandator();

					while ($l_row = $l_tenant_result->get_row())
					{
						$l_tenants[] = $l_row['isys_mandator__id'];
					} // while
				} // if

				// Include module installscript if available.
				if (file_exists($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install/isys_module_' . $l_package['identifier'] . '_install.class.php'))
				{
					include_once($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install/isys_module_' . $l_package['identifier'] . '_install.class.php');
				} // if

				// Delete files if necessary.
				if (file_exists($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install/update_files.xml'))
				{
					$l_files->delete($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install');
				} // if

				// Iterate through prepared mandators and install module into each of them.
				foreach ($l_tenants as $l_tenant)
				{
					// Connect mandator database $g_comp_database.
					connect_mandator($l_tenant);

					// Install module with package.
					$l_module_id = $l_module_manager->install($l_package);

					// Update Databases.
					if (file_exists($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install/update_data.xml'))
					{
						$l_db_update->update_database($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install/update_data.xml', $g_comp_database);
					} // if

					if (file_exists($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install/update_sys.xml'))
					{
						$l_db_update->update_database($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/install/update_sys.xml', $g_comp_database_system);
					} // if

					// Call module installscript if available.
					$l_installclass = 'isys_module_' . $l_package['identifier'] . '_install';
					if (class_exists($l_installclass))
					{
						// When a package.json already exists, this is an update.
						if (file_exists($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/package.json'))
						{
							$p_installtype = 'update';
						}
						else
						{
							$p_installtype = 'install';
						} // if

						call_user_func_array(array($l_installclass, 'init'), array($g_comp_database, $g_comp_database_system, $l_module_id, $p_installtype));
					} // if
				} // foreach

				// Move package.
				if (!file_exists($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/package.json'))
				{
					rename($g_absdir . '/package.json', $g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/package.json');
				}
				else
				{
					unlink($g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/package.json');
					rename($g_absdir . '/package.json', $g_absdir . '/src/classes/modules/' . $l_package['identifier'] . '/package.json');
				} // if

				// Delete cache.
				$l_deleted = array();
				$l_undeleted = array();
				isys_glob_delete_recursive($g_absdir . '/temp/', $l_deleted, $l_undeleted);

				// Re-Create constant cache.
				$g_dcs = new isys_component_constant_manager();
				$g_dcs->set_subdir('');
				$g_dcs->create_dcs_cache();
			}
			else
			{
				throw new Exception('Error: package.json was not found.');
			} // if
		}
		else
		{
			throw new Exception('Error: Could not read zip package.');
		}
	}
	else
	{
		throw new Exception('Error: Could not extract zip file. Please check, if the zip and zlib PHP extensions are installed.');
	} // if

	return true;
} // function