<?php

/**
 * AJAX
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Van Quyen Hoang <qhoang@i-doit.org>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       1.0
 */
class isys_ajax_handler_dragbar extends isys_ajax_handler
{
	/**
	 * Init method, which gets called from the framework.
	 *
	 * @global  isys_component_database $g_comp_database
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function init ()
	{
		global $g_comp_database;

		switch ($_GET['func'])
		{
			default:
			case 'save_menu_width':
				$l_menu_width = $_POST['menu_width'];

				isys_factory::get_instance('isys_component_dao_user', $g_comp_database)->set_user_menu_width($l_menu_width);

				$_SESSION[isys_locale::C__SESSION_CACHE_KEY]['menu_width'] = $l_menu_width;
				break;
		} // switch

		$this->_die();
	} // function
} // class