<?php

/**
 * AJAX
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       0.9.9-9
 */
class isys_ajax_handler_validate_field extends isys_ajax_handler
{
	/**
	 * Init method, which gets called from the framework.
	 *
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function init()
	{
		// We set the header information because we don't accept anything than JSON.
		header('Content-Type: application/json');

		$l_return = array();

		switch ($_GET['m'])
		{
			case 'validate':
				$l_return = $this->validate();
				break;

			case 'get_mandatory_fields':
				$l_return = $this->get_mandatory_fields();
				break;

			case 'get_validation_by_category':
				$l_return = $this->get_validation_by_category($_POST['cat_type'], $_POST['cat_id']);
				break;

			case 'create_mandatory_rule':
				$l_return = $this->create_mandatory_rule($_POST['cat_type'], $_POST['cat_id'], $_POST['property']);
				break;

			case 'remove_mandatory_rule':
				$l_return = $this->remove_mandatory_rule($_POST['cat_type'], $_POST['cat_id'], $_POST['property']);
				break;

			case 'create_validation_rule':
				$l_return = $this->create_validation_rule($_POST['cat_type'], $_POST['cat_id'], $_POST['property'], $_POST['validation_method']);
				break;

			case 'update_additional_validation':
				$l_return = $this->update_validation_rule($_POST['cat_type'], $_POST['cat_id'], $_POST['property'], $_POST['validation_additional']);
				break;

			case 'remove_validation_rule':
				$l_return = $this->remove_validation_rule($_POST['cat_type'], $_POST['cat_id'], $_POST['property']);
				break;

			case 'reset_validation_cache':
				$l_return = $this->reset_validation_cache();
				break;
		} // switch

		// Output the result.
		echo isys_format_json::encode($l_return);

		// And die, since this is a ajax request.
		$this->_die();
	} // function

	/**
	 * Method for validating a value of
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function validate()
	{
		list($l_dao_name, $l_prop) = explode('::', $_POST['identifier']);

		if (!empty($_POST['category']))
		{
			// Yeah... This happens on the overview page.
			$l_prop_id = $l_dao_name;
			$l_dao_name = $_POST['category'];
		}

		$l_value = trim($_POST['element_value']);

		$l_return = array(
			'error' => false,
			'message' => 'Nothing to validate'
		);

		if (class_exists($l_dao_name))
		{
			$l_dao = new $l_dao_name($this->m_database_component);

			if (method_exists($l_dao, 'validate_property'))
			{
				// This might happen on the overview-page.
				if ($l_prop === null)
				{
					$l_properties = $l_dao->get_properties();

					foreach ($l_properties as $l_key => $l_property)
					{
						if ($l_property[C__PROPERTY__UI][C__PROPERTY__UI__ID] == $l_prop_id)
						{
							$l_prop = $l_key;

							break;
						} // if
					} // foreach
				} // if

				$l_validated = $l_dao->validate_property($l_prop, $l_value);

				$l_return = array(
					'error' => false,
					'message' => 'Success'
				);

				if ($l_validated !== true)
				{
					$l_return = array(
						'error' => true,
						'message' => isys_glob_utf8_encode($l_validated)
					);
				} // if
			} // if
		}
		else
		{
			$l_return = array(
				'error' => false,
				'message' => 'DAO class could not be found'
			);
		} // if

		return $l_return;
	} // function


	/**
	 * This method returns an array of the mandatory fields from the given elements.
	 * The element needs a certain format: 'dao_class_name::property_key'.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function get_mandatory_fields()
	{
		$l_return = array();
		$l_elements = explode(',', $_POST['elements']);
		$l_already_called_dao = array();

		foreach ($l_elements as $l_element)
		{
			$l_dao_name = current(explode('::', $l_element));

			if (! in_array($l_dao_name, $l_already_called_dao) && class_exists($l_dao_name))
			{
				$l_already_called_dao[] = $l_dao_name;

				// We use the factory, so we don't always create new instances of the same class (inside the foreach).
				$l_dao = isys_factory_cmdb_category_dao::get_instance($l_dao_name, $this->m_database_component);
				$l_properties = $l_dao->get_properties(C__PROPERTY__WITH__VALIDATION);

				foreach ($l_properties as $l_property)
				{
					if ($l_property[C__PROPERTY__CHECK][C__PROPERTY__CHECK__MANDATORY])
					{
						$l_return[] = $l_property[C__PROPERTY__UI][C__PROPERTY__UI__ID];
					} // if
				} // foreach
			} // if
		} // foreach

		return $l_return;
	} // function


	/**
	 * Retrieves the properties with validation rules.
	 *
	 * @param   integer  $p_cat_type
	 * @param   integer  $p_cat_id
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function get_validation_by_category($p_cat_type, $p_cat_id)
	{
		try
		{
			$l_property_names = array();
			$l_properties = isys_factory_cmdb_category_dao::get_instance_by_id($p_cat_type, $p_cat_id, $this->m_database_component)->get_properties();

			foreach ($l_properties as $l_property => $l_property_data)
			{
				$l_property_names[$l_property] = isys_glob_utf8_encode(_L($l_property_data[C__PROPERTY__INFO][C__PROPERTY__INFO__TITLE]));
			}

			$l_validation_row = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_validation', $this->m_database_component)
				->get_data(null, $p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's')
				->get_row();

			$l_return = array(
				'success' => true,
				'data' => array(
					'rules' => $l_validation_row['isys_validation_config__json'],
					'properties' => $l_property_names
				)
			);
		}
		catch (Exception $e)
		{
			$l_return = array(
				'success' => false,
				'message' => $e->getMessage()
			);
		} // try

		return $l_return;
	} // function


	/**
	 * Method for defining a property as mandatory field.
	 *
	 * @param   integer  $p_cat_type
	 * @param   integer  $p_cat_id
	 * @param   string   $p_property
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function create_mandatory_rule($p_cat_type, $p_cat_id, $p_property)
	{
		try
		{
			$l_validation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_validation', $this->m_database_component);

			$l_validation_row = $l_validation_dao
				->get_data(null, $p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's')
				->get_row();

			$l_rules = isys_format_json::decode($l_validation_row['isys_validation_config__json']);
			$l_rules[$p_property][C__PROPERTY__CHECK][C__PROPERTY__CHECK__MANDATORY] = true;
			$l_rules = isys_format_json::encode($l_rules);

			$l_return = array(
				'rules' => $l_rules,
				'success' => $l_validation_dao->save($p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's', $l_rules)
			);
		}
		catch (Exception $e)
		{
			$l_return = array(
				'success' => false,
				'message' => $e->getMessage()
			);
		} // try

		return $l_return;
	} // function


	/**
	 * Method for removing a properties mandatory rule.
	 *
	 * @param   integer  $p_cat_type
	 * @param   integer  $p_cat_id
	 * @param   string   $p_property
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function remove_mandatory_rule($p_cat_type, $p_cat_id, $p_property)
	{
		try
		{
			$l_validation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_validation', $this->m_database_component);

			$l_validation_row = $l_validation_dao
				->get_data(null, $p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's')
				->get_row();

			$l_rules = isys_format_json::decode($l_validation_row['isys_validation_config__json']);
			unset($l_rules[$p_property][C__PROPERTY__CHECK][C__PROPERTY__CHECK__MANDATORY]);

			// If this property has no more rules, we can remove it.
			if (count($l_rules[$p_property][C__PROPERTY__CHECK]) === 0)
			{
				unset($l_rules[$p_property]);
			} // if

			$l_rules = isys_format_json::encode($l_rules);

			$l_return = array(
				'rules' => $l_rules,
				'success' => $l_validation_dao->save($p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's', $l_rules)
			);
		}
		catch (Exception $e)
		{
			$l_return = array(
				'success' => false,
				'message' => $e->getMessage()
			);
		} // try

		return $l_return;
	} // function


	/**
	 * Method for defining a property as mandatory field.
	 *
	 * @param   integer  $p_cat_type
	 * @param   integer  $p_cat_id
	 * @param   string   $p_property
	 * @param   string   $p_validation_method
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function create_validation_rule($p_cat_type, $p_cat_id, $p_property, $p_validation_method)
	{
		$l_properties = isys_factory_cmdb_category_dao::get_instance_by_id($p_cat_type, $p_cat_id, $this->m_database_component)->get_properties();

		if (! $l_properties[$p_property][C__PROPERTY__PROVIDES][C__PROPERTY__PROVIDES__VALIDATION])
		{
			return array(
				'success' => false,
				'message' => isys_glob_utf8_encode(_L('LC__SETTINGS__CMDB__VALIDATION__CREATION_ERROR'))
			);
		} // if

		try
		{
			$l_validation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_validation', $this->m_database_component);

			$l_validation_row = $l_validation_dao
				->get_data(null, $p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's')
				->get_row();

			$l_rules = isys_format_json::decode($l_validation_row['isys_validation_config__json']);
			$l_rules[$p_property][C__PROPERTY__CHECK][C__PROPERTY__CHECK__VALIDATION] = array($p_validation_method, array());
			$l_rules = isys_format_json::encode($l_rules);

			$l_return = array(
				'rules' => $l_rules,
				'success' => $l_validation_dao->save($p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's', $l_rules)
			);
		}
		catch (Exception $e)
		{
			$l_return = array(
				'success' => false,
				'message' => $e->getMessage()
			);
		} // try

		return $l_return;
	} // function


	/**
	 * @param   integer  $p_cat_type
	 * @param   integer  $p_cat_id
	 * @param   string   $p_property
	 * @param   string   $p_validation_additional
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function update_validation_rule($p_cat_type, $p_cat_id, $p_property, $p_validation_additional)
	{
		$l_properties = isys_factory_cmdb_category_dao::get_instance_by_id($p_cat_type, $p_cat_id, $this->m_database_component)->get_properties();

		if (! $l_properties[$p_property][C__PROPERTY__PROVIDES][C__PROPERTY__PROVIDES__VALIDATION])
		{
			return array(
				'success' => false,
				'message' => isys_glob_utf8_encode(_L('LC__SETTINGS__CMDB__VALIDATION__CREATION_ERROR'))
			);
		} // if

		try
		{
			$l_validation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_validation', $this->m_database_component);

			$l_validation_row = $l_validation_dao
				->get_data(null, $p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's')
				->get_row();

			$l_rules = isys_format_json::decode($l_validation_row['isys_validation_config__json']);
			$l_rules[$p_property][C__PROPERTY__CHECK][C__PROPERTY__CHECK__VALIDATION][1]['options']['regexp'] = $p_validation_additional;
			$l_rules = isys_format_json::encode($l_rules);

			$l_return = array(
				'rules' => $l_rules,
				'success' => $l_validation_dao->save($p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's', $l_rules)
			);
		}
		catch (Exception $e)
		{
			$l_return = array(
				'success' => false,
				'message' => $e->getMessage()
			);
		} // try

		return $l_return;
	} // function


	/**
	 * Method for removing a properties validation rule.
	 *
	 * @param   integer  $p_cat_type
	 * @param   integer  $p_cat_id
	 * @param   string   $p_property
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function remove_validation_rule($p_cat_type, $p_cat_id, $p_property)
	{
		try
		{
			$l_validation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_validation', $this->m_database_component);

			$l_validation_row = $l_validation_dao
				->get_data(null, $p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's')
				->get_row();

			$l_rules = isys_format_json::decode($l_validation_row['isys_validation_config__json']);
			unset($l_rules[$p_property][C__PROPERTY__CHECK][C__PROPERTY__CHECK__VALIDATION]);

			// If this property has no more rules, we can remove it.
			if (count($l_rules[$p_property][C__PROPERTY__CHECK]) === 0)
			{
				unset($l_rules[$p_property]);
			} // if

			$l_rules = isys_format_json::encode($l_rules);

			$l_return = array(
				'rules' => $l_rules,
				'success' => $l_validation_dao->save($p_cat_id, ($p_cat_type == C__CMDB__CATEGORY__TYPE_GLOBAL) ? 'g' : 's', $l_rules)
			);
		}
		catch (Exception $e)
		{
			$l_return = array(
				'success' => false,
				'message' => $e->getMessage()
			);
		} // try

		return $l_return;
	} // function


	/**
	 * Method for resetting the validation cache.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function reset_validation_cache()
	{
		try
		{
			isys_module_cmdb::create_validation_cache();

			return array(
				'success' => true,
				'message' => _L('LC_UNIVERSAL__SAVED')
			);
		}
		catch (Exception $e)
		{
			return array(
				'success' => false,
				'message' => $e->getMessage()
			);
		} // try
	} // function
} // class
?>