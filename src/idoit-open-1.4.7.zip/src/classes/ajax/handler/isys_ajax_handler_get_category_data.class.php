<?php

/**
 * AJAX
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Leonard Fischer <lfischer@i-doit.org>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       0.9.9-8
 */
class isys_ajax_handler_get_category_data extends isys_ajax_handler
{
	/**
	 * Init method, which gets called from the framework.
	 *
	 * @global  isys_component_database  $g_comp_database
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function init()
	{
		// We set the header information because we don't accept anything than JSON.
		header('Content-Type: application/json');

		$l_return = array();

		switch ($_GET['func'])
		{
			case 'get_data':
				$l_return = $this->get_data();
			break;

			case 'get_properties_by_database':
				$l_return = $this->get_properties_by_database();
			break;

			case 'get_property_keys_and_names':
				$l_return = $this->get_property_keys_and_names();
			break;

			case 'is_property_sortable':
				$l_return = $this->is_property_sortable();
			break;

			case 'get_categories':
				$l_return = $this->get_categories();
			break;

			case 'format_preselection':
				$l_return = $this->format_preselection();
			break;
		} // switch

		echo isys_format_json::encode($l_return);
		$this->_die();
	} // function

	/**
	 * Rebuilds selected properties to a readable format for the property selector
	 * @return array
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	protected function format_preselection()
	{
		global $g_comp_database;
		$l_dao = new isys_smarty_plugin_f_property_selector($g_comp_database);
		return $l_dao->handle_preselection(isys_format_json::decode($_POST['data']));
	} // function

	/**
	 * Get global / specific categories for the property selector
	 * @return array
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	protected function get_categories()
	{
		global $g_comp_database;
		$l_dao = new isys_smarty_plugin_f_property_selector($g_comp_database);
		$l_return = array(
			'catg' => $l_dao->get_catg($_POST['provides'], $_POST['dynamic_properties'], $_POST['consider_rights']),
			'cats' => $l_dao->get_cats($_POST['provides'], $_POST['dynamic_properties'], $_POST['consider_rights']),
			'catg_custom' => $l_dao->get_catg_custom($_POST['provides'], $_POST['dynamic_properties'], $_POST['consider_rights'])
		);
		return $l_return;
	} // function

	/**
	 * Get-data method.
	 *
	 * It is possible to pass the following parameters per post:
	 *    catsID (int)
	 *    catgID (int)
	 *    objID (int)
	 *    condition (string)
	 *
	 * @global  isys_component_database  $g_comp_database
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function get_data()
	{
		global $g_comp_database;

		$l_dao = new isys_cmdb_dao($g_comp_database);

		$l_return = array();

		// We look, if we are selecting a specific or global category.
		if (isset($_POST[C__CMDB__GET__CATS]))
		{
			$l_get_param 	= C__CMDB__GET__CATS;
			$l_cat_suffix	= 's';
		}
		else
		{
			$l_get_param = C__CMDB__GET__CATG;
			$l_cat_suffix	= 'g';
		} // if

		$l_cat_id = $_POST[$l_get_param];
		$l_object_id = (int) $_POST[C__CMDB__GET__OBJECT];
		$l_condition = $_POST['condition'];

		// Get category info.
		$l_isysgui = $l_dao->get_isysgui('isysgui_cat' . $l_cat_suffix, $l_cat_id)->__to_array();

		// Check class and instantiate it.
		if (class_exists($l_isysgui['isysgui_cat' . $l_cat_suffix . '__class_name']))
		{
			/**
			 * IDE typehinting.
			 * @var  $l_cat  isys_cmdb_dao_category
			 */
			if (($l_cat = new $l_isysgui['isysgui_cat' . $l_cat_suffix . '__class_name']($g_comp_database)))
			{
				// Check if the get_data method exists.
				if (method_exists($l_cat, 'get_data'))
				{
					if (isset($l_condition))
					{
						$l_catdata = $l_cat->get_data(null, null, $l_condition);
					}
					else
					{
						$l_catdata = $l_cat->get_data(null, $l_object_id);
					} // if

					if ($l_catdata->num_rows() > 0)
					{
						while ($l_row = $l_catdata->get_row())
						{
							$l_return[] = $l_row;
						} // while
					} // if
				} // if
			} // if
		} // if

		return $l_return;
	} // function

	/**
	 * Retrieve the properties by the isys_property_2_cat table.
	 *
	 * @global  isys_component_database  $g_comp_database
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function get_properties_by_database()
	{
		$l_dao = new isys_cmdb_dao_category_property($this->m_database_component);

		$l_return = array();
		$l_dynamic_properties = $_POST['dynamic_properties'];
		$l_allowed_prop_types = explode(',', $_POST['allowed_prop_types']);
		$l_consider_rights = ($_POST['consider_rights'] == 'true')? true: false;
		$l_replace_dynamic_properties = $_POST['replace_dynamic_properties'];

		$l_res = $l_dao->retrieve_properties(
			null,
			null,
			null,
			$_POST['provide'],
			'AND isys_property_2_cat__cat_const = ' . $l_dao->convert_sql_text($_POST['cat_const']),
			$l_dynamic_properties);

		$l_keys = array();

		while ($l_row = $l_res->get_row())
		{
			$l_property = unserialize($l_row['data']);
			$l_property_type = $l_property[C__PROPERTY__INFO][C__PROPERTY__INFO__TYPE];

			// This can be used to display only types like "text" or "dialog", ...
			if (count($l_allowed_prop_types) > 0 && !empty($l_allowed_prop_types[0]) && $l_consider_rights && !in_array($l_property_type, $l_allowed_prop_types))
			{
				continue;
			} // if

			// Also skip the "HR" and "HTML" fields of custom categories.
			if ($_POST['cat_type'] == 'g_custom' && (strpos($l_row['key'], 'hr_c_') === 0 || strpos($l_row['key'], 'html_c_') === 0))
			{
				continue;
			} // if

			if($l_replace_dynamic_properties && $l_row['type'] == C__PROPERTY_TYPE__DYNAMIC )
			{
				$l_search_key = substr($l_row['key'], 1);
				if(array_key_exists($l_search_key, $l_keys))
				{
					unset($l_return[$l_keys[$l_search_key]]);
				} // if
			} // if

			$l_return[$l_row['key'] . '#' . $l_row['id'] . '#' . $l_property_type] = isys_glob_utf8_encode(_L($l_row['title']));
			$l_keys[$l_row['key']] = $l_row['key'] . '#' . $l_row['id'] . '#' . $l_property_type;
		} // while

		asort($l_return);

		return $l_return;
	} // function


	/**
	 * Method for loading all property keys and their translated names by a given category-constant.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function get_property_keys_and_names()
	{
		$l_return = array();
		$l_props = $this->get_properties_by_database();

		foreach ($l_props as $l_prop_key => $l_prop_name)
		{
			if (!empty($l_prop_name))
			{
				$l_return[] = $l_prop_name . ': "' . current(explode('#', $l_prop_key)) . '"';
			} // if
		} // foreach

		return $l_return;
	} // function

	/**
	 * This method checks if a property is sortable or not
	 *
	 * @return bool
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	protected function is_property_sortable()
	{
		$l_prop_id = $_POST['prop_id'];
		$l_dao = new isys_cmdb_dao_category_property($this->m_database_component);
		$l_prop_arr = $l_dao->retrieve_properties($l_prop_id, null, null, null, '', true)->__to_array();
		$l_property = unserialize($l_prop_arr['data']);
		$l_return = false;

		if($l_property[C__PROPERTY__PROVIDES][C__PROPERTY__PROVIDES__LIST] &&
			($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DATE || $l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__TEXT ||
				(($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DIALOG ||
					(isset($l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]) && $l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]['p_strPopupType'] == 'dialog_plus')) &&
					isset($l_property[C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES][0])
				)))
		{
			if($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DIALOG ||
				(isset($l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]) && $l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]['p_strPopupType'] == 'dialog_plus') ||
				($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DATE && $l_property[C__PROPERTY__PROVIDES][C__PROPERTY__PROVIDES__LIST]))
			{
				$l_return = true;
			} else{
				if(!isset($l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]['p_strPopupType']) &&
					!isset($l_property[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK]) &&
					!isset($l_property[C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES])
				)
				{
					$l_return = true;
				}
			}
		} elseif($l_prop_arr['const'] == 'C__CATG__GLOBAL'){
			$l_return = true;
		}

		return $l_return;
	}

} // class
?>