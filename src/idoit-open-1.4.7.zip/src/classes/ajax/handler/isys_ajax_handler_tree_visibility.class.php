<?php
/**
 * AJAX updates tree visibility for object type tree and category tree
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Van Quyen Hoang <qhoang@synetics.de>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_ajax_handler_tree_visibility extends isys_ajax_handler
{
	/**
	 * Initialization for this AJAX request.
	 *
	 * @global  isys_component_database  $g_comp_database
	 */
	public function init ()
	{
		global $g_comp_database;

		$l_dao = new isys_component_dao_user($g_comp_database);

		$l_settings = $l_dao->get_user_settings()->get_row();

		if (isset($l_settings['isys_user_ui__tree_visible']))
		{
			$_POST['C__CATG__OVERVIEW__TREE_VISIBILTY'] = $l_settings['isys_user_ui__tree_visible'] + $_POST['C__CATG__OVERVIEW__TREE_VISIBILTY'];

			$l_dao->save_settings(C__SETTINGS_PAGE__REFERENCES, $_POST, false);
		} // if

		$this->_die();
	} // function
} // class