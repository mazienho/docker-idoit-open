<?php
/**
 * AJAX
 *
 * @package     i-doit
 * @subpackage  General
 * @author      Dennis Stücken <dstuecken@synetics.de>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_ajax_handler_tree extends isys_ajax_handler
{
	/**
	 * Initialization for this AJAX request.
	 *
	 * @global  isys_component_template $g_comp_template
	 * @global  isys_component_database $g_comp_database
	 */
	public function init ()
	{
		global $g_comp_template, $g_comp_database;

		$l_dao = new isys_component_dao_user($g_comp_database);

		if ($_GET[C__CMDB__GET__TREEMODE] != C__WF__VIEW__TREE)
		{
			$l_dao->save_settings(
				C__SETTINGS_PAGE__SYSTEM,
				array('C__CATG__OVERVIEW__DEFAULT_TREEVIEW' => $_GET[C__CMDB__GET__TREEMODE]),
				false);
		} // if

		// At this point we need to select the previously saved option to assign it to the template.
		$l_settings = $l_dao->get_user_settings()->get_row();

		$g_comp_template
			->assign('treeType', $l_settings['isys_user_locale__default_tree_type'])
			->display("file:" . $this->m_smarty_dir . "templates/ajax/tree_left.tpl");

		$this->_die();
	} // function


	/**
	 * Method which defines, if the hypergate needs to be run.
	 *
	 * @return  boolean
	 */
	public static function needs_hypergate ()
	{
		return true;
	} // function
} // class