<?php
/**
 * AJAX
 *
 * @package i-doit
 * @subpackage General
 * @author GR <gr@synetics.de>
 * @version 1.0
 * @copyright synetics GmbH
 * @license http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_ajax_handler_search_table extends isys_ajax_handler
{

	public static function needs_hypergate()
	{
		return true;
	}

	public function init()
	{
		global $g_comp_template;
		global $g_comp_template_language_manager;

		$l_search = new isys_module_search();

		if (($l_search_list = $l_search->get_search_list()))
		{
			if (isset($_POST['C__SEARCH_TEXT']))
			{
				$g_comp_template->display("search/result_list.tpl");
			} else
			{
				$g_comp_template->display("search/response_container.tpl");
			}
		}
		else
		{
			$l_arSearchCounter = array("var" => 0);
			echo $g_comp_template_language_manager->get('LC_SEARCH__RESULTS_FOUND', $l_arSearchCounter);
		}
		$this->_die();

		return true;
	}
}

?>