<?php

/**
 * i-doit
 *
 * API model
 *
 * @package    i-doit
 * @subpackage API
 * @author     Dennis Stücken <dstuecken@synetics.de>
 * @copyright  synetics GmbH
 * @license    http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_api_model_cmdb_category
    extends isys_api_model_cmdb
    implements isys_api_model_interface
{

    /**
     * Possible options and their parameters
     *
     * @var array
     */
    protected $m_options = array(
        'read' => array()
    );

    /**
     * Validation
     *
     * @var array
     */
    protected $m_validation = array();

    /**
     * Data formatting used in format methods
     *
     * @var array
     */
    protected $m_mapping = array();

    /**
     * Category type: global, specific or custom
     *
     * @var int
     */
    protected $m_category_type = NULL;

    /**
     * Field which includes the content
     *
     * @var string
     */
    protected $m_content_field = NULL;

    /**
     * Category id
     *
     * @var int
     */
    protected $m_category_id = NULL;

    /**
     * Category suffix
     *
     * @var string
     */
    protected $m_category_suffix = NULL;

    /**
     * Category get-param
     *
     * @var string
     */
    protected $m_category_get = NULL;

    /**
     * Category info from isysgui
     *
     * @var array
     */
    protected $m_category_info = NULL;

    /**
     * Category DAO
     *
     * @var isys_cmdb_dao_category
     */
    protected $m_category_dao = NULL;

    /**
     * Category source table
     *
     * @var string
     */
    protected $m_category_source_table = NULL;

    /**
     * Constructor
     *
     * @param \isys_cmdb_dao $p_dao
     */
    public function __construct(isys_cmdb_dao &$p_dao)
    {
        $this->m_dao = $p_dao;
        parent::__construct();
    } // function

    /**
     * Read category data
     *
     * $p_param structure:
     *    array (
     *        'objID'        => 1,
     *        'catgID'    => 10
     *    )
     *
     * or
     *    array(
     *        'objID'        => 1,
     *        'catsID'    => 12
     *    )
     *
     * @param array $p_params
     *
     * @throws isys_exception_api
     * @return array
     */
    public function read($p_params)
    {
        // Init
        $l_return    = array();
        $i           = 0;
        $l_object_id = @$p_params[C__CMDB__GET__OBJECT];

        // Validate object id
        if (!$l_object_id || $l_object_id < 1)
        {
            throw new isys_exception_api('Object id invalid. ID must be positive and higher than one.', -32602);
        } // if

        // Process data
        if (($l_cat = $this->prepare($p_params)))
        {
            if (method_exists($l_cat, 'get_data'))
            {
                // Status-Handling
                if (isset($p_params['status']))
                {
                    $l_status = is_numeric($p_params['status']) ?
                        $p_params['status'] :
                        (defined($p_params['status']) ?
                            constant($p_params['status']) :
                            NULL);
                }
                else
                {
                    $l_status = C__RECORD_STATUS__NORMAL;
                } // if

                // Condition-Handling and retrieve data
                if (isset($p_params['condition']))
                {
                    $l_catentries = $l_cat->get_data_as_array(
                        NULL,
                        addslashes($l_object_id),
                        urldecode($p_params['condition']),
                        NULL,
                        $l_status
                    );
                }
                else
                {
                    $l_catentries = $l_cat->get_data_as_array(
                        NULL,
                        addslashes($l_object_id),
                        NULL,
                        NULL,
                        $l_status
                    );
                } // if

                // Count category result
                if (count($l_catentries))
                {
                    if (!isset($p_params['raw']) || !$p_params['raw'])
                    {
                        $l_properties = $l_cat->get_properties();

                        // Get content field
                        $l_content_field = $this->get_content_field();

                        // Format category result
                        foreach ($l_catentries AS $l_row)
                        {
                            // Set object and category entry id
                            $l_return[$i]['id']    = $l_row[$this->get_category_source_table('__id')];
                            $l_return[$i]['objID'] = $l_row[$this->get_category_source_table('__isys_obj__id')];

                            // Property-Handling
                            foreach ($l_properties AS $l_key => $l_propdata)
                            {
                                if (is_string($l_key))
                                {
                                    if (isset($l_propdata[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]) &&
                                        isset($l_propdata[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1])
                                    )
                                    {

                                        // Call helper object to retrieve more information
                                        if (class_exists($l_propdata[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0]))
                                        {

                                            $l_helper = new $l_propdata[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0](
                                                $l_row,
                                                $this->m_dao->get_database_component(),
                                                $l_propdata[C__PROPERTY__DATA],
                                                $l_propdata[C__PROPERTY__FORMAT]
                                            );

                                            // Set the Unit constant for the convert-helper
                                            if ($l_propdata[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] == 'convert')
                                            {
                                                if (method_exists($l_helper, 'set_unit_const'))
                                                {
                                                    $l_row_unit = $l_properties[$l_propdata[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__UNIT]][C__PROPERTY__DATA][$l_content_field];
                                                    $l_helper->set_unit_const($l_row[$l_row_unit]);
                                                } // if
                                            } // if

                                            // Call callback
                                            $l_return[$i][$l_key] = call_user_func(
                                                array(
                                                    $l_helper,
                                                    $l_propdata[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1]
                                                ),
                                                $l_row[$l_propdata[C__PROPERTY__DATA][$l_content_field]]
                                            );

                                            // Set data id
                                            $p_params['data']['id'] = $this->get_category_id();

                                            // Retrieve data from isys_export_data
                                            if ($l_return[$i][$l_key] instanceof isys_export_data)
                                            {
                                                $l_export_data = $l_return[$i][$l_key];

                                                /** @var isys_export_data $l_export_data */
                                                $l_return[$i][$l_key] = $l_export_data->get_data();
                                            } // if
                                        } // if

                                    }
                                    else
                                    {
                                        $l_return[$i][$l_key] = $l_row[$l_propdata[C__PROPERTY__DATA][$l_content_field]];
                                    } // if

                                    unset($l_helper_class, $l_helper);
                                } // if
                            } // foreach
                            $i++;
                        } // foreach

                    }
                    else
                    {
                        $l_return = $l_catentries;
                    } // if
                } // if

            }
            else
            {
                throw new isys_exception_api('get_data method does not exist for ' . get_class($l_cat), -32601);
            } // if
        } // if

        return $l_return;
    } // function

    /**
     * Prepare api request
     *
     * @param array $p_params
     *
     * @throws isys_exception_api
     * @return bool|isys_cmdb_dao_category
     */
    protected function prepare($p_params)
    {
        // Get category params
        list($l_get_param, $l_cat_suffix) = $this->prepare_category_params($p_params);

        $this->set_category_suffix($l_cat_suffix);

        // Convert constant to ID
        if (is_string($p_params[$l_get_param]) && defined($p_params[$l_get_param]))
        {
            $p_params[$l_get_param] = constant($p_params[$l_get_param]);
        } // if

        $l_isysgui = array();

        // Get category info
        if (is_numeric($p_params[$l_get_param]))
        {
            $l_isysgui = $this->m_dao->get_isysgui('isysgui_cat' . $l_cat_suffix, (int)$p_params[$l_get_param])
                                     ->__to_array();

            $this->set_category_id($p_params[$l_get_param]);
        } // if

        // Category exists?
        if (count($l_isysgui))
        {
            $this->set_category_info($l_isysgui);

            // Set source table
            if ($this->is_global())
            {
                $this->set_category_source_table($l_isysgui["isysgui_cat{$l_cat_suffix}__source_table"] . '_list');
            }
            else
            {
                $this->set_category_source_table($l_isysgui["isysgui_cat{$l_cat_suffix}__source_table"]);
            } // if

            // Check class and instantiate it
            if (class_exists($l_isysgui["isysgui_cat{$l_cat_suffix}__class_name"]))
            {

                $_GET[$l_get_param] = $this->get_category_id();

                // Set category DAO
                if (($l_cat = new $l_isysgui["isysgui_cat{$l_cat_suffix}__class_name"]($this->m_dao->get_database_component())))
                {
                    if (method_exists($l_cat, 'set_catg_custom_id'))
                    {
                        /** @var $l_cat isys_cmdb_dao_category_g_custom_fields */
                        $l_cat->set_catg_custom_id($this->get_category_id());
                    } // if

                    return $l_cat;
                }
                else
                {
                    // Unable to instantiate DAO class
                    throw new isys_exception_api('Unable to instantiate category DAO "'.$l_isysgui["isysgui_cat{$l_cat_suffix}__class_name"].'".', -32602);
                } // if
            }
            else
            {
                // DAO does not exists
                throw new isys_exception_api('Category DAO "'.$l_isysgui["isysgui_cat{$l_cat_suffix}__class_name"].'" does not exist.', -32602);
            } // if
        }
        else
        {
            // Category does not exist
            throw new isys_exception_api('Unable to find desired category with ID "'.$p_params[$l_get_param].'". Please check the delivered category ID and try again',
                                         -32602);
        } // if
    } // function

    /**
     * Prepare category parameter for globa, specific and custom
     *
     * @param $p_params
     *
     * @return array
     * @throws isys_exception_api
     */
    private function prepare_category_params(&$p_params)
    {
        // Process Parameters
        if (isset($p_params[C__CMDB__GET__CATS]) && $p_params[C__CMDB__GET__CATS])
        {
            $l_get_param  = C__CMDB__GET__CATS;
            $l_cat_suffix = 's';

            $this->set_category_type(C__CMDB__CATEGORY__TYPE_SPECIFIC);
            $this->set_content_field(C__PROPERTY__DATA__FIELD);
        }
        else
        {
            if (isset($p_params[C__CMDB__GET__CATG]) && $p_params[C__CMDB__GET__CATG])
            {
                $l_get_param  = C__CMDB__GET__CATG;
                $l_cat_suffix = 'g';

                $this->set_category_type(C__CMDB__CATEGORY__TYPE_GLOBAL);
                $this->set_content_field(C__PROPERTY__DATA__FIELD);
            }
            else
            {
                if (isset($p_params[C__CMDB__GET__CATG_CUSTOM]) && $p_params[C__CMDB__GET__CATG_CUSTOM])
                {
                    $l_get_param  = C__CMDB__GET__CATG_CUSTOM;
                    $l_cat_suffix = 'g_custom';

                    $this->set_category_type(C__CMDB__CATEGORY__TYPE_CUSTOM);
                    $this->set_content_field(C__PROPERTY__DATA__FIELD_ALIAS);
                }
                else
                {
                    if (isset($p_params['category']) && is_string($p_params['category']) && defined($p_params['category']))
                    {
                        if (strpos($p_params['category'], 'C__CATG') === 0 &&
                            strpos($p_params['category'], 'C__CATG__CUSTOM_FIELDS_') !== 0
                        )
                        {
                            $l_get_param  = C__CMDB__GET__CATG;
                            $l_cat_suffix = 'g';

                            $this->set_category_type(C__CMDB__CATEGORY__TYPE_GLOBAL);
                            $this->set_content_field(C__PROPERTY__DATA__FIELD);
                        }
                        else
                        {
                            if (strpos($p_params['category'], 'C__CATS') === 0)
                            {
                                $l_get_param  = C__CMDB__GET__CATS;
                                $l_cat_suffix = 's';

                                $this->set_category_type(C__CMDB__CATEGORY__TYPE_SPECIFIC);
                                $this->set_content_field(C__PROPERTY__DATA__FIELD);
                            }
                            else
                            {
                                $l_get_param  = C__CMDB__GET__CATG_CUSTOM;
                                $l_cat_suffix = 'g_custom';

                                $this->set_category_type(C__CMDB__CATEGORY__TYPE_CUSTOM);
                                $this->set_content_field(C__PROPERTY__DATA__FIELD_ALIAS);
                            } // if
                        } // if

                        $p_params[$l_get_param] = $p_params['category'];
                    }
                    else
                    {
                        throw new isys_exception_api('Category type missing. You must specify the parameter int \'catsID\', int \'catgID\', int \'customID\' or string \'category\' ' .
                                                     'in order to identify the corresponding category you would like to use.',
                                                     -32602);
                    } // if
                } // if
            } // if
        } // if

        return array($l_get_param, $l_cat_suffix);
    } // function

    /**
     * Set the category type
     *
     * @param int $p_category_type
     *
     * @return $this
     */
    protected function set_category_type($p_category_type)
    {
        $this->m_category_type = $p_category_type;

        return $this;
    } // function

    /**
     * Set the content field
     *
     * @param string $p_content_field
     *
     * @return $this
     */
    protected function set_content_field($p_content_field)
    {
        $this->m_content_field = $p_content_field;

        return $this;
    } // function

    /**
     * Set category suffix
     *
     * @param string $p_category_suffix
     *
     * @return $this
     */
    protected function set_category_suffix($p_category_suffix)
    {
        $this->m_category_suffix = $p_category_suffix;

        return $this;
    } // function

    /**
     * Set category id
     *
     * @param int $p_category_id
     *
     * @return $this
     */
    protected function set_category_id($p_category_id)
    {
        $this->m_category_id = $p_category_id;

        return $this;
    } // function

    /**
     * Set category info from isysgui
     *
     * @param array $p_category_info
     *
     * @return $this
     */
    protected function set_category_info($p_category_info)
    {
        $this->m_category_info = $p_category_info;

        return $this;
    } // function

    /**
     * Is category type global?
     *
     * @return bool
     */
    protected function is_global()
    {
        return (C__CMDB__CATEGORY__TYPE_GLOBAL == $this->get_category_type());
    } // function

    /**
     * Set category source table
     *
     * @param string $p_category_source_table
     *
     * @return $this
     */
    protected function set_category_source_table($p_category_source_table)
    {
        $this->m_category_source_table = $p_category_source_table;

        return $this;
    } // function

    /**
     * Get category id
     *
     * @return int
     */
    public function get_category_id()
    {
        return $this->m_category_id;
    } // function

    /**
     * Is category type custom?
     *
     * @return bool
     */
    protected function is_custom()
    {
        return (C__CMDB__CATEGORY__TYPE_CUSTOM == $this->get_category_type());
    } // function

    /**
     * Get category's source table
     *
     * @param string $p_add
     *
     * @return string
     */
    protected function get_category_source_table($p_add = '')
    {
        return $this->m_category_source_table . $p_add;
    } // function

    /**
     * Get content field
     *
     * @return string
     */
    protected function get_content_field()
    {
        return $this->m_content_field;
    } // function

    /**
     * Create category entry
     *
     * @param array $p_params Parameters (depends on data method)
     *
     * @internal param string $p_method Data method
     * @return isys_api_model_cmdb Returns itself.
     */
    public function create($p_params)
    {
        $l_id = $this->sync_wrapper($p_params, isys_import_handler_cmdb::C__CREATE);

        if ($l_id)
        {
            // Update 'isys_obj__updated'
            $this->m_dao->object_changed($p_params[C__CMDB__GET__OBJECT]);

            $l_return['id']      = $l_id;
            $l_return['message'] = 'Category entry successfully created.';
            $l_return['success'] = true;
        }
        else
        {
            $l_return['success'] = false;
            $l_return['message'] = 'Error while creating category entry';
        } // if

        return $l_return;
    } // function

    /**
     * Sync data
     *
     * @param array $p_params
     * @param int   $p_mode
     *
     * @return bool
     * @throws \Exception
     * @throws \isys_exception_api
     * @throws \isys_exception_api_validation
     */
    protected function sync_wrapper($p_params, $p_mode)
    {
        global $g_comp_database;

        /** @var isys_cmdb_dao_dialog_admin $l_dialog_admin */
        $l_dialog_admin = isys_factory::get_instance('isys_cmdb_dao_dialog_admin', $g_comp_database);

        // Init
        $l_object_id = isset($p_params[C__CMDB__GET__OBJECT]) ? $p_params[C__CMDB__GET__OBJECT] : false;

        // Validate object id
        if (!$l_object_id || $l_object_id < 2)
        {
            throw new isys_exception_api('Object id invalid. ID must be positive and higher than two.', -32602);
        } // if

        if (!isset($p_params['data']) || !is_array($p_params['data']))
        {
            throw new isys_exception_api('Mandatory array parameter \'data\' missing or wrong format given.');
        } // if

        try
        {
            // Process data
            if (($l_cat = $this->prepare($p_params)))
            {
                $l_cat_suffix = $this->get_category_suffix();
                $l_isysgui    = $this->get_category_info();

                $l_cat->set_object_id($l_object_id);
                $l_cat->set_object_type_id($l_cat->get_objTypeID($l_object_id));

                if (method_exists($l_cat, 'sync'))
                {
                    // Get properties
                    $l_properties = $l_cat->get_properties();

                    // Try to validate incoming data
                    $l_validation = $l_cat->validate($p_params['data']);

                    if (is_array($l_validation) && count($l_validation) > 0)
                    {

                        $l_validation_errors = '';
                        foreach ($l_validation AS $l_field => $l_problem)
                        {
                            $l_validation_errors .= $l_field . '(' . $l_properties[$l_field][C__PROPERTY__DATA][C__PROPERTY__DATA__TYPE] . '): ' . $l_problem . ', ';
                        } // foreach

                        throw new isys_exception_api_validation(
                            'There was a validation error: ' . rtrim(
                                $l_validation_errors,
                                ', '
                            ), $l_validation);

                    }
                    else
                    {
                        if ($l_validation === true)
                        {
                            // Create sync conform data array
                            $l_data = array();

                            // Prepare category ressource
                            if ($l_isysgui["isysgui_cat{$l_cat_suffix}__list_multi_value"] == 1)
                            {
                                // Set category id
                                if (isset($p_params['data']['category_id']) && $p_params['data']['category_id'] > 0)
                                {
                                    $l_data['data_id'] = $p_params['data']['category_id'];
                                }
                                else
                                {
                                    if (isset($p_params['data']['id']) && $p_params['data']['id'] > 0)
                                    {
                                        $l_data['data_id'] = $p_params['data']['id'];
                                    }
                                    else
                                    {
                                        $l_data['data_id'] = NULL;
                                    } // if
                                } // if

                                // Mode: Update
                                if ($p_mode == isys_import_handler_cmdb::C__UPDATE)
                                {
                                    // Check for category entry id first
                                    if (isset($l_data['data_id']))
                                    {
                                        // Try to get specified entry
                                        $l_catentries = $l_cat->get_data_as_array($l_data['data_id'], $l_object_id);

                                        if (count($l_catentries) != 1)
                                        {
                                            // Category entry does not exist or the object does not own it.
                                            throw new isys_exception_api('Unable to find specified category entry for object. Please check parameter \'data_id\' and try again.');
                                        } // if
                                    }
                                    else
                                    {
                                        throw new isys_exception_api('Please define the category entry you want to update by setting data.id or data.category_id.');
                                    } // if
                                } // if

                                $l_cat->set_list_id($l_data['data_id']);
                                $l_catentries = $l_cat->get_data_as_array($l_data['data_id'], $l_object_id);
                            }
                            else
                            {

                                /*
                                 * If we are updating a single value category we obviously only need the object id for identifying the right category entry.
                                 * So let's check for it.
                                 */
                                $l_catentries = $l_cat->get_data_as_array(NULL, $l_object_id);
                            } // if

                            // Update-Handling
                            if ($l_isysgui["isysgui_cat{$l_cat_suffix}__list_multi_value"] != 1)
                            {
                                if (count($l_catentries))
                                {
                                    list($l_data['data_id']) = $l_catentries[0][$this->get_category_source_table('__id')];

                                    if (!$l_data['data_id'])
                                    {
                                        $p_mode = isys_import_handler_cmdb::C__CREATE;
                                    }
                                    else
                                    {
                                        $p_params['data_id'] = $p_params['data']['id'] = $l_data['data_id'];
                                        $p_mode              = isys_import_handler_cmdb::C__UPDATE;
                                    } // if
                                }
                                else
                                {
                                    $p_mode = isys_import_handler_cmdb::C__CREATE;
                                } // if
                            } // if

                            // Dialog+ handling before merge
                            foreach ($p_params['data'] AS $l_key => $l_value)
                            {
                                // Is it a dialog_plus or a custom_dialog_plus field
                                if (($l_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] == 'dialog_plus' ||
                                        $l_properties[$l_key][C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][1] == 'custom_category_property_dialog_plus') &&
                                    is_string($l_value)
                                )
                                {
                                    $l_identifier = NULL;

                                    // Get custom dialog identifier
                                    if (isset($l_properties[$l_key][C__PROPERTY__UI][C__PROPERTY__UI__ID]['identifier']) &&
                                        is_scalar($l_properties[$l_key][C__PROPERTY__UI][C__PROPERTY__UI__ID]['identifier']))
                                    {
                                        $l_identifier = $l_properties[$l_key][C__PROPERTY__UI][C__PROPERTY__UI__ID]['identifier'];
                                    } // if

                                    $p_params['data'][$l_key] = $l_dialog_admin->get_id(
                                        $l_properties[$l_key][C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES][0],
                                        $p_params['data'][$l_key],
                                        $l_identifier
                                    );
                                } // if
                            } // foreach

                            // Merge new and old data from the database to prevent overwrites through nulls
                            if (isset($l_data['data_id']) && is_numeric($l_data['data_id']) && count($l_catentries))
                            {
                                $p_params['data'] = array_merge(
                                    self::to_sync_structure($l_catentries[0], $l_cat->get_properties()),
                                    $p_params['data']
                                );
                            } // if

                            // Build Data-Structure for the sync-routine
                            foreach ($p_params['data'] AS $l_key => $l_value)
                            {
                                if (is_string($l_value) && defined($l_value))
                                {
                                    $l_data['properties'][$l_key][C__DATA__VALUE] = constant($l_value);
                                }
                                else
                                {
                                    $l_data['properties'][$l_key][C__DATA__VALUE] = $l_value;
                                } // if
                            } // foreach

                            /*
                             * Emit signal
                             */
                            global $g_comp_signals;
                            $g_comp_signals->emit(
                                'mod.api.beforeCmdbCategorySync',
                                $l_data,
                                $l_object_id,
                                $p_mode
                            );

                            // Call sync of corresponding category
                            return $l_cat->sync($l_data, $l_object_id, $p_mode);
                        }
                        else
                        {
                            throw new isys_exception_api('There was an unknown validation error.');
                        } // if
                    } // if
                } // if
            }
            else
            {
                throw new isys_exception_api('Unable to prepare requested category data. Please make sure the given category ID or constant exists.');
            } // if
        }
        catch (isys_exception_api_validation $e)
        {
            throw $e;
        } // try

        catch
        (isys_exception_api $e)
        {
            throw $e;
        } // try

        return false;

    } // function

    /**
     * Get category suffix
     *
     * @return string
     */
    public function get_category_suffix()
    {
        return $this->m_category_suffix;
    } // function

    /**
     * Get category info
     *
     * @return array
     */
    public function get_category_info()
    {
        return $this->m_category_info;
    } // function

    /**
     * Transform stored data
     * for merging it with the delivered data
     * from the API
     *
     * @author Selcuk Kekec <skekec@i-doit.com>
     *
     * @param array $p_data          API-DATA
     * @param array $p_category_info Category Properties
     *
     * @return array                            Array-Structure for merging
     */
    protected function to_sync_structure($p_data, $p_category_info)
    {
        $l_result = array();

        if (is_array($p_category_info) && count($p_category_info) && is_array($p_data) && count($p_data))
        {
            foreach ($p_category_info AS $l_property_key => $l_property_data)
            {
                if (isset($p_data[$l_property_data[C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD]]))
                {
                    // Handling for connectionFields
                    if (isset($l_property_data[C__PROPERTY__FORMAT]['callback'][1]) && $l_property_data[C__PROPERTY__FORMAT]['callback'][1] == 'connection')
                    {
                        $l_result[$l_property_key] = $p_data['isys_connection__isys_obj__id'];
                    }
                    else
                    {
                        $l_result[$l_property_key] = $p_data[$l_property_data[C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD]];
                    } // if
                } // if
            } // foreach
        } // if

        return $l_result;
    } // function

    /**
     * Save category
     *
     * @param array $p_params Parameters (depends on data method)
     *
     * @internal param string $p_method Data method
     * @return isys_api_model_cmdb Returns itself.
     */
    public function update($p_params)
    {
        if ($this->sync_wrapper($p_params, isys_import_handler_cmdb::C__UPDATE))
        {
            // Update 'isys_obj__updated'
            $this->m_dao->object_changed($p_params[C__CMDB__GET__OBJECT]);

            return array(
                'success' => true,
                'message' => 'Category entry successfully saved'
            );
        }
        else
        {
            return array(
                'success' => false,
                'message' => 'Error while saving category'
            );
        } // if
    } // function

    /**
     * Rank category entry:
     *
     * This method only moves the given category entry
     * to the next deletion status: normal -> archived, archived -> deleted...
     * It will not purge the entry!
     *
     * @param array $p_params Parameters (depends on data method)
     *
     * @throws isys_exception_api
     * @internal param string $p_method Data method
     * @return isys_api_model_cmdb Returns itself.
     */
    public function delete($p_params)
    {
        // Init
        $l_object_id = @$p_params[C__CMDB__GET__OBJECT];

        // Validate object id
        if (!$l_object_id || $l_object_id < 2)
        {
            throw new isys_exception_api('Object id invalid. ID must be positive and higher than one.', -32602);
        } // if

        // Get category params
        if (($l_cat = $this->prepare($p_params)))
        {
            $l_cat_suffix   = $this->get_category_suffix();
            $l_isysgui      = $this->get_category_info();
            $l_source_table = $this->get_category_source_table();

            if (@$p_params[C__CMDB__GET__CATLEVEL])
            {
                $l_category_id = $p_params[C__CMDB__GET__CATLEVEL];
            }
            else
            {
                if (@$p_params['id'])
                {
                    $l_category_id = $p_params['id'];
                }
                else
                {
                    throw new isys_exception_api('Category ID missing. You must specify the parameter \'cateID\' with the content of the entry ID of the category.');
                } // if
            } // if

            // Check class and instantiate it
            if ($l_isysgui["isysgui_cat{$l_cat_suffix}__list_multi_value"] == 1)
            {
                if ($this->get_category_source_table() != 'isys_catg_virtual_list')
                {
                    if (method_exists($l_cat, 'rank_record'))
                    {

                        $l_return = $l_cat->rank_record($l_category_id,
                                                        C__CMDB__RANK__DIRECTION_DELETE,
                                                        $l_source_table);

                        if ($l_return)
                        {
                            return array(
                                'success' => true,
                                'message' => 'Category entry \'' . $l_category_id . '\' successfully deleted'
                            );
                        }
                        else
                        {
                            return array(
                                'success' => false,
                                'message' => 'Category entry \'' . $l_category_id . '\' was not deleted. It may not exists.'
                            );
                        } // if
                    }
                    else
                    {
                        throw new isys_exception_api('CMDB-Category-Error! Rank method not supported by the category.');
                    } // if

                }
                else
                {
                    throw new isys_exception_api('The category does not support deletion.');
                } // if
            }
            else
            {
                throw new isys_exception_api('Your category is not multi-valued. It is not possible to delete a single value category.');
            } // if
        } // if

        return false;
    } // function

    /**
     * Set the get-param for
     * retrieving the categoryID
     *
     * @param   string $p_category_get
     *
     * @return $this
     */
    protected function set_category_get($p_category_get)
    {
        $this->m_category_get = $p_category_get;

        return $this;
    } // function

    /**
     * Get category get paramater: catgID, catsID, customID
     *
     * @return string
     */
    protected function get_category_get()
    {
        return $this->m_category_get;
    } // function

    /**
     * Is category type specific?
     *
     * @return bool
     */
    protected function is_specific()
    {
        return (C__CMDB__CATEGORY__TYPE_SPECIFIC == $this->get_category_type());
    } // function

    /**
     * Get the current category type
     *
     * @return int
     */
    protected function get_category_type()
    {
        return $this->m_category_type;
    } // function

} // class