<?php

/**
 * i-doit
 *
 * CMDB
 * Action Processor
 *
 * Action: Category ranking
 *
 * @package     i-doit
 * @subpackage  CMDB
 * @author      Andre Woesten <awoesten@i-doit.de>
 * @version     0.9
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_action_category_rank extends isys_cmdb_action_category implements isys_cmdb_action
{
	/**
	 * Callback function called by rank_records.
	 *
	 * @todo    It would be much better, if the current object-id would get passed by parameter.
	 * @return  boolean
	 */
	public function check_right ()
	{
		return isys_auth::factory(C__MODULE__CMDB)->has_rights_in_obj_and_category(isys_auth::DELETE, $_GET[C__CMDB__GET__OBJECT], $this->m_cat_dao->get_category_const());
	} // function


	/**
	 * Method for handling the ranking-action.
	 *
	 * @param   isys_cmdb_dao  $p_dao
	 * @param   array          &$p_data
	 * @throws  Exception|isys_exception
	 * @throws  isys_exception_cmdb
	 * @global  isys_component_signalcollection  $g_comp_signals
	 */
	public function handle (isys_cmdb_dao $p_dao, &$p_data)
	{
		global $g_comp_signals;

		$p_direction = $p_data[0];
		$p_cat_dao = $p_data[1];
        $this->m_cat_dao = $p_cat_dao;
		$p_table = $p_data[2];
		$p_posts = $p_data[3];

		if (isset($p_data[4]) && ($p_data[4] == C__NAVMODE__PURGE || $p_data[4] == C__NAVMODE__QUICK_PURGE))
		{
			$l_purge = true;
		}
		else
		{
			$l_purge = false;
		} // if

		if (!$this->object_is_locked())
		{
			if (strpos($p_table, "isys_cats") === 0)
			{
				if (strripos($p_table, "_list"))
				{
					$p_table = substr($p_table, 0, strripos($p_table, "_list"));
				} // if

				$p_table = trim($p_table);
				$p_table = $p_table . "_list";
			} // if

			try
			{
				if (is_array($p_posts) && count($p_posts) > 0)
				{
					$l_tmp = count($p_posts);
					// This is used to remove "empty" entries like array(0 => "0").
					$p_posts = array_filter($p_posts);

					if ($l_tmp != count($p_posts))
					{
						// Notify the user!
						isys_notify::warning(_L('LC__CMDB__RANK_ERROR__ZERO_ID', array($p_table)), array('sticky' => true));

						// This will create a log message, without displaying the big red error-box.
						new isys_exception_database(_L('LC__CMDB__RANK_ERROR__ZERO_ID', array($p_table)));
					} // if

					if (count($p_posts) > 0)
					{
						$g_comp_signals->emit("mod.cmdb.beforeCategoryEntryRank", $p_cat_dao, $p_table, $p_direction, $p_posts);

						if (($l_result = $p_cat_dao->rank_records($p_posts, $p_direction, $p_table, array($this, "check_right"), $l_purge)))
						{
							// Nothing to do here.
						}
						else
						{
							throw new isys_exception_cmdb("Could not delete category entries (" . var_export($p_posts, true) . ") (CMDB-DAO->rank_records)", C__CMDB__ERROR__ACTION_PROCESSOR);
						} // if

						$g_comp_signals->emit("mod.cmdb.afterCategoryEntryRank", $p_cat_dao, $p_table, $l_result, $p_direction, $p_posts);
					} // if
				} // if
			}
			catch (isys_exception $e)
			{
				throw $e;
			} // try
		} // if
	} // function
} // class