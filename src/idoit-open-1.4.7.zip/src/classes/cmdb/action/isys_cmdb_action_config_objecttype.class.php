<?php
/**
 * Action: Object type configuration
 *
 * @package    i-doit
 * @subpackage CMDB_Actions
 * @author     i-doit-team
 * @copyright  synetics GmbH
 * @license    http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_action_config_objecttype implements isys_cmdb_action
{
	/**
	 * Handle method.
	 *
	 * @param  isys_cmdb_dao $p_dao
	 * @param  array         $p_data
	 */
	public function handle (isys_cmdb_dao $p_dao, &$p_data)
	{
		global $g_comp_signals;

		$l_mod_event_manager = isys_event_manager::getInstance();

		$l_arr2 = array();

		/**
		 * @var isys_cmdb_action_processor
		 */
		$l_actionproc = $p_data["__ACTIONPROC"];

		list($l_navmode, $l_type_id, $l_posts) = $p_data;


		if ($l_posts['assigned_categories'])
		{
			$l_arr = $l_posts['assigned_categories'];
			$l_arr[] = C__CATG__GLOBAL;
		}
		else
		{
			$l_arr = array(C__CATG__GLOBAL);
		}

		if ($l_type_id != C__OBJTYPE__PERSON && $l_type_id != C__OBJTYPE__PERSON_GROUP && $l_type_id != C__OBJTYPE__ORGANIZATION)
		{
			$l_arr2[] = C__CATG__GLOBAL;
		}
		if ($l_posts['assigned_cat_overview'])
		{
			$l_arr2 = array_merge($l_arr2, $l_posts['assigned_cat_overview']);
		}

		switch ($l_navmode)
		{
			case C__NAVMODE__NEW:
				isys_auth::factory(C__MODULE__CMDB)->check(isys_auth::EDIT, 'OBJ_TYPE');

				try
				{
					$l_objtypeid = $p_dao->insert_new_objtype($l_type_id);

					if ($l_objtypeid !== null)
					{
						$l_mod_event_manager->triggerCMDBEvent("C__LOGBOOK_EVENT__OBJECTTYPE_CREATED", isys_glob_get_param("LogbookCommentary"), null, $l_objtypeid);

						$l_actionproc->result_push($l_objtypeid);
					} // if
				}
				catch (isys_exception_dao_cmdb $l_e)
				{
					echo $l_e->getMessage();
					die;
				} // try

				break;

			case C__NAVMODE__SAVE:
				$l_obj_type = $p_dao->get_object_type($l_type_id);
				isys_auth::factory(C__MODULE__CMDB)->check(isys_auth::EDIT, 'OBJ_TYPE/' . $l_obj_type['isys_obj_type__const']);

				try
				{
					$g_comp_signals->emit("mod.cmdb.beforeObjectTypeSave", $l_type_id, $l_posts);

					$l_bRet = $p_dao->update_objtype_by_id($l_type_id, $l_arr, $l_arr2, $l_posts);

					$g_comp_signals->emit("mod.cmdb.afterObjectTypeSave", $l_type_id, $l_posts, $l_bRet);

					if ($l_bRet)
					{
						$l_mod_event_manager->triggerCMDBEvent("C__LOGBOOK_EVENT__OBJECTTYPE_CHANGED", isys_glob_get_param("LogbookCommentary"), null, $l_type_id);
					}
					else
					{
						$l_mod_event_manager->triggerCMDBEvent("C__LOGBOOK_EVENT__OBJECTTYPE_CHANGED__NOT", isys_glob_get_param("LogbookCommentary"), null, $l_type_id);
					} // if
				}
				catch (isys_exception_dao_cmdb $l_e)
				{
					die($l_e->getMessage());
				} // try
				break;

			case C__NAVMODE__ARCHIVE:
			case C__NAVMODE__DELETE:
			case C__NAVMODE__PURGE:
				/**
				 * Delete object type
				 * You can only delete self-defined object types which have
				 * currently no objects associated!
				 */
				$l_obj_type = $p_dao->get_object_type($l_type_id);
				isys_auth::factory(C__MODULE__CMDB)->check(isys_auth::DELETE, 'OBJ_TYPE/' . $l_obj_type['isys_obj_type__const']);

				if (is_array($l_posts["id"]))
				{
					foreach ($l_posts["id"] as $l_val)
					{
						$l_strObjTypeTitle = $p_dao->get_objtype_name_by_id_as_string($l_val);

						try
						{
							$g_comp_signals->emit("mod.cmdb.beforeObjectTypePurge", $l_type_id, $l_strObjTypeTitle);

							$l_result = $p_dao->delete_object_type($l_val);

							$l_mod_event_manager->triggerCMDBEvent("C__LOGBOOK_EVENT__OBJECTTYPE_PURGED", isys_glob_get_param("LogbookCommentary"), null, $l_type_id, $l_strObjTypeTitle);

							$g_comp_signals->emit("mod.cmdb.afterObjectTypePurge", $l_type_id, $l_strObjTypeTitle, $l_result);
						}
						catch (Exception $e)
						{
							global $g_error;

							$g_error = "Delete failed: " . $e->getMessage();

							$l_mod_event_manager->triggerCMDBEvent("C__LOGBOOK_EVENT__OBJECTTYPE_PURGED__NOT", isys_glob_get_param("LogbookCommentary"), null, $l_type_id, $l_strObjTypeTitle);
						} // try
					} // foreach
				} // if
				break;
		} // switch
	} // function
} // class
?>