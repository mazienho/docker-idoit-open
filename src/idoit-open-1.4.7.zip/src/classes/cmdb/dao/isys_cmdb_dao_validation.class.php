<?php
/**
 * i-doit
 *
 * Validation DAO
 *
 * @package     i-doit
 * @subpackage  CMDB_Low-Level_API
 * @author      Leonard Fischer <lfischer@i-doit.org>
 * @version     1.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_validation extends isys_cmdb_dao
{
	/**
	 * Retrieve contents from isys_validation_config.
	 *
	 * @param   integer  $p_config_id
	 * @param   integer  $p_cat_id
	 * @param   string   $p_cat_type
	 * @return  isys_component_dao_result
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_data($p_config_id = null, $p_cat_id = null, $p_cat_type = 'g')
	{
		$l_sql = 'SELECT * FROM isys_validation_config WHERE TRUE ';

		if ($p_config_id !== null)
		{
			$l_sql .= 'AND isys_validation_config__id = ' . $this->convert_sql_id($p_config_id) . ' ';
		} // if

		if ($p_cat_id !== null)
		{
			$l_sql .= 'AND isys_validation_config__isysgui_cat' . $p_cat_type . '__id = ' . $this->convert_sql_id($p_cat_id) . ' ';
		} // if

		return $this->retrieve($l_sql . ';');
	} // function


	/**
	 * Method for removing a validation set.
	 *
	 * @param   integer  $p_cat_id
	 * @param   string   $p_cat_type
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function delete($p_cat_id, $p_cat_type)
	{
		$l_sql = 'DELETE FROM isys_validation_config WHERE isys_validation_config__isysgui_cat' . $p_cat_type . '__id = ' . $this->convert_sql_id($p_cat_id) . ';';

		return ($this->update($l_sql) && $this->apply_update());
	} // function


	/**
	 * Method for saving new validation sets to the database.
	 *
	 * @param   integer  $p_cat_id
	 * @param   string   $p_cat_type
	 * @param   string   $p_json
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function save($p_cat_id, $p_cat_type, $p_json)
	{
		$l_res = $this->get_data(null, $p_cat_id, $p_cat_type);

		if ($l_res->num_rows() > 0)
		{
			$l_row = $l_res->get_row();
			// Update.
			$l_sql = 'UPDATE isys_validation_config SET ' .
				'isys_validation_config__isysgui_cat' . $p_cat_type . '__id = ' . $this->convert_sql_id($p_cat_id) . ', ' .
				'isys_validation_config__json = ' . $this->convert_sql_text($p_json) . ' ' .
				'WHERE isys_validation_config__id = ' . $this->convert_sql_id($l_row['isys_validation_config__id']) . ';';
		}
		else
		{
			// Create.
			$l_sql = 'INSERT INTO isys_validation_config (' .
				'isys_validation_config__isysgui_cat' . $p_cat_type . '__id, ' .
				'isys_validation_config__json' .
				') VALUES (' .
				$this->convert_sql_id($p_cat_id) . ', ' .
				$this->convert_sql_text($p_json) . ');';
		} // if

		return ($this->update($l_sql) && $this->apply_update());
	} // function
} // class