<?php

/**
 * i-doit
 *
 * CMDB DAO: specific category for the layer 2 nets
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       0.9.9-8
 * @author      Selcuk Kekec <skekec@synetics.de>
 */
class isys_cmdb_dao_category_s_layer2_net extends isys_cmdb_dao_category_specific
{
    /**
     * Category's name. Will be used for the identifier, constant, main table, and many more.
     * @var  string
     */
    protected $m_category = 'layer2_net';

    /**
     * Method for returning the properties.
     *
     * @return  array
     */
    protected function properties()
    {
        return array(
            'vlan_id' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::text(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__LAYER2_ID',
                        C__PROPERTY__INFO__DESCRIPTION => 'ID (VLAN)'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_layer2_net_list__ident'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CATS__LAYER2_ID'
                    )
                )
            ),
            'standard' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::dialog(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__LAYER2_STANDARD_VLAN',
                        C__PROPERTY__INFO__DESCRIPTION => 'Default VLAN'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_layer2_net_list__standard'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CATS__LAYER2_STANDARD_VLAN',
						C__PROPERTY__UI__DEFAULT => '0'
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false
                    ),
                    C__PROPERTY__FORMAT => array(
                        C__PROPERTY__FORMAT__CALLBACK => array(
                            'isys_export_helper',
                            'get_yes_or_no'
                        )
                    )
                )
            ),
            'type' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::dialog_plus(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__LAYER2_TYPE',
                        C__PROPERTY__INFO__DESCRIPTION => 'Type'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_layer2_net_list__isys_layer2_net_type__id',
                        C__PROPERTY__DATA__REFERENCES => array(
                            'isys_layer2_net_type',
                            'isys_layer2_net_type__id'
                        )
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CATS__LAYER2_TYPE',
                        C__PROPERTY__UI__PARAMS => array(
                            'p_strTable' => 'isys_layer2_net_type'
                        ),
						C__PROPERTY__UI__DEFAULT => C__LAYER2_NET__TYPE_VLAN
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false
                    )
                )
            ),
            'subtype' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::dialog_plus(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__LAYER2_SUBTYPE',
                        C__PROPERTY__INFO__DESCRIPTION => 'Subtype'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_layer2_net_list__isys_layer2_net_subtype__id',
                        C__PROPERTY__DATA__REFERENCES => array(
                            'isys_layer2_net_subtype',
                            'isys_layer2_net_subtype__id'
                        )
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CATS__LAYER2_SUBTYPE',
                        C__PROPERTY__UI__PARAMS => array(
                            'p_strTable' => 'isys_layer2_net_subtype'
                        )
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false
                    )
                )
            ),
            'ip_helper_addresses' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::int(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__LAYER2_IP_HELPER_ADDRESSES',
                        C__PROPERTY__INFO__DESCRIPTION => 'IP helper addresses'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_layer2_net_list__id'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CMDB__CATS__LAYER2_NET__IP_HELPER_ADDRESSES'
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false,
                        C__PROPERTY__PROVIDES__REPORT => false,
                        C__PROPERTY__PROVIDES__LIST => false,
                    ),
                    C__PROPERTY__FORMAT => array(
                        C__PROPERTY__FORMAT__CALLBACK => array(
                            'isys_export_helper',
                            'ip_helper_addresses'
                        )
                    )
                )
            ),
	        'layer3_assignments' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::object_browser(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__LAYER2__LAYER3_NET',
                        C__PROPERTY__INFO__DESCRIPTION => 'Layer-3-net assignments'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_layer2_net_list__id'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CATS__LAYER2__LAYER3_NET'
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false,
                        C__PROPERTY__PROVIDES__REPORT => false,
                        C__PROPERTY__PROVIDES__LIST => false
                    ),
                    C__PROPERTY__FORMAT => array(
                        C__PROPERTY__FORMAT__CALLBACK => array(
                            'isys_export_helper',
                            'layer_3_assignment'
                        )
                    )
                )
            ),
            'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__LOGBOOK__DESCRIPTION',
                        C__PROPERTY__INFO__DESCRIPTION => 'Description'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_layer2_net_list__description'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_SPECIFIC . C__CATS__LAYER2_NET
                    )
                )
            )
        );
    }

	/**
	 * Method for adding a new IP helper to the database.
	 *
	 * @param   integer  $p_cat_id
	 * @param   string   $p_ip
	 * @param   integer  $p_type
	 * @return  boolean
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 */
	public function add_iphelper($p_cat_id, $p_ip, $p_type)
	{
		$l_sql = "INSERT INTO isys_cats_layer2_net_2_iphelper VALUES (NULL, " . $this->convert_sql_id($p_cat_id) . ", " . $this->convert_sql_id($p_type) . ", " . $this->convert_sql_text($p_ip) . ")";

		return $this->update($l_sql) && $this->apply_update();
	} // function


	/**
	 * Method for checking if a certain ID already exists.
	 *
	 * @param   integer  $p_id
	 * @return  boolean
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 */
	public function check_id_exists($p_id)
	{
		$l_res = $this->retrieve("SELECT * FROM isys_cats_layer2_net_list WHERE isys_cats_layer2_net_list__ident = " . $this->convert_sql_text($p_id) . ";");
		$l_count = $l_res->num_rows();

		$l_row2 = $this->get_data(NULL, $_GET[C__CMDB__GET__OBJECT])->get_row();

		if ($l_count == 0)
		{
			return false;
		}
		else if ($l_count == 1)
		{
			$l_row = $l_res->get_row();

			if ($l_row['isys_cats_layer2_net_list__id'] == $l_row2['isys_cats_layer2_net_list__id'])
			{
				return false;
			} // if

			return true;
		}
		else
		{
			return true;
		} // if
	} // function


	/**
	 * Removes a certain IP-helper from a layer2 net.
	 *
	 * @param   integer  $p_cat_id
	 * @return  boolean
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 */
	public function clean_iphelper($p_cat_id)
	{
		$l_sql = "DELETE FROM isys_cats_layer2_net_2_iphelper
			WHERE isys_cats_layer2_net_2_iphelper__isys_cats_layer2_net_list__id = " . $this->convert_sql_id($p_cat_id) . ";";

		return $this->update($l_sql) && $this->apply_update();
	} // function


	/**
	 * Create method.
	 *
	 * @param   integer  $p_obj_id
	 * @param   integer  $p_status
	 * @param   string   $p_ident
	 * @param   integer  $p_type
	 * @param   integer  $p_subtype
	 * @param   integer  $p_standard
	 * @param   string   $p_description
	 * @return  mixed  Integer with the last inserted ID or boolean false on failure.
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function create($p_obj_id, $p_status = C__RECORD_STATUS__NORMAL, $p_ident = NULL, $p_type = NULL, $p_subtype = NULL, $p_standard = NULL, $p_description = '')
	{
		$l_sql = 'INSERT INTO isys_cats_layer2_net_list SET
			isys_cats_layer2_net_list__ident = ' . $this->convert_sql_text($p_ident) . ',
			isys_cats_layer2_net_list__isys_layer2_net_type__id = ' . $this->convert_sql_id($p_type) . ',
			isys_cats_layer2_net_list__isys_layer2_net_subtype__id = ' . $this->convert_sql_id($p_subtype) . ',
			isys_cats_layer2_net_list__description = ' . $this->convert_sql_text($p_description) . ',
			isys_cats_layer2_net_list__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ',
			isys_cats_layer2_net_list__status = ' . $this->convert_sql_id($p_status) . ',
			isys_cats_layer2_net_list__standard = ' . $this->convert_sql_boolean(($p_standard == true)) . ';';

		if ($this->update($l_sql) && $this->apply_update())
		{
			return $this->get_last_insert_id();
		}
		else
		{
			return false;
		} // if
	} // function


	/**
	 * Create element method.
	 *
	 * @param   integer  $p_cat_level
	 * @param   integer  & $p_new_id
	 * @return  mixed  Integer on success, null on failure.
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function create_element ($p_cat_level, &$p_new_id)
	{
		$p_new_id = -1;
		$l_intRetCode = 3;

		$l_id = $this->create($_GET[C__CMDB__GET__OBJECT], C__RECORD_STATUS__NORMAL, null, null, null, null, null, null, null);

		if ($l_id != false)
		{
			$this->m_strLogbookSQL = $this->get_last_query();
			$l_intRetCode = null;
			$p_new_id = $l_id;
		} // if

		return $l_intRetCode;
	} // function

	/**
	 * Get data method.
	 *
	 * @param   integer  $p_cats_list_id
	 * @param   integer  $p_obj_id
	 * @param   string   $p_condition
	 * @param   array    $p_filter
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 */
	public function get_data($p_cats_list_id = NULL, $p_obj_id = NULL, $p_condition = '', $p_filter = NULL, $p_status = NULL)
	{
		$l_sql = "SELECT *
			FROM isys_cats_layer2_net_list
			LEFT JOIN isys_layer2_net_type ON isys_cats_layer2_net_list__isys_layer2_net_type__id = isys_layer2_net_type__id
			LEFT JOIN isys_layer2_net_subtype ON isys_cats_layer2_net_list__isys_layer2_net_subtype__id  = isys_layer2_net_subtype__id
			LEFT JOIN isys_obj AS obj ON isys_cats_layer2_net_list__isys_obj__id = obj.isys_obj__id
			WHERE TRUE " . $p_condition . $this->prepare_filter($p_filter);

		if ($p_obj_id !== NULL)
		{
			$l_sql .= $this->get_object_condition($p_obj_id);
		} // if

		if ($p_cats_list_id !== NULL)
		{
			$l_sql .= " AND (isys_cats_layer2_net_list__id = " . $this->convert_sql_int($p_cats_list_id) . ")";
		} // if

		if ($p_status !== NULL)
		{
			$l_sql .= " AND (obj.isys_obj__status = " . $this->convert_sql_int($p_status) . ")";
		} // if

		return $this->retrieve($l_sql . ";");
	} // function

	/**
	 * Creates the condition to the object table
	 *
	 * @param int|array $p_obj_id
	 * @return string
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function get_object_condition($p_obj_id = NULL){
		$l_sql = '';

		if (!empty($p_obj_id)) {
			if(is_array($p_obj_id)){
				$l_sql = ' AND (isys_cats_layer2_net_list__isys_obj__id ' . $this->prepare_in_condition($p_obj_id) . ') ';
			} else{
				$l_sql = ' AND (isys_cats_layer2_net_list__isys_obj__id = '.$this->convert_sql_id($p_obj_id).') ';
			}
		}
		return $l_sql;
	}

	/**
	 * Method for retrieving the address of a certain IP helper.
	 *
	 * @param   integer  $p_cat_id
	 * @return  mixed  Array with data or boolean false.
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 */
	public function get_iphelper_adress($p_cat_id)
	{
		if ($p_cat_id)
		{
			$l_sql = "SELECT * FROM isys_cats_layer2_net_2_iphelper WHERE isys_cats_layer2_net_2_iphelper__isys_cats_layer2_net_list__id = " . $p_cat_id . ";";

			$l_res = $this->retrieve($l_sql);

			if ($l_res->num_rows() > 0)
			{
				$l_res_arr = array();
				while ($l_row = $l_res->get_row())
				{
					$l_res_arr[] = $l_row;
				} // while

				return $l_res_arr;
			} // if
		} // if

		return false;
	} // function


	/**
	 * This method selects all layer2 nets, but adds a suffix to the title. This is used for the object browser.
	 *
	 * @return  isys_component_dao_result
	 * @author  Leonard Fischer <lfischer@i-doit.org>
     * @param   array $p_layer2_object_ids
	 * @todo    Add a parameter to select only layer2 nets, assigned by a port (for dataretrieval method).
	 */
	public function find_layer2_objects_with_prefixed_name($p_layer2_object_ids = array())
	{
		$l_sql_condition = ' CASE isys_cats_layer2_net_list__isys_layer2_net_subtype__id ' .
			'WHEN ' . (int) C__CATS__LAYER2_NET__SUBTYPE__STATIC_VLAN . ' THEN CONCAT(isys_obj__title, " ", isys_cats_layer2_net_list__ident, " (Static)") ' .
			'WHEN ' . (int) C__CATS__LAYER2_NET__SUBTYPE__DYNAMIC_VLAN . ' THEN CONCAT(isys_obj__title, " ", isys_cats_layer2_net_list__ident, " (Dynamic)") ' .
			'ELSE CONCAT(isys_obj__title, "") END ';

		$l_sql = 'SELECT isys_obj__id, ' . $l_sql_condition . ' AS isys_obj__title, isys_obj_type__title, isys_obj__sysid FROM isys_cats_layer2_net_list
			LEFT JOIN isys_obj ON isys_obj__id = isys_cats_layer2_net_list__isys_obj__id
			LEFT JOIN isys_obj_type ON isys_obj_type__id = isys_obj__isys_obj_type__id
			WHERE isys_obj__isys_obj_type__id = ' . $this->convert_sql_id(C__OBJTYPE__LAYER2_NET) . '
			AND isys_obj__status = '  . $this->convert_sql_id(C__RECORD_STATUS__NORMAL);

        if ($p_layer2_object_ids && count($p_layer2_object_ids))
        {
	        $l_sql .= ' AND isys_obj__id IN('.implode(',', $p_layer2_object_ids).')';
        } // if

		return $this->retrieve($l_sql . ';');
	} // function

	/**
	 * Method for retrieving the layer2 nets.
	 *
	 * @param   array  $p_layer2_object_ids
	 * @return  array
	 */
    public function get_layer2_vlans(array $p_layer2_object_ids)
    {
        $l_return = array();
        $l_vlans = $this->find_layer2_objects_with_prefixed_name($p_layer2_object_ids);

        while ($l_row = $l_vlans->get_row())
        {
            $l_return[] = array(
                'id' => $l_row['isys_obj__id'],
                'title' => $l_row['isys_obj__title']
            );
        } // while

        return $l_return;
    } // function


	/**
	 * Save method.
	 *
	 * @param   integer  $p_id
	 * @param   integer  $p_status
	 * @param   string   $p_ident
	 * @param   integer  $p_type
	 * @param   integer  $p_subtype
	 * @param   integer  $p_standard
	 * @param   string   $p_description
	 * @return  boolean
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function save($p_id, $p_status, $p_ident, $p_type, $p_subtype, $p_standard, $p_description)
	{
		$l_sql = 'UPDATE  isys_cats_layer2_net_list SET
			isys_cats_layer2_net_list__ident = ' . $this->convert_sql_text($p_ident) . ',
			isys_cats_layer2_net_list__isys_layer2_net_type__id = ' . $this->convert_sql_id($p_type) . ',
			isys_cats_layer2_net_list__isys_layer2_net_subtype__id = ' . $this->convert_sql_id($p_subtype) . ',
			isys_cats_layer2_net_list__description = ' . $this->convert_sql_text($p_description) . ',
			isys_cats_layer2_net_list__status = ' . $this->convert_sql_id($p_status) . ',
			isys_cats_layer2_net_list__standard = ' . $this->convert_sql_boolean(($p_standard == true)) . '
			WHERE isys_cats_layer2_net_list__id = ' . $this->convert_sql_id($p_id) . ';';

		return $this->update($l_sql) && $this->apply_update();
	} // function


	/**
	 * Save element method.
	 *
	 * @param   integer  & $p_cat_level
	 * @param   integer  & $p_intOldRecStatus
	 * @return  mixed  Null on success, or the error code as integer.
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function save_element(&$p_cat_level, &$p_intOldRecStatus)
	{
		$l_intErrorCode = -1;
		$l_catdata = $this->get_data_by_object($_GET[C__CMDB__GET__OBJECT])->__to_array();

		if (! empty($l_catdata["isys_cats_layer2_net_list__id"]))
		{
			$l_bRet = $this->save(
				$l_catdata['isys_cats_layer2_net_list__id'],
				C__RECORD_STATUS__NORMAL, //TODO
				$_POST['C__CATS__LAYER2_ID'],
				$_POST['C__CATS__LAYER2_TYPE'],
				$_POST['C__CATS__LAYER2_SUBTYPE'],
				$_POST['C__CATS__LAYER2_STANDARD_VLAN'],
				$_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()]);

			$this->update_iphelper($l_catdata['isys_cats_layer2_net_list__id'], $_POST['ip_helper']);
			$this->update_layer3($l_catdata['isys_cats_layer2_net_list__id'], isys_format_json::decode( $_POST['C__CATS__LAYER2__LAYER3_NET__HIDDEN'], true));

			$this->m_strLogbookSQL = $this->get_last_query();
		} // if

		return $l_bRet == true ? NULL : $l_intErrorCode;
	} // function


	/**
	 * Synchronize category content with $p_data
	 *
	 * @global  isys_component_database  $g_comp_database
	 * @param   array    $p_category_data
	 * @param   integer  $p_object_id
	 * @param   integer  $p_status
	 * @return  mixed  Boolean or integer.
	 */
	public function sync($p_category_data, $p_object_id, $p_status = isys_import_handler_cmdb::C__CREATE)
	{
		$l_indicator = false;
		if(is_array($p_category_data) && isset($p_category_data['properties']))
		{
			$this->m_sync_catg_data = $p_category_data;
			// Create category data identifier if needed.
			if ($p_status === isys_import_handler_cmdb::C__CREATE)
			{
				$p_category_data['data_id'] = $this->create($p_object_id);
			}
			if ($p_status === isys_import_handler_cmdb::C__CREATE || $p_status === isys_import_handler_cmdb::C__UPDATE)
			{
				// Save category data.
				$l_indicator = $this->save($p_category_data['data_id'],
										C__RECORD_STATUS__NORMAL,
										$this->get_property('vlan_id'),
										$this->get_property('type'),
										$this->get_property('subtype'),
										$this->get_property('standard'),
										$this->get_property('description'));
				$this->clean_iphelper($p_category_data['data_id']);
				$l_ip_helper = $this->get_property('ip_helper_addresses');
				if (is_array($l_ip_helper))
				{
					foreach ($l_ip_helper AS $l_iphelper)
					{
						$this->add_iphelper($p_category_data['data_id'],
											$l_iphelper['ip'],
											isys_import::check_dialog('isys_layer2_iphelper_type',
																	  $l_iphelper['type_title']));
					} // foreach
				} // if
				$l_layer_3 = $this->get_property('layer3_assignments');
				if ($l_layer_3)
				{
					if (!is_array($l_layer_3) && is_numeric($l_layer_3))
					{
						$l_layer_3 = array($l_layer_3);
					}
					$this->update_layer3($p_category_data['data_id'], $l_layer_3);
				}
			} // if
		}
		return ($l_indicator === true)? $p_category_data['data_id']: false;
	} // function


	/**
	 * Method for creating several IP helper.
	 *
	 * @param   integer  $p_cat_id
	 * @param   array    $p_iphelper
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 */
	public function update_iphelper($p_cat_id, $p_iphelper)
	{
		if ($this->clean_iphelper($p_cat_id))
		{
			if (isset($p_iphelper) && count($p_iphelper))
			{
				foreach ($p_iphelper as $l_value)
				{
					$this->add_iphelper($p_cat_id, $l_value['ip'], $l_value['type']);
				} // foreach
			} // if
		} // if
	} // function


	/**
	 * Method for creating several IP helper.
	 *
	 * @param   integer  $p_cat_id
	 * @param   array    $p_layer3
	 * @return  boolean
	 * @author  Dennis Stücken <dstuecken@synetics.de>
	 */
	public function update_layer3($p_cat_id, $p_layer3)
	{
		if ($this->clean_layer3($p_cat_id))
		{
			if (count($p_layer3))
			{
                $l_updating = 0;
				$l_sql = "INSERT INTO isys_cats_layer2_net_2_layer3 VALUES ";

				foreach ($p_layer3 AS $l_value)
				{
                    if ($p_cat_id > 0 && $l_value > 0 && $p_cat_id != $l_value)
                    {
                        $l_sql .= '(' . (int) $p_cat_id . ',' . (int) $l_value . '),';
                        $l_updating++;
                    }
				} // foreach

                if ($l_updating > 0)
                {
                    $l_sql = rtrim($l_sql, ',');

                    return $this->m_db->query($l_sql);
                }
			} // if
		} // if
		return false;
	} // function

	/**
	 * @param $p_cat_id
	 * @return boolean
	 */
	public function clean_layer3($p_cat_id)
	{
		return $this->m_db->query("DELETE FROM isys_cats_layer2_net_2_layer3 WHERE isys_cats_layer2_net_list__id = '".$p_cat_id."';");
	}

	/**
	 * Get layer 3 assignments
	 *
	 * @param $p_cat_id
	 * @return array
	 */
	public function get_layer3_assignments_as_array($p_cat_id) {
		$l_layer3s = array();
		$l_data = $this->get_layer3_assignments($p_cat_id);
		while ($l_row = $l_data->get_row())
		{
			$l_layer3s[] = $l_row['isys_obj__id'];
		}
		return $l_layer3s;
	}

	/**
	 * Get layer 3 assignments
	 *
	 * @param $p_cat_id
	 * @return array
	 */
	public function get_layer3_assignments($p_cat_id) {
		return $this->retrieve("SELECT isys_obj.isys_obj__id, isys_obj.isys_obj__title FROM isys_cats_layer2_net_2_layer3 INNER JOIN isys_obj ON isys_obj.isys_obj__id = isys_cats_layer2_net_2_layer3.isys_obj__id WHERE isys_cats_layer2_net_list__id = '".$p_cat_id."';");
	}


	/**
	 * Validate post data for easy validation.
	 *
	 * @return  boolean
	 * @author  Selcuk Kekec <skekec@synetics.de>
	 */
	public function validate_user_data()
	{
		$l_return = true;
		$l_tom_additional = array();

		if (isys_settings::get('cmdb.unique.layer-2-net'))
		{
			if (!empty($_POST["C__CATS__LAYER2_ID"]))
			{
				if ($this->check_id_exists($_POST["C__CATS__LAYER2_ID"]))
				{
					$l_tom_additional['C__CATS__LAYER2_ID']['p_strInfoIconError'] = _L('LC__CMDB__CATS__LAYER2_NET__ALREADY_EXISTS');
					$l_return = false;
				} // if
			} // if
		} // if

		$this->set_additional_rules(($l_return == false) ? $l_tom_additional : NULL);
		$this->set_validation($l_return);

		return $l_return;
	} // function
} // class