<?php

/**
 * i-doit
 *
 * DAO: specific category for persons with assigned groups
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Andre Woesten <awoesten@i-doit.de>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_s_person_assigned_groups extends isys_cmdb_dao_category_specific
{
    /**
     * Category's name. Will be used for the identifier, constant, main table, and many more.
     * @var  string
     */
    protected $m_category = 'person_assigned_groups';

    /**
     * The category's table.
     * @var    string
     * @fixme  No standard behavior!
     */
    protected $m_table = 'isys_cats_person_group_list';


    /**
     * Method for returning the properties.
     *
     * @return  array
     */
    protected function properties()
    {
        return array(
            'connected_object' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::object_browser(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CONTACT__TREE__GROUP_MEMBERS',
                        C__PROPERTY__INFO__DESCRIPTION => 'Person group memberships'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_person_group_list__isys_obj__id',
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => '',
                        C__PROPERTY__UI__PARAMS => array(
                            isys_popup_browser_object_ng::C__MULTISELECTION => true,
                            isys_popup_browser_object_ng::C__FORM_SUBMIT => true,
                            isys_popup_browser_object_ng::C__TYPE_FILTER => "C__OBJTYPE__PERSON_GROUP",
                            isys_popup_browser_object_ng::C__RETURN_ELEMENT => C__POST__POPUP_RECEIVER,
                            /*isys_popup_browser_object_ng::C__DATARETRIEVAL => array(
                                array('isys_cmdb_dao_category_s_person_assigned_groups', 'get_assigned_contacts'),
                                $_GET[C__CMDB__GET__OBJECT],
                                array("isys_obj__id", "isys_obj__title", "isys_obj__isys_obj_type__id", "isys_obj__sysid")
                                ),*/
							isys_popup_browser_object_ng::C__DATARETRIEVAL => new isys_callback(array('isys_cmdb_dao_category_s_person_assigned_groups', 'callback_property_connected_object'))
                        )
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__REPORT => true
                    ),
                    C__PROPERTY__FORMAT => array(
                        C__PROPERTY__FORMAT__CALLBACK => array(
                            'isys_export_helper',
                            'object'
                        )
                    )
                )
            ),
			'contact' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::int(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__GLOBAL_CONTACT',
						C__PROPERTY__INFO__DESCRIPTION => 'Contact'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_person_2_group__isys_obj__id__group'
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__VALIDATION => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false,
						C__PROPERTY__PROVIDES__IMPORT => false,
						C__PROPERTY__PROVIDES__EXPORT => true
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'person_property_contact'
						)
					)
				)
			)
        );
    }

	/**
	 * Method for retrieving the dynamic properties, used by the new list component.
	 *
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	protected function dynamic_properties()
	{
		return array(
			'_connected_object' => array(
				C__PROPERTY__INFO => array(
					C__PROPERTY__INFO__TITLE => 'LC__CONTACT__TREE__GROUP_MEMBERS',
					C__PROPERTY__INFO__DESCRIPTION => 'Person group memberships'
				),
				C__PROPERTY__FORMAT => array(
					C__PROPERTY__FORMAT__CALLBACK => array(
						$this,
						'dynamic_property_callback_connected_object'
					)
				),
				C__PROPERTY__PROVIDES => array(
					C__PROPERTY__PROVIDES__LIST => true
				)
			)
		);
	} // function

	/**
	 * Dynamic property handling for retrieving the assigned person groups.
	 *
	 * @param   array  $p_row
	 * @return  string
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function dynamic_property_callback_connected_object(array $p_row)
	{
		global $g_comp_database;

		$l_return = array();
		$l_quickinfo = new isys_ajax_handler_quick_info();

		$l_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_person_assigned_groups', $g_comp_database);
		$l_res = $l_dao->get_data(null, $p_row['isys_obj__id']);

		if ($l_res->num_rows() > 0)
		{
			while ($l_row = $l_res->get_row())
			{
				if ($l_row !== false && $l_row['isys_person_2_group__isys_obj__id__group'] > 0)
				{
					$l_return[] = $l_quickinfo->get_quick_info(
						$l_row['isys_person_2_group__isys_obj__id__group'],
						$l_row["isys_cats_person_group_list__title"],
						C__LINK__OBJECT);
				} // if
			} // while
		} // if


		return implode(', ', $l_return);
	} // function

	/**
	 * Callback function for dataretrieval for UI
	 *
	 * @param isys_request $p_request
	 * @return isys_component_dao_result
	 */
	public function callback_property_connected_object(isys_request $p_request){
		$l_obj_id = $p_request->get_object_id();

		return $this->get_data(null, $l_obj_id);
	}

	/**
	 * Return Category Data
	 *
	 * @param [int $p_id]h
	 * @param [int $p_obj_id]
	 * @param [string $p_condition]
	 *
	 * @return isys_component_dao_result
	 */
	public function get_data($p_id=null, $p_obj_id=null, $p_condition="", $p_filter=null, $p_status=null) {
		$p_condition .= $this->prepare_filter($p_filter);

		$l_sql = "SELECT *, mail_person.isys_catg_mail_addresses_list__title AS isys_cats_person_list__mail_address, ".
						"mail_pgroup.isys_catg_mail_addresses_list__title AS isys_cats_person_group_list__email_address ".
					"FROM isys_person_2_group ".
					"INNER JOIN isys_cats_person_list ".
						"ON ".
						"isys_person_2_group__isys_obj__id__person = isys_cats_person_list__isys_obj__id ".
					"INNER JOIN isys_cats_person_group_list ".
						"ON ".
						"isys_person_2_group__isys_obj__id__group = isys_cats_person_group_list__isys_obj__id ".
					"LEFT JOIN isys_catg_mail_addresses_list AS mail_person ".
						"ON ".
						"mail_person.isys_catg_mail_addresses_list__isys_obj__id = isys_cats_person_list__isys_obj__id AND mail_person.isys_catg_mail_addresses_list__primary = 1 ".
					"LEFT JOIN isys_catg_mail_addresses_list AS mail_pgroup ".
						"ON ".
						"mail_pgroup.isys_catg_mail_addresses_list__isys_obj__id = isys_cats_person_group_list__isys_obj__id AND mail_pgroup.isys_catg_mail_addresses_list__primary = 1 ".
					"WHERE TRUE ";

		$l_sql .= $p_condition;

		if (!empty($p_id))
		{
			$l_sql .= " AND (isys_person_2_group__id = '{$p_id}')";
		}

		if (!empty($p_obj_id))
		{
			$l_sql .= $this->get_object_condition($p_obj_id);
		}

		return $this->retrieve($l_sql . ' GROUP BY isys_cats_person_group_list__id;');
	}

	/**
	 * Creates the condition to the object table
	 *
	 * @param int|array $p_obj_id
	 * @return string
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function get_object_condition($p_obj_id = null){
		$l_sql = '';

		if (!empty($p_obj_id)) {
			if(is_array($p_obj_id)){
				$l_sql = ' AND (isys_person_2_group__isys_obj__id__person ' . $this->prepare_in_condition($p_obj_id) . ') ';
			} else{
				$l_sql = ' AND (isys_person_2_group__isys_obj__id__person = '.$this->convert_sql_id($p_obj_id).') ';
			}
		}
		return $l_sql;
	}

	/**
	 * Synchronizes properties from an import with the database.
	 *
	 * @param   array    $p_category_data  Values of category data to be saved.
	 * @param   integer  $p_object_id      Current object identifier (from database).
	 * @param   integer  $p_status         Decision whether category data should be created or just updated.
	 * @return  mixed  Returns category data identifier (int) on success, true (bool) if nothing had to be done, otherwise false.
	 */
	public function sync($p_category_data, $p_object_id, $p_status = isys_import_handler_cmdb::C__CREATE)
	{
		$l_indicator = false;
		if(is_array($p_category_data) && isset($p_category_data['properties']))
		{
			// Create category data identifier if needed.
			if ($p_status === isys_import_handler_cmdb::C__CREATE)
			{
				$p_category_data['data_id'] = $this->attach_group($p_object_id,
																  $p_category_data['properties']['connected_object'][C__DATA__VALUE]);
				if($p_category_data['data_id'] > 0)
				{
					$l_indicator = true;
				}
			} // if
		}
		return ($l_indicator === true)? $p_category_data['data_id']: false;
	} // function


	/**
	 * Save specific category monitor.
	 *
	 * @param  integer  $p_cat_level
	 * @param  integer  &$p_intOldRecStatus
	 * @param  null
	 */
	public function save_element($p_cat_level, &$p_intOldRecStatus)
	{
		return null;
	} // function


	/**
	 * Method for attaching a new group.
	 *
	 * @param   integer  $p_person_id
	 * @param   integer  $p_group_id
	 * @return  boolean
	 */
	public function attach_group($p_person_id, $p_group_id)
	{
		$l_sql = "INSERT INTO isys_person_2_group SET ".
			"isys_person_2_group__isys_obj__id__person = '".$p_person_id."', ".
			"isys_person_2_group__isys_obj__id__group = '".$p_group_id."';";

		if ($this->update($l_sql) && $this->apply_update())
		{
			$l_last_id = $this->get_last_insert_id();

			$l_relation_dao = new isys_cmdb_dao_category_g_relation($this->get_database_component());
			$l_relation_dao->handle_relation($this->get_last_insert_id(), "isys_person_2_group", C__RELATION_TYPE__PERSON_ASSIGNED_GROUPS, null, $p_group_id, $p_person_id);

			// delete auth cache of the person
			isys_caching::factory('auth-'.$p_person_id)->clear();
			return $l_last_id;
		} else{
			return false;
		}
	} // function


	/**
	 * Save method.
	 *
	 * @param   integer  $p_objID
	 * @param   array    $p_groups
	 * @return  boolean
	 */
	public function save($p_objID, $p_groups)
	{
		$l_edit_right = isys_auth::factory(C__MODULE__CMDB)->has_rights_in_obj_and_category(isys_auth::SUPERVISOR, $p_objID, $this->get_category_const());

		if (! $l_edit_right)
		{
			return false;
		} // if

		$l_data = $this->get_data(null, $p_objID);

		while ($l_row = $l_data->get_row())
		{
			if (! empty($l_row))
			{
				$l_current_groups[$l_row["isys_person_2_group__isys_obj__id__group"]] = $l_row["isys_person_2_group__id"];
			} // if
		} // while

		if (count($p_groups) > 0)
		{
			foreach ($p_groups as $l_group)
			{
				if (!@$l_current_groups[$l_group] && !empty($l_group))
				{
					$this->attach_group($p_objID, $l_group);
				} // if
			} // foreach
		} // if

		return $this->apply_update();
	} // function


	/**
	 * Save global category monitor element.
	 *
	 * @param   integer  $p_cat_level
	 * @param   integer  &$p_new_id
	 * @return  mixed
	 */
	public function create_element ($p_cat_level, &$p_new_id)
	{
		global $g_comp_template_infobox;

		$l_edit_right = isys_auth::factory(C__MODULE__CMDB)->has_rights_in_obj_and_category(isys_auth::SUPERVISOR, $_GET[C__CMDB__GET__OBJECT], $this->get_category_const());

		if (! $l_edit_right)
		{
			return 0;
		} // if

		$l_existing = array();
		$l_save = array();

		// Removed: isys_rs_system

		// Select all items from the database-table for deleting them.
		$l_res = $this->get_assigned_contacts($_GET[C__CMDB__GET__OBJECT]);

		// Get the array of ID's from our json-string.
		$l_objects = (array) isys_format_json::decode($_POST[C__POST__POPUP_RECEIVER]);

		$l_auth_obj = isys_auth::factory(C__MODULE__CMDB);
		$l_not_allowed_objects = array();

		while ($l_row = $l_res->get_row())
		{
			$l_existing[] = $l_row['isys_obj__id'];

			// Collect only items, which are not to be saved.
			if (!in_array($l_row['isys_obj__id'], $l_objects))
			{
				if($l_auth_obj->is_allowed_to(isys_auth::EDIT, 'OBJ_ID/'.$l_row['isys_obj__id']))
				{
					$l_sql = 'DELETE FROM isys_person_2_group
						WHERE isys_person_2_group__isys_obj__id__group = ' . $this->convert_sql_id($l_row['isys_obj__id']) . '
						AND isys_person_2_group__isys_obj__id__person = ' . $this->convert_sql_id($_GET[C__CMDB__GET__OBJECT]) . ' LIMIT 1';

					$this->update($l_sql);
				}
				else
				{
					$l_not_allowed_objects[$l_row['isys_obj__id']] = $l_row['isys_obj__title'];
				}
			} // if
		} // while

		// Now insert new items.
		if (count($l_objects) > 0)
		{
			foreach ($l_objects as $l_object)
			{
				// But don't insert any items, that already exist!
				if (!in_array($l_object, $l_existing))
				{
					if ($l_object > 0)
					{
						// Create the new items.
						if($l_auth_obj->is_allowed_to(isys_auth::EDIT, 'OBJ_ID/'.$l_object))
						{
							$l_save[] = $l_object;
						}
						else if(!array_key_exists($l_object, $l_not_allowed_objects))
						{
							$l_not_allowed_objects[$l_object] = $this->get_obj_name_by_id_as_string($l_object);
						}
					} // if
				} // if
			} // foreach

			if (count($l_save) > 0)
			{
				$l_bRet = $this->save($_GET[C__CMDB__GET__OBJECT], $l_save);
			} // if
			if(count($l_not_allowed_objects) > 0)
			{
				$l_message = 'Error: No rights to modify person groups (';
				foreach($l_not_allowed_objects AS $l_obj_id => $l_obj_name)
				{
					$l_message .= $l_obj_name.', ';
				}
				$l_message = rtrim($l_message, ', ').').';
				$g_comp_template_infobox->set_message($l_message, 1, null, null, C__LOGBOOK__ALERT_LEVEL__3);
			}
		} // if

		// delete auth cache of the person
		isys_caching::factory('auth-'.$_GET[C__CMDB__GET__OBJECT])->clear();
		return ($l_bRet ? 0 : false);
	} // function


	public function rank_records ($p_objects, $p_direction, $p_table)
	{
		if ($p_direction == C__CMDB__RANK__DIRECTION_RECYCLE)
		{
			return true;
		}

		$l_relation_dao = new isys_cmdb_dao_category_g_relation($this->get_database_component());

		$l_update = "DELETE FROM isys_person_2_group WHERE FALSE";

		foreach ($p_objects as $l_id)
		{
			$l_edit_right = isys_auth::factory(C__MODULE__CMDB)->has_rights_in_obj_and_category(isys_auth::SUPERVISOR, $_GET[C__CMDB__GET__OBJECT], $this->get_category_const());

			if (! $l_edit_right)
			{
				continue;
			} // if

			$l_update .= " OR isys_person_2_group__id = " . $this->convert_sql_id($l_id);

			$l_data = $this->get_data($l_id)->__to_array();
			if ($l_data["isys_person_2_group__isys_catg_relation_list__id"] > 0)
			{
				$l_relation_dao->delete_relation($l_data["isys_person_2_group__isys_catg_relation_list__id"]);
			}
		}

		return ($this->update($l_update) && $this->apply_update());
	} // function


	/**
	 * @return TRUE if posted Data is verified, FALSE if not
	 * @desc verifiy posted data, save set_additional_rules and validation state for further usage..
	 */
	public function validate_user_data() {
		$l_retValid = true;
		$l_arrTomAdditional = array();

		if ($_POST["C__CONTACT__PERSON_PASSWORD"] != $_POST["C__CONTACT__PERSON_PASSWORD_SECOND"])
		{
			$l_arrTomAdditional["C__CONTACT__PERSON_PASSWORD_SECOND"]["p_strInfoIconError"] = _L("LC__LOGIN__PASSWORDS_DONT_MATCH");
		}

		if (count($l_arrTomAdditional) > 0) {
			$l_retValid = false;
		}

		//	save the array when post data is invalid
		$this->set_additional_rules($l_retValid == false ? $l_arrTomAdditional : null);

		$this->set_validation($l_retValid);

		return $l_retValid;
	}

	public function get_count($p_obj_id = null){

		if(!empty($p_obj_id))
			$l_obj_id = $p_obj_id;
		else $l_obj_id = $this->m_object_id;

		$l_sql = "SELECT COUNT(isys_cats_person_list__id) AS count FROM isys_person_2_group ".
					"INNER JOIN isys_cats_person_list ".
						"ON ".
						"isys_person_2_group__isys_obj__id__person = isys_cats_person_list__isys_obj__id ".
					"INNER JOIN isys_cats_person_group_list ".
						"ON ".
						"isys_person_2_group__isys_obj__id__group = isys_cats_person_group_list__isys_obj__id ".
					"WHERE TRUE ";

		if (!empty($this->m_object_id)) {
			$l_sql .= " AND (isys_person_2_group__isys_obj__id__person = ".$this->convert_sql_id($l_obj_id).")";
		}

		$l_data = $this->retrieve($l_sql)->__to_array();

		return $l_data["count"];
	}

	/**
	 * This method gets the assigned contacts by an object-id for the contact-browser.
	 *
	 * @param   integer  $p_obj_id
	 * @return  isys_component_dao_result
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_assigned_contacts($p_obj_id)
	{
		// Prepare SQL statement for retrieving contacts, assigned to a certain object.
		$l_sql = "SELECT obj.isys_obj__id, obj.isys_obj__title, obj.isys_obj__isys_obj_type__id, obj.isys_obj__sysid " .
			"FROM isys_person_2_group AS p2g " .
			"LEFT JOIN isys_obj AS obj " .
			"ON obj.isys_obj__id = p2g.isys_person_2_group__isys_obj__id__group " .
			"WHERE p2g.isys_person_2_group__isys_obj__id__person = " . ($p_obj_id + 0) . ";";
		return $this->retrieve($l_sql);
	} // function

} // class

?>