<?php

/**
 * i-doit
 *
 * DAO: specific category for DHCP
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Leonard Fischer <lfischer@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       0.9.9-8
 */
class isys_cmdb_dao_category_s_net_dhcp extends isys_cmdb_dao_category_specific
{
    /**
     * Category's name. Will be used for the identifier, constant, main table, and many more.
     * @var  string
     */
    protected $m_category = 'net_dhcp';

    /**
     * Method for returning the properties.
     *
     * @return  array
     */
    protected function properties()
    {
        return array(
            'type' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::dialog(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__NET__DHCPV4_TYPE',
                        C__PROPERTY__INFO__DESCRIPTION => 'Type v4'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_net_dhcp_list__isys_net_dhcp_type__id',
                        C__PROPERTY__DATA__REFERENCES => array(
                            'isys_net_dhcp_type',
                            'isys_net_dhcp_type__id'
                        )
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CMDB__CATS__NET_DHCP__TYPE',
                        C__PROPERTY__UI__PARAMS => array(
                            'p_strTable'   =>  'isys_net_dhcp_type',
                            'p_bDbFieldNN' =>  '1',
                        )
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false
                    )
                )
            ),
            'typev6' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::dialog(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__NET__DHCPV6_TYPE',
                        C__PROPERTY__INFO__DESCRIPTION => 'Type v6'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id',
                        C__PROPERTY__DATA__REFERENCES => array(
                            'isys_net_dhcpv6_type',
                            'isys_net_dhcpv6_type__id'
                        )
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CMDB__CATS__NET_DHCP__TYPEV6',
                        C__PROPERTY__UI__PARAMS => array(
                            'p_strTable' => 'isys_net_dhcpv6_type',
                            'p_bDbFieldNN' =>  '1',
                        )
                    ),
                    C__PROPERTY__PROVIDES => array(
                        C__PROPERTY__PROVIDES__SEARCH => false
                    )
                )
            ),
            'range_from' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::text(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__NET__DHCP_RANGE_FROM',
                        C__PROPERTY__INFO__DESCRIPTION => 'DHCP from'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_net_dhcp_list__range_from'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CATS__NET_DHCP_RANGE_FROM'
                    )
                )
            ),
            'range_to' => array_replace_recursive(
                isys_cmdb_dao_category_pattern::text(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__NET__DHCP_RANGE_TO',
                        C__PROPERTY__INFO__DESCRIPTION => 'DHCP to'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_net_dhcp_list__range_to'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CATS__NET_DHCP_RANGE_TO'
                    )
                )
            ),
            'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
                array(
                    C__PROPERTY__INFO => array(
                        C__PROPERTY__INFO__TITLE => 'LC__CMDB__LOGBOOK__DESCRIPTION',
                        C__PROPERTY__INFO__DESCRIPTION => 'Description'
                    ),
                    C__PROPERTY__DATA => array(
                        C__PROPERTY__DATA__FIELD => 'isys_cats_net_dhcp_list__description'
                    ),
                    C__PROPERTY__UI => array(
                        C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_SPECIFIC . C__CATS__NET_DHCP
                    )
                )
            )
        );
    }


	/**
	 * Executes the query to create the category entry.
	 *
	 * @param   integer  $p_obj_id
	 * @param   integer  $p_type
	 * @param   integer  $p_typev6
	 * @param   integer  $p_ip_range_from
	 * @param   integer  $p_ip_range_to
	 * @param   string   $p_description
	 * @param   integer  $p_status
	 * @return  integer
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function create($p_obj_id = null, $p_type = null, $p_typev6 = null, $p_ip_range_from = null, $p_ip_range_to = null, $p_description = null, $p_status = C__RECORD_STATUS__NORMAL)
	{
		if ($p_obj_id === null)
		{
			$p_obj_id = $_GET[C__CMDB__GET__OBJECT];
		}

		if (!isys_helper_ip::validate_ip($p_ip_range_from) && empty($p_typev6))
		{
			$p_typev6 = C__NET__DHCPV6__DHCPV6;
		}
		elseif(isys_helper_ip::validate_ip($p_ip_range_from) && !empty($p_typev6))
		{
			$p_typev6 = null;
		} // if

		$l_ip_dao = new isys_cmdb_dao_category_g_ip($this->m_db);
		$l_ip_dao->update_ip_assignment_by_ip_range(
			$p_obj_id,
			$p_type,
			$p_typev6,
			$p_ip_range_from,
			$p_ip_range_to);

		$l_sql = 'INSERT INTO ' . $this->m_table . ' (' .
				$this->m_table . '__isys_obj__id, ' .
				$this->m_table . '__isys_net_dhcp_type__id, ' .
				$this->m_table . '__isys_net_dhcpv6_type__id, ' .
				$this->m_table . '__range_from, ' .
				$this->m_table . '__range_from_long, ' .
				$this->m_table . '__range_to, ' .
				$this->m_table . '__range_to_long, ' .
				$this->m_table . '__description, ' .
				$this->m_table . '__status' .
			') VALUES (' .
				$this->convert_sql_id($p_obj_id) . ', ' .
				$this->convert_sql_id($p_type) . ', ' .
				$this->convert_sql_id($p_typev6) . ', ' .
				$this->convert_sql_text($p_ip_range_from) . ', ' .
				$this->convert_sql_text(isys_helper_ip::ip2long($p_ip_range_from)) . ', ' .
				$this->convert_sql_text($p_ip_range_to) . ', ' .
				$this->convert_sql_text(isys_helper_ip::ip2long($p_ip_range_to)) . ', ' .
				$this->convert_sql_text($p_description) . ', ' .
				$this->convert_sql_int($p_status) . ');';

		if ($this->update($l_sql) && $this->apply_update())
		{
			return $this->get_last_insert_id();
		}
		else
		{
			return false;
		} // if
	} // function


	/**
	 * Method for deleting DHCP ranges.
	 *
	 * @param   integer  $p_id
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function delete($p_id)
	{
		$l_res = $this->get_data($p_id)->get_row();

		// We have to assign the "ip assignment" to static, because we delete this dhcp range.
		$l_ip_dao = new isys_cmdb_dao_category_g_ip($this->m_db);
		$l_ip_dao->update_ip_assignment_by_ip_range(
			$l_res['isys_cats_net_dhcp_list__isys_obj__id'],
			C__CATP__IP__ASSIGN__STATIC,
			$l_res['isys_cats_net_dhcp_list__range_from'],
			$l_res['isys_cats_net_dhcp_list__range_to']);

		// And after that, we can happily delete our range.
		$l_sql = 'DELETE FROM ' . $this->m_table . ' ' .
			'WHERE ' . $this->m_table . '__id = ' . $this->convert_sql_id($p_id);

		return $this->update($l_sql) && $this->apply_update();
	} // function


	/**
	 * With this method, we can find every DHCPv4 range conflict, before we actually start messing with the database.
	 *
	 * @param   integer  $p_obj_id
	 * @param   string   $p_from
	 * @param   string   $p_to
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function find_range_conflicts($p_obj_id, $p_from, $p_to, $p_status = C__RECORD_STATUS__NORMAL)
	{
		if (! empty($p_from) && ! empty($p_to))
		{
			$l_sql = 'SELECT * FROM ' . $this->m_table . ' ' .
				'WHERE (( ' .
					$this->m_table . '__range_from_long BETWEEN ' . isys_helper_ip::ip2long($p_from) . ' ' .
					'AND ' . isys_helper_ip::ip2long($p_to) . ') ' .
				'OR (' .
					$this->m_table . '__range_to_long BETWEEN ' . isys_helper_ip::ip2long($p_from) . ' ' .
					'AND ' . isys_helper_ip::ip2long($p_to) . ') ' .
				'OR (' .
					$this->m_table . '__range_from_long <= ' . isys_helper_ip::ip2long($p_from) . ' ' .
					'AND ' . $this->m_table . '__range_to_long >= ' . isys_helper_ip::ip2long($p_to) . ') ' .
				'OR (' .
					$this->m_table . '__range_from_long >= ' . isys_helper_ip::ip2long($p_from) . ' ' .
					'AND ' . $this->m_table . '__range_to_long <= ' . isys_helper_ip::ip2long($p_to) . ')) ' .
				'AND ' . $this->m_table . '__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ' ' .
				'AND ' . $this->m_table . '__status = ' . $this->convert_sql_int($p_status) . ' ' .
				'ORDER BY ' . $this->m_table . '__range_from_long ASC;';

			return $this->retrieve($l_sql);
		} // if

		return null;
	} // function


	/**
	 * With this method, we can find every DHCPv6 range conflict, before we actually start messing with the database.
	 *
	 * @param   integer  $p_obj_id
	 * @param   string   $p_from
	 * @param   string   $p_to
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function find_ipv6_range_conflicts($p_obj_id, $p_from, $p_to = null, $p_status = C__RECORD_STATUS__NORMAL)
	{
		if (! empty($p_from))
		{
			if ($p_to === null)
			{
				$p_to = $p_from;
			} // if

			$l_ip_dao = new isys_cmdb_dao_category_g_ip($this->m_db);

			$l_from = isys_helper_ip::validate_ipv6($p_from);
			$l_to = isys_helper_ip::validate_ipv6($p_to);

			$l_sql = 'SELECT * FROM ' . $this->m_table . ' ' .
				'WHERE (( ' .
					$this->m_table . '__range_from BETWEEN "' . $l_from . '" ' .
					'AND "' . $l_to . '") ' .
				'OR (' .
					$this->m_table . '__range_to BETWEEN "' . $l_from . '" ' .
					'AND "' . $l_to . '") ' .
				'OR (' .
					$this->m_table . '__range_from <= "' . $l_from . '" ' .
					'AND ' . $this->m_table . '__range_to >= "' . $l_to . '") ' .
				'OR (' .
					$this->m_table . '__range_from >= "' . $l_from . '" ' .
					'AND ' . $this->m_table . '__range_to <= "' . $l_to . '")) ' .
				'AND ' . $this->m_table . '__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ' ' .
				'AND ' . $this->m_table . '__status = ' . $this->convert_sql_int($p_status) . ' ' .
				'ORDER BY ' . $this->m_table . '__range_from_long ASC;';

			return $this->retrieve($l_sql);
		} // if

		return null;
	} // function


	/**
	 * Method for merging a new DHCP range inside an existing.
	 *
	 * @param   integer  $p_obj_id  The object-ID of the layer3 net.
	 * @param   integer  $p_type    The assignment type from "isys_net_dhcp_type".
	 * @param   string   $p_from    The starting IP-address.
	 * @param   string   $p_to      The ending IP-address (if left empty this parameter will be set to the "from" value).
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function check_and_merge_new_dhcp_range_inside_existing($p_obj_id, $p_type, $p_from, $p_to = null)
	{
		if ($p_to === null)
		{
			$p_to = $p_from;
		} // if

		// With this method we check, if there will be any conflicts.
		$l_conflict_ids = $this->find_range_conflicts($p_obj_id, $p_from, $p_to);

		// Now we check, if the method retrieved any conflicted ID's for us.
		if ($l_conflict_ids->num_rows() > 0)
		{
			while ($l_row = $l_conflict_ids->get_row())
			{
				// We save all entries.
				$l_dhcp_ranges[] = $l_row;

				// And delete them - So now we can start from scratch.
				$this->delete($l_row['isys_cats_net_dhcp_list__id']);
			} // while

			// We set the new FROM and TO values as default, but check this in the next IF-statements.
			$l_new_range_from = $p_from;
			$l_new_range_to = $p_to;

			// We get ourselves the first and last entry of the array.
			$l_first = current($l_dhcp_ranges);
			$l_last = end($l_dhcp_ranges);

			// Please note: We can only check this because it was ordered by the FROM range.
			if ($l_first['isys_cats_net_dhcp_list__range_from_long'] < isys_helper_ip::ip2long($l_new_range_from))
			{
				// Now we check for the type - If it's the same, we merge.
				if ($l_first['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'] == $p_type)
				{
					$l_new_range_from = $l_first['isys_cats_net_dhcp_list__range_from'];
				}
				else
				{
					// If the types are not the same, we have to restore the first range.
					$this->create(
						$p_obj_id,
						$l_first['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'],
						null,
						$l_first['isys_cats_net_dhcp_list__range_from'],
						isys_helper_ip::long2ip(isys_helper_ip::ip2long($l_new_range_from) - 1),
						$l_first['isys_cats_net_dhcp_list__description'],
						$l_first['isys_cats_net_dhcp_list__status']);
				} // if
			} // if

			// In the last entry there has to be the most last range.
			if ($l_last['isys_cats_net_dhcp_list__range_to_long'] > isys_helper_ip::ip2long($l_new_range_to))
			{
				// Now we check for the type - If it's the same, we merge.
				if ($l_last['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'] == $p_type)
				{
					$l_new_range_to = $l_last['isys_cats_net_dhcp_list__range_to'];
				}
				else
				{
					// If the types are not the same, we have to restore the range.
					$this->create(
						$p_obj_id,
						$l_last['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'],
						null,
						isys_helper_ip::long2ip(isys_helper_ip::ip2long($l_new_range_to) + 1),
						$l_last['isys_cats_net_dhcp_list__range_to'],
						$l_last['isys_cats_net_dhcp_list__description'],
						$l_last['isys_cats_net_dhcp_list__status']);
				} // if
			} // if

			$this->create(
				$p_obj_id,
				$p_type,
				null,
				$l_new_range_from,
				$l_new_range_to,
				'',
				C__RECORD_STATUS__NORMAL);

			$l_return = array('result' => 'merged');
		}
		else
		{
			// When the array is empty, we can blindly create a new DHCP range.
			$this->create(
				$p_obj_id,
				$p_type,
				null,
				$p_from,
				$p_to,
				'',
				C__RECORD_STATUS__NORMAL);

			$l_return = array('result' => 'success');
		} // if

		return $l_return;
	} // function


	/**
	 * Method for merging a new DHCPv6 range inside an existing.
	 *
	 * @param   integer  $p_obj_id  The object-ID of the layer3 net.
	 * @param   integer  $p_type    The assignment type from "isys_net_dhcpv6_type".
	 * @param   string   $p_from    The starting IP-address.
	 * @param   string   $p_to      The ending IP-address (if left empty this parameter will be set to the "from" value).
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function check_and_merge_new_dhcpv6_range_inside_existing($p_obj_id, $p_type, $p_from, $p_to = null)
	{
		if ($p_to === null)
		{
			$p_to = $p_from;
		} // if

		$l_ip_dao = new isys_cmdb_dao_category_g_ip($this->m_db);

		// With this method we check, if there will be any conflicts.
		$l_conflict_ids = $this->find_ipv6_range_conflicts($p_obj_id, $p_from, $p_to);

		// Now we check, if the method retrieved any conflicted ID's for us.
		if ($l_conflict_ids->num_rows() > 0)
		{
			while ($l_row = $l_conflict_ids->get_row())
			{
				// We save all entries.
				$l_dhcp_ranges[] = $l_row;

				// And delete them - So now we can start from scratch.
				$this->delete($l_row['isys_cats_net_dhcp_list__id']);
			} // while

			// We set the new FROM and TO values as default, but check this in the next IF-statements.
			$l_new_range_from = $p_from;
			$l_new_range_to = $p_to;

			// We get ourselves the first and last entry of the array.
			$l_first = current($l_dhcp_ranges);
			$l_last = end($l_dhcp_ranges);

			// Please note: We can only check this because it was ordered by the FROM range.
			if (strcmp($l_first['isys_cats_net_dhcp_list__range_from'], isys_helper_ip::validate_ipv6($l_new_range_from)) < 0)
			{
				// Now we check for the type - If it's the same, we merge.
				if ($l_first['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'] == $p_type)
				{
					$l_new_range_from = $l_first['isys_cats_net_dhcp_list__range_from'];
				}
				else
				{
					// If the types are not the same, we have to restore the first range.
					$this->create(
						$p_obj_id,
						null,
						$l_first['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'],
						$l_first['isys_cats_net_dhcp_list__range_from'],
						isys_helper_ip::calculate_prev_ipv6($l_new_range_from),
						$l_first['isys_cats_net_dhcp_list__description'],
						$l_first['isys_cats_net_dhcp_list__status']);
				} // if
			} // if

			// In the last entry there has to be the most last range.
			if (strcmp($l_last['isys_cats_net_dhcp_list__range_to'], isys_helper_ip::validate_ipv6($l_new_range_to)) > 0)
			{
				// Now we check for the type - If it's the same, we merge.
				if ($l_last['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'] == $p_type)
				{
					$l_new_range_to = $l_last['isys_cats_net_dhcp_list__range_to'];
				}
				else
				{
					// If the types are not the same, we have to restore the range.
					$this->create(
						$p_obj_id,
						null,
						$l_last['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'],
						isys_helper_ip::calculate_next_ipv6($l_new_range_to),
						$l_last['isys_cats_net_dhcp_list__range_to'],
						$l_last['isys_cats_net_dhcp_list__description'],
						$l_last['isys_cats_net_dhcp_list__status']);
				} // if
			} // if

			$this->create(
				$p_obj_id,
				null,
				$p_type,
				$l_new_range_from,
				$l_new_range_to,
				'',
				C__RECORD_STATUS__NORMAL);

			$l_return = array('result' => 'merged');
		}
		else
		{
			// When the array is empty, we can blindly create a new DHCP range.
			$this->create(
				$p_obj_id,
				null,
				$p_type,
				$p_from,
				$p_to,
				'',
				C__RECORD_STATUS__NORMAL);

			$l_return = array('result' => 'success');
		} // if

		return $l_return;
	} // function

	/**
	 * Return Category Data.
	 *
	 * @param   integer  $p_id
	 * @param   integer  $p_obj_id
	 * @param   string   $p_condition
	 * @param   mixed    $p_filter
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_data($p_id = null, $p_obj_id = null, $p_condition = '', $p_filter = null, $p_status = null)
	{
		$p_condition .= $this->prepare_filter($p_filter);
		$l_sql = 'SELECT * FROM ' . $this->m_table . ' ' .
			' LEFT JOIN isys_net_dhcp_type ON ' . $this->m_table . '__isys_net_dhcp_type__id = isys_net_dhcp_type__id ' .
			' LEFT JOIN isys_net_dhcpv6_type ON ' . $this->m_table . '__isys_net_dhcpv6_type__id = isys_net_dhcpv6_type__id '.
			'WHERE TRUE ' . $p_condition . ' ';

		if ($p_id !== null)
		{
			$l_sql .= 'AND ' . $this->m_table . '__id = ' . $this->convert_sql_id($p_id) . ' ';
		} // if

		if ($p_obj_id !== null)
		{
			$l_sql .= $this->get_object_condition($p_obj_id);
		} // if

		if ($p_status !== null)
		{
			$l_sql .= 'AND ' . $this->m_table . '__status = ' . $this->convert_sql_int($p_status) . ' ';
		} // if

		$l_sql .= ' ORDER BY ' . $this->m_table . '__range_from_long ASC';

		return $this->retrieve($l_sql . ';');
	} // function

	/**
	 * Creates the condition to the object table
	 *
	 * @param int|array $p_obj_id
	 * @return string
	 * @author Van Quyen Hoang <qhoang@i-doit.de>
	 */
	public function get_object_condition($p_obj_id = NULL){
		$l_sql = '';

		if (!empty($p_obj_id)) {
			if(is_array($p_obj_id)){
				$l_sql = ' AND (' . $this->m_table . '__isys_obj__id ' . $this->prepare_in_condition($p_obj_id) . ') ';
			} else{
				$l_sql = ' AND (' . $this->m_table . '__isys_obj__id = '.$this->convert_sql_id($p_obj_id).') ';
			}
		}
		return $l_sql;
	}

	/**
	 * In this method we handle the archiving, deleting and purging of DHCP ranges.
	 *
	 * @param   integer  $p_obj
	 * @param   integer  $p_direction
	 * @param   string   $p_table
	 * @param   array    $p_check_method
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function pre_rank($p_obj, $p_direction, $p_table, $p_check_method)
	{
		// We will need the data of the entry which is beeing deleted or recycled.
		$l_old = $this->get_data($p_obj)->get_row();

		$l_net_dao = new isys_cmdb_dao_category_s_net($this->get_database_component());
		$l_net_row = $l_net_dao->get_data(null, $l_old['isys_cats_net_dhcp_list__isys_obj__id'])->get_row();

		// We only do all this stuff when we are inside a IPv4 NET.
		if($l_net_row['isys_cats_net_list__isys_net_type__id'] == C__CATS_NET_TYPE__IPV4)
		{
			if ($p_direction === C__CMDB__RANK__DIRECTION_DELETE)
			{
				// In this case, the entry is getting archived, deleted or purged - So we set the assignment to STATIC.
				$l_ip_dao = new isys_cmdb_dao_category_g_ip($this->m_db);
				$l_ip_dao->update_ip_assignment_by_ip_range(
					$l_old['isys_cats_net_dhcp_list__isys_obj__id'],
					C__CATP__IP__ASSIGN__STATIC,
					$l_old['isys_cats_net_dhcp_list__range_from'],
					$l_old['isys_cats_net_dhcp_list__range_to']);
			}
			else if ($p_direction === C__CMDB__RANK__DIRECTION_RECYCLE)
			{
				// In this case we are recovering an entry.

				// With this method we check, if there will be any conflicts.
				$l_conflict_ids = $this->find_range_conflicts(
					$l_old['isys_cats_net_dhcp_list__isys_obj__id'],
					$l_old['isys_cats_net_dhcp_list__range_from'],
					$l_old['isys_cats_net_dhcp_list__range_to']);

				// Now we check, if the method retrieved any conflicted ID's for us.
				if ($l_conflict_ids->num_rows() > 0)
				{
					while ($l_row = $l_conflict_ids->get_row())
					{
						// We save all entries.
						$l_dhcp_ranges[] = $l_row;

						// And delete them - So now we can start from scratch.
						$this->delete($l_row['isys_cats_net_dhcp_list__id']);
					} // while

					// We set the new FROM and TO values as default, but check this in the next IF-statements.
					$l_new_range_from = $l_old['isys_cats_net_dhcp_list__range_from'];
					$l_new_range_to = $l_old['isys_cats_net_dhcp_list__range_to'];

					// We get ourselves the first and last entry of the array.
					$l_first = current($l_dhcp_ranges);
					$l_last = end($l_dhcp_ranges);

					// Please note: We can only check this because it was ordered by the FROM range.
					if ($l_first['isys_cats_net_dhcp_list__range_from_long'] < isys_helper_ip::ip2long($l_new_range_from))
					{
						// Now we check for the type - If it's the same, we merge.
						if ($l_first['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'] == $l_old['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'])
						{
							$l_new_range_from = $l_first['isys_cats_net_dhcp_list__range_from'];
						}
						else
						{
							// If the types are not the same, we have to restore the first range.
							$this->create(
								$p_obj,
								$l_first['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'],
								$l_first['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'],
								$l_first['isys_cats_net_dhcp_list__range_from'],
								isys_helper_ip::long2ip(isys_helper_ip::ip2long($l_new_range_from) - 1),
								$l_first['isys_cats_net_dhcp_list__description'],
								$l_first['isys_cats_net_dhcp_list__status']);
						} // if
					} // if

					// In the last entry there has to be the most last range.
					if ($l_last['isys_cats_net_dhcp_list__range_to_long'] > isys_helper_ip::ip2long($l_new_range_to))
					{
						// Now we check for the type - If it's the same, we merge.
						if ($l_last['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'] == $l_old['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'])
						{
							$l_new_range_to = $l_last['isys_cats_net_dhcp_list__range_to'];
						}
						else
						{
							// If the types are not the same, we have to restore the range.
							$this->create(
								$p_obj,
								$l_last['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'],
								$l_last['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'],
								isys_helper_ip::long2ip(isys_helper_ip::ip2long($l_new_range_to) + 1),
								$l_last['isys_cats_net_dhcp_list__range_to'],
								$l_last['isys_cats_net_dhcp_list__description'],
								$l_last['isys_cats_net_dhcp_list__status']);
						} // if
					} // if

					$this->save(
						$l_old['isys_cats_net_dhcp_list__id'],
						$l_old['isys_cats_net_dhcp_list__isys_obj__id'],
						$l_old['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'],
						$l_old['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'],
						$l_new_range_from,
						$l_new_range_to,
						$l_old['isys_cats_net_dhcp_list__description'],
						C__RECORD_STATUS__NORMAL);
				}
				else
				{
					// When the array is empty, we can blindly create a new DHCP range.
					$this->save(
						$l_old['isys_cats_net_dhcp_list__id'],
						$l_old['isys_cats_net_dhcp_list__isys_obj__id'],
						$l_old['isys_cats_net_dhcp_list__isys_net_dhcp_type__id'],
						$l_old['isys_cats_net_dhcp_list__isys_net_dhcpv6_type__id'],
						$l_old['isys_cats_net_dhcp_list__range_from'],
						$l_old['isys_cats_net_dhcp_list__range_to'],
						$l_old['isys_cats_net_dhcp_list__description'],
						C__RECORD_STATUS__NORMAL);
				} // if
			} // if
		} // if
	} // function


	/**
	 * Executes the query to save the category entry given by its ID $p_id.
	 *
	 * @param   integer  $p_id
	 * @param   integer  $p_obj_id
	 * @param   integer  $p_type
	 * @param   integer  $p_typev6
	 * @param   integer  $p_ip_range_from
	 * @param   integer  $p_ip_range_to
	 * @param   string   $p_description
	 * @param   integer  $p_status
	 * @return  boolean true, if transaction executed successfully, else false
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function save($p_id, $p_obj_id = null, $p_type = null, $p_typev6 = null, $p_ip_range_from = null, $p_ip_range_to = null, $p_description = null, $p_status = C__RECORD_STATUS__NORMAL)
	{
		// We'll have to update the IP assignment for the old range to "static" and the new to whatever type this is.
		$l_old = $this->get_data($p_id)->get_row();

		$l_ip_dao = new isys_cmdb_dao_category_g_ip($this->m_db);
		$l_ip_dao->update_ip_assignment_by_ip_range(
			$p_obj_id,
			C__CATP__IP__ASSIGN__STATIC,
			$l_old['isys_cats_net_dhcp_list__range_from'],
			$l_old['isys_cats_net_dhcp_list__range_to']);

		$l_ip_dao->update_ip_assignment_by_ip_range(
			$p_obj_id,
			$p_type,
			$p_typev6,
			$p_ip_range_from,
			$p_ip_range_to);

		$l_sql = 'UPDATE ' . $this->m_table . ' SET ' .
			$this->m_table . '__isys_obj__id = ' . $this->convert_sql_id($p_obj_id) . ', ' .
			$this->m_table . '__isys_net_dhcp_type__id = ' . $this->convert_sql_id($p_type) . ', ' .
			$this->m_table . '__isys_net_dhcpv6_type__id = ' . $this->convert_sql_id($p_typev6) . ', ' .
			$this->m_table . '__range_from = ' . $this->convert_sql_text($p_ip_range_from) . ', ' .
			$this->m_table . '__range_from_long = ' . $this->convert_sql_text(isys_helper_ip::ip2long($p_ip_range_from)) . ', ' .
			$this->m_table . '__range_to = ' . $this->convert_sql_text($p_ip_range_to) . ', ' .
			$this->m_table . '__range_to_long = ' . $this->convert_sql_text(isys_helper_ip::ip2long($p_ip_range_to)) . ', ' .
			$this->m_table . '__description = ' . $this->convert_sql_text($p_description) . ', ' .
			$this->m_table . '__status = ' . $this->convert_sql_int($p_status) . ' ' .
			'WHERE ' . $this->m_table . '__id = ' . $this->convert_sql_id($p_id);

		if ($this->update($l_sql))
		{
			return $this->apply_update();
		}
		else
		{
			return false;
		} // if
	} // function

	/**
	 * Save category entry.
	 *
	 * @param   integer  $p_id
	 * @param   integer  $p_old_status
	 * @param   boolean  $p_create
	 * @return  integer
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function save_element($p_id, &$p_old_status, $p_create)
	{
		$l_return = false;

		// If we receive an array it's probably an IPv4 address.
		if (is_array($_POST['C__CATS__NET_DHCP_RANGE_FROM']) && is_array($_POST['C__CATS__NET_DHCP_RANGE_TO']))
		{
			$l_dhcp_ip_range_from = implode('.', $_POST['C__CATS__NET_DHCP_RANGE_FROM']);
			$l_dhcp_ip_range_to = implode('.', $_POST['C__CATS__NET_DHCP_RANGE_TO']);
		}
		else
		{
			$l_dhcp_ip_range_from = $_POST['C__CATS__NET_DHCP_RANGE_FROM'];
			$l_dhcp_ip_range_to = $_POST['C__CATS__NET_DHCP_RANGE_TO'];
		} // if

		$l_catdata = $this->get_general_data();
		$l_list_id = $l_catdata['isys_cats_net_dhcp_list__id'];

		if ($p_create)
		{
			$l_list_id = $this->create(
				$_GET[C__CMDB__GET__OBJECT],
				$_POST['C__CATS__NET_DHCP_TYPE'],
				$_POST['C__CATS__NET_DHCPV6_TYPE'],
				$l_dhcp_ip_range_from,
				$l_dhcp_ip_range_to,
				$_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()]);

			if ($l_list_id > 0)
			{
				$l_return = true;
			} // if
		}
		else
		{
			$l_return = $this->save(
				$l_list_id,
				$_GET[C__CMDB__GET__OBJECT],
				$_POST['C__CATS__NET_DHCP_TYPE'],
				$_POST['C__CATS__NET_DHCPV6_TYPE'],
				$l_dhcp_ip_range_from,
				$l_dhcp_ip_range_to,
				$_POST['C__CMDB__CAT__COMMENTARY_' . $this->get_category_type() . $this->get_category_id()]);
		} // if

		$this->m_strLogbookSQL = $this->get_last_query();

		return ($l_return == true) ? $l_list_id : -1;
	} // function


	/**
	 * Synchronizes properties from an import with the database.
	 *
	 * @param   array    $p_category_data  Values of category data to be saved.
	 * @param   int      $p_object_id      Current object identifier (from database).
	 * @param   integer  $p_status         Decision whether category data should be created or just updated.
	 * @return  mixed  Returns category data identifier (int) on success, true (bool) if nothing had to be done, otherwise false.
	 */
	public function sync($p_category_data, $p_object_id, $p_status = isys_import_handler_cmdb::C__CREATE)
	{
		$l_indicator = false;
		if(is_array($p_category_data) && isset($p_category_data['properties']))
		{
			// Create category data identifier if needed:
			if ($p_status === isys_import_handler_cmdb::C__CREATE)
			{
				$p_category_data['data_id'] = $this->create($p_object_id,
															$p_category_data['properties']['type'][C__DATA__VALUE],
															$p_category_data['properties']['typev6'][C__DATA__VALUE],
															$p_category_data['properties']['range_from'][C__DATA__VALUE],
															$p_category_data['properties']['range_to'][C__DATA__VALUE],
															$p_category_data['properties']['description'][C__DATA__VALUE]);
			} // if
			if ($p_status === isys_import_handler_cmdb::C__CREATE || $p_status === isys_import_handler_cmdb::C__UPDATE)
			{
				// Save category data.
				$l_indicator = $this->save($p_category_data['data_id'],
										$p_object_id,
										$p_category_data['properties']['type'][C__DATA__VALUE],
										$p_category_data['properties']['typev6'][C__DATA__VALUE],
										$p_category_data['properties']['range_from'][C__DATA__VALUE],
										$p_category_data['properties']['range_to'][C__DATA__VALUE],
										$p_category_data['properties']['description'][C__DATA__VALUE]);
			} // if
		}
		return ($l_indicator === true)? $p_category_data['data_id']: false;
	} // function


	/**
	 * Method for updating the range only.
	 *
	 * @param   integer  $p_id
	 * @param   string   $p_from
	 * @param   string   $p_to
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function update_ranges($p_id, $p_from = null, $p_to = null)
	{
		$l_sql = 'UPDATE ' . $this->m_table . ' SET ';

		// We use this, so we don't have to play around setting the commas at the right places.
		$l_update = array();

		if ($p_from !== null)
		{
			$l_update[] = $this->m_table . '__range_from = ' . $this->convert_sql_text($p_from). ', ' .
				$this->m_table . '__range_from_long = ' . isys_helper_ip::ip2long($p_from);
		} // if

		if ($p_to !== null)
		{
			$l_update[] = $this->m_table . '__range_to = ' . $this->convert_sql_text($p_to) . ', ' .
				$this->m_table . '__range_to_long = ' . isys_helper_ip::ip2long($p_to);
		} // if

		if (! empty($l_update))
		{
			$l_sql .= implode(' , ', $l_update) . ' WHERE ' . $this->m_table . '__id = ' . $this->convert_sql_id($p_id);

			if ($this->update($l_sql))
			{
				return $this->apply_update();
			}
			else
			{
				return false;
			} // if
		} // if

		return false;
	} // function


	/**
	 * Validates the given IP address-range and sorts it from "low" to "high" (from -> to).
	 *
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function validate_user_data()
	{
		$l_return = true;
		$l_tom_additional = array();

		$l_net_dao = new isys_cmdb_dao_category_s_net($this->get_database_component());
		$l_row = $l_net_dao->get_data(null, $_GET[C__CMDB__GET__OBJECT], '', null, C__RECORD_STATUS__NORMAL)->get_row();

		// Here we have to handle the incoming addresses as IPv4.
		if (is_array($_POST['C__CATS__NET_DHCP_RANGE_FROM']) && is_array($_POST['C__CATS__NET_DHCP_RANGE_TO']))
		{
			$l_from = isys_helper_ip::ip2long(implode('.', $_POST['C__CATS__NET_DHCP_RANGE_FROM']));
			$l_to = isys_helper_ip::ip2long(implode('.', $_POST['C__CATS__NET_DHCP_RANGE_TO']));
		}
		else
		{
			$l_from = isys_glob_ip2bin($_POST['C__CATS__NET_DHCP_RANGE_FROM']);
			$l_to = isys_glob_ip2bin($_POST['C__CATS__NET_DHCP_RANGE_TO']);
		} // if

		// If the methods return null, the function "inet_pton" (or another one) does not exist and we cannot validate.
		if ($l_from === null && $l_to === null)
		{
			return true;
		} // if

		// When the method returned false, this is no valid IP address.
		if ($l_from === false)
		{
			$l_tom_additional['C__CATS__NET_DHCP_RANGE_FROM']['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
			$l_return = false;
		} // if

		if ($l_to === false)
		{
			$l_tom_additional['C__CATS__NET_DHCP_RANGE_TO']['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
			$l_return = false;
		} // if

		if ($l_from !== false && $l_to !== false)
		{
			if ($l_row['isys_cats_net_list__isys_net_type__id'] == C__CATS_NET_TYPE__IPV4)
			{
				if (filter_var(implode('.', $_POST['C__CATS__NET_DHCP_RANGE_FROM']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false)
				{
					$l_tom_additional['C__CATS__NET_DHCP_RANGE_FROM']['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
					$l_return = false;
				} // if

				if (filter_var(implode('.', $_POST['C__CATS__NET_DHCP_RANGE_TO']), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false)
				{
					$l_tom_additional['C__CATS__NET_DHCP_RANGE_TO']['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
					$l_return = false;
				} // if
			} // if

			// Here we have to handle the incoming addresses as IPv6.
			if ($l_row['isys_cats_net_list__isys_net_type__id'] == C__CATS_NET_TYPE__IPV6)
			{
				if (function_exists('inet_pton') && function_exists('inet_pton') && defined('AF_INET6'))
				{
					// When we have these functions and installed the IPv6 compability, we can standardize the IP string.
					if (filter_var($_POST['C__CATS__NET_DHCP_RANGE_FROM'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false)
					{
						$l_tom_additional['C__CATS__NET_DHCP_RANGE_FROM']['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
						$l_return = false;
					}
					else
					{
						$_POST['C__CATS__NET_DHCP_RANGE_FROM'] = isys_helper_ip::validate_ipv6($_POST['C__CATS__NET_DHCP_RANGE_FROM']);
					} // if

					if (filter_var($_POST['C__CATS__NET_DHCP_RANGE_TO'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false)
					{
						$l_tom_additional['C__CATS__NET_DHCP_RANGE_TO']['p_strInfoIconError'] = _L('LC__UNIVERSAL__FIELD_VALUE_IS_INVALID');
						$l_return = false;
					}
					else
					{
						$_POST['C__CATS__NET_DHCP_RANGE_TO'] = isys_helper_ip::validate_ipv6($_POST['C__CATS__NET_DHCP_RANGE_TO']);
					} // if
				} // if
			} // if
		} // if

		// If the "from" value is higher than the "to" value, we simply swap them.
		if (strcmp($l_from, $l_to) > 0)
		{
			$l_tmp = $_POST['C__CATS__NET_DHCP_RANGE_TO'];

			$_POST['C__CATS__NET_DHCP_RANGE_TO'] = $_POST['C__CATS__NET_DHCP_RANGE_FROM'];
			$_POST['C__CATS__NET_DHCP_RANGE_FROM'] = $l_tmp;

			unset($l_tmp);
		} // if

		$this->set_additional_rules(($l_return == false) ? $l_tom_additional : null);
		$this->set_validation($l_return);

		return $l_return;
	} // function
} // class