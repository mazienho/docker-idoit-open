<?php

/**
 * i-doit
 *
 * DAO: specific category for applications with assigned objects.
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_category_s_application_assigned_obj extends isys_cmdb_dao_category_specific
{
    /**
     * Category's name. Will be used for the identifier, constant, main table, and many more.
     * @var  string
     */
    protected $m_category = 'application_assigned_obj';

	protected $m_tpl = 'catg__application.tpl';

    /**
     * Is category multi-valued or single-valued?
     * @var  boolean
     */
    protected $m_multivalued = true;

	/**
	 * Category's title
	 * @var string
	 */
	protected $m_table = 'isys_catg_application_list';

	/**
	 * Method for returning the properties.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function properties()
	{
		$l_return = $l_application_properties = array(
			'object' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__UNIVERSAL__INSTALLED_ON',
						C__PROPERTY__INFO__DESCRIPTION => 'Installed on'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_obj__id',
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATS__APPLICATION_OBJ_APPLICATION',
						C__PROPERTY__UI__PARAMS => array(
							'groupFilter' => "C__OBJTYPE_GROUP__INFRASTRUCTURE;C__OBJTYPE_GROUP__OTHER"
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__LIST => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'object'
						)
					)
				)),
			'assigned_license' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__LIC_ASSIGN__LICENSE',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned licence for the application'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_cats_lic_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_lic_list',
							'isys_cats_lic_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__LIC_ASSIGN__LICENSE',
						C__PROPERTY__UI__PARAMS => array(
							'groupFilter' => 'C__OBJTYPE_GROUP__SOFTWARE',
							'typeFilter' => 'C__OBJTYPE__LICENCE',
							'secondSelection' => true,
							'secondList' => 'isys_cmdb_dao_category_s_lic::object_browser',
							'secondListFormat' => 'isys_cmdb_dao_category_s_lic::format_selection',
							'readOnly' => true
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => true
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_license'
						)
					)
				)),
			'assigned_database_schema' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__DATABASE_SCHEMA',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned database schema for the application'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_catg_relation_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_database_access_list',
							'isys_cats_database_access_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_DATABASE_SCHEMATA',
						C__PROPERTY__UI__PARAMS => array(
							'typeFilter' => 'C__OBJTYPE__DATABASE_SCHEMA',
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_database_schema'
						)
					)
				)),
			'assigned_it_service' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::object_browser(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__IT_SERVICE',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned it service for the application'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_catg_relation_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_catg_its_components_list',
							'isys_catg_its_components_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_IT_SERVICE',
						C__PROPERTY__UI__PARAMS => array(
							'typeFilter' => 'C__OBJTYPE__IT_SERVICE',
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__SEARCH => false,
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false,
						C__PROPERTY__PROVIDES__MULTIEDIT => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_it_service'
						)
					)
				)),
			'assigned_variant' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::dialog(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATS__APPLICATION_VARIANT__VARIANT',
						C__PROPERTY__INFO__DESCRIPTION => 'The assigned variant for the application assignment'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__isys_cats_app_variant_list__id',
						C__PROPERTY__DATA__REFERENCES => array(
							'isys_cats_app_variant_list',
							'isys_cats_app_variant_list__id'
						)
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CATG__APPLICATION_VARIANT',
						C__PROPERTY__UI__PARAMS => array(
							'p_arData' => new isys_callback(array('isys_cmdb_dao_category_s_application_assigned_obj', 'callback_property_assigned_variant'))
						)
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__SEARCH => false
					),
					C__PROPERTY__FORMAT => array(
						C__PROPERTY__FORMAT__CALLBACK => array(
							'isys_export_helper',
							'application_assigned_obj_property_assigned_variant'
						)
					)
				)),
			'description' => array_replace_recursive(
				isys_cmdb_dao_category_pattern::commentary(),
				array(
					C__PROPERTY__INFO => array(
						C__PROPERTY__INFO__TITLE => 'LC__CMDB__CATG__DESCRIPTION',
						C__PROPERTY__INFO__DESCRIPTION => 'Description'
					),
					C__PROPERTY__DATA => array(
						C__PROPERTY__DATA__FIELD => 'isys_catg_application_list__description'
					),
					C__PROPERTY__UI => array(
						C__PROPERTY__UI__ID => 'C__CMDB__CAT__COMMENTARY_' . C__CMDB__CATEGORY__TYPE_GLOBAL . C__CATG__APPLICATION
					),
					C__PROPERTY__PROVIDES => array(
						C__PROPERTY__PROVIDES__REPORT => false,
						C__PROPERTY__PROVIDES__LIST => false
					)
				))
		);

		return $l_return;
	} // function


	/**
	 * Callback method for property assigned_variant.
	 *
	 * @param   isys_request  $p_request
	 * @return  string
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function callback_property_assigned_variant (isys_request $p_request)
	{
		global $g_comp_database;

		return serialize(isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_application_assigned_obj', $g_comp_database)->get_variants($p_request->get_object_id()));
	} // function


	/**
	 * Gets all entries from category variant from the given object id
	 *
	 * @param $p_obj_id
	 *
	 * @return array
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function get_variants($p_obj_id){
		if(is_null($p_obj_id)) return array();

		global $g_comp_database;

		$l_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_application_variant', $g_comp_database);
		$l_res = $l_dao->get_data(NULL, $p_obj_id);
		$l_data = array();
		while($l_row = $l_res->get_row()){
			$l_data[$l_row['isys_cats_app_variant_list__id']] = $l_row['isys_cats_app_variant_list__variant'];
		}
		return $l_data;
	}


	/**
	 * Return Category Data.
	 *
	 * @param   integer  $p_cats_list_id
	 * @param   integer  $p_obj_id
	 * @param   string   $p_condition
	 * @param   array    $p_filter
	 * @param   integer  $p_status
	 * @return  isys_component_dao_result
	 */
	public function get_data($p_cats_list_id = null, $p_obj_id = null, $p_condition = "", $p_filter = null, $p_status = C__RECORD_STATUS__NORMAL)
	{
		$l_dao = new isys_cmdb_dao_category_g_application($this->m_db);

		if($p_obj_id > 0)
			$l_condition = ' AND isys_connection__isys_obj__id = '.$l_dao->convert_sql_id($p_obj_id);
		else $l_condition = '';

		return $l_dao->get_data($p_cats_list_id, null, $l_condition, $p_filter, $p_status);
	} // function


	/**
	 * Save global category application element.
	 *
	 * @param   integer  $p_cat_level
	 * @param   integer  &$p_intOldRecStatus
	 * @param   boolean  $p_create
	 * @return  int|null
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function save_element(&$p_cat_level, &$p_intOldRecStatus, $p_create = false)
	{
		global $g_modreq;


		$l_dao_app = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_application', $this->m_db);

		$l_intErrorCode = -1;

		if (isys_glob_get_param(C__CMDB__GET__CATLEVEL) == 0 &&
			isys_glob_get_param(C__CMDB__GET__CATG) == C__CATG__OVERVIEW &&
			isys_glob_get_param(C__GET__NAVMODE) == C__NAVMODE__SAVE) {
			$p_create = true;
		}

		if ($p_create)
		{
			// Overview page and no input was given
			if (isys_glob_get_param(C__CMDB__GET__CATG) == C__CATG__OVERVIEW && empty($_POST['C__CATS__APPLICATION_OBJ_APPLICATION__HIDDEN']))
			{
				return null;
			} // if

			$l_id = $this->create(
				$_GET[C__CMDB__GET__OBJECT],
				C__RECORD_STATUS__NORMAL,
				$_POST['C__CATS__APPLICATION_OBJ_APPLICATION__HIDDEN'],
				$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()],
				$_POST["C__CATG__LIC_ASSIGN__LICENSE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_DATABASE_SCHEMATA__HIDDEN"],
				$_POST["C__CATG__APPLICATION_IT_SERVICE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_VARIANT__VARIANT"],
				$_POST["C__CATG__APPLICATION_DOCUMENT_NUMBER__TITLE"]
			);



			$this->m_strLogbookSQL = $this->get_last_query();

			if ($l_id)
			{
				$l_catdata['isys_catg_application_list__id'] = $l_id;
				$l_bRet = true;
				$p_cat_level = null;
			}
			else
			{
				throw new isys_exception_dao("Could not create category element application");
			} // if
		}
		else
		{
			$l_catdata = $this->get_result()->__to_array();
			$p_intOldRecStatus = $l_catdata["isys_catg_application_list__status"];

			$l_bRet = $this->save(
				$l_catdata['isys_catg_application_list__id'],
				C__RECORD_STATUS__NORMAL,
				$_POST['C__CATS__APPLICATION_OBJ_APPLICATION__HIDDEN'],
				$_POST["C__CMDB__CAT__COMMENTARY_" . $this->get_category_type() . $this->get_category_id()],
				$_POST["C__CATG__LIC_ASSIGN__LICENSE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_DATABASE_SCHEMATA__HIDDEN"],
				$_POST["C__CATG__APPLICATION_IT_SERVICE__HIDDEN"],
				$_POST["C__CATG__APPLICATION_VARIANT__VARIANT"],
				$_POST["C__CATG__APPLICATION_DOCUMENT_NUMBER__TITLE"]
			);

			$this->m_strLogbookSQL = $this->get_last_query();
		} // if

		if ($p_create) return $l_catdata["isys_catg_application_list__id"];

		return $l_bRet  == true ? null : $l_intErrorCode;
	} // function

    /**
     * @param   $p_category_data
     * @param   $p_object_id
     * @param   $p_status
     * @return  bool
     */
	public function sync($p_category_data, $p_object_id, $p_status = isys_import_handler_cmdb::C__CREATE)
	{
		$l_indicator = false;
		if(is_array($p_category_data) && isset($p_category_data['properties']))
		{
			$this->m_sync_catg_data = $p_category_data;
			switch ($p_status)
			{
				case isys_import_handler_cmdb::C__CREATE:
					$p_category_data['data_id'] = $this->create($p_object_id,
																C__RECORD_STATUS__NORMAL,
																$this->get_property('object'),
																$this->get_property('description'),
																$this->get_property('assigned_license'),
																$this->get_property('assigned_database_schema'),
																$this->get_property('assigned_it_service'),
																$this->get_property('assigned_variant'));
					if ($p_category_data['data_id'] > 0)
					{
						$l_indicator = true;
					}
					break;
				case isys_import_handler_cmdb::C__UPDATE:
					$l_indicator = $this->save($p_category_data['data_id'],
											C__RECORD_STATUS__NORMAL,
											$this->get_property('object'),
											$this->get_property('description'),
											$this->get_property('assigned_license'),
											$this->get_property('assigned_database_schema'),
											$this->get_property('assigned_it_service'),
											$this->get_property('assigned_variant'));

					break;
			}
		}
		return ($l_indicator === true)? $p_category_data['data_id']: false;
	} // function


	/**
	 * Executes the query to save the category entry given by its ID $p_cat_level
	 *
	 * @param   $p_cat_level
	 * @param   $p_newRecStatus
	 * @param   $p_specification
	 * @param   $p_manufacturerID
	 * @param   $p_release
	 * @param   $p_description
	 * @return  null
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function save($p_cat_level, $p_newRecStatus, $p_connectedObjID, $p_description, $p_licence, $p_database_schemata_obj, $p_it_service_obj, $p_variant = null)
	{
		$l_old_data = $this->get_data($p_cat_level)->__to_array();
		$l_app_obj_id = $l_old_data['isys_connection__isys_obj__id'];

		// Update software assignment
		$l_strSql = "UPDATE isys_catg_application_list SET ".
			"isys_catg_application_list__isys_obj__id 					= ".$this->convert_sql_id($p_connectedObjID).", ".
			"isys_catg_application_list__description					= ".$this->convert_sql_text($p_description).", ".
			"isys_catg_application_list__status 						= ".$this->convert_sql_id($p_newRecStatus).", ".
			"isys_catg_application_list__isys_cats_app_variant_list__id = ".$this->convert_sql_id($p_variant) . ", " .
			"isys_catg_application_list__isys_cats_lic_list__id			= ".$this->convert_sql_id($p_licence) ." ".
			"WHERE isys_catg_application_list__id 						= ".$this->convert_sql_id($p_cat_level);

		if ($this->update($l_strSql))
		{
			if($this->apply_update())
			{
				// Handle relation
				$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->get_database_component());
				$l_data = $this->get_data($p_cat_level)->__to_array();

				$l_relation_dao->handle_relation($p_cat_level, "isys_catg_application_list", C__RELATION_TYPE__SOFTWARE, $l_data["isys_catg_application_list__isys_catg_relation_list__id"], $p_connectedObjID, $l_app_obj_id);

				if($p_connectedObjID > 0){
					$l_data = $this->get_data($l_data["isys_catg_application_list__id"])->__to_array();

					if($l_data["isys_catg_application_list__isys_catg_relation_list__id"] != ""){
						$l_rel_data = $l_relation_dao->get_data($l_data["isys_catg_application_list__isys_catg_relation_list__id"])->__to_array();
						$l_dao_dbms_access = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_database_access', $this->get_database_component());
						$l_dao_its_comp = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_it_service_components', $this->get_database_component());

						if($p_database_schemata_obj > 0){
							$l_dbms_res = $l_dao_dbms_access->get_data(NULL, NULL, "AND isys_connection__isys_obj__id = ".$l_dao_dbms_access->convert_sql_id($l_rel_data["isys_catg_relation_list__isys_obj__id"]), NULL, C__RECORD_STATUS__NORMAL);
							if($l_dbms_res->num_rows() < 1){
								$l_dao_dbms_access->create($p_database_schemata_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"], C__RECORD_STATUS__NORMAL);
							} else{
								if($l_dao_dbms_access->delete_connection($l_rel_data["isys_catg_relation_list__isys_obj__id"])){
									$l_dao_dbms_access->create($p_database_schemata_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"], C__RECORD_STATUS__NORMAL);
								}
							}
						} else{
							$l_dao_dbms_access->delete_connection($l_rel_data["isys_catg_relation_list__isys_obj__id"]);
						}

						if($p_it_service_obj > 0){
							$l_it_service_res = $l_dao_its_comp->get_data(NULL, $p_it_service_obj, "AND isys_connection__isys_obj__id = ".$l_dao_its_comp->convert_sql_id($l_rel_data["isys_catg_relation_list__isys_obj__id"]), NULL, C__RECORD_STATUS__NORMAL);

							if($l_it_service_res->num_rows() < 1){
								$l_dao_its_comp->create($p_it_service_obj, C__RECORD_STATUS__NORMAL, $l_rel_data["isys_catg_relation_list__isys_obj__id"], "");
							} else{
								if($l_dao_its_comp->remove_component($p_it_service_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"])){
									$l_dao_its_comp->create($p_it_service_obj, C__RECORD_STATUS__NORMAL, $l_rel_data["isys_catg_relation_list__isys_obj__id"], "");
								}
							}
						} else{
							$l_dao_its_comp->remove_component($p_it_service_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"]);
						}

					}
				}

				return true;
			} else{
				return false;
			}
		} else{
			return false;
		}

	}


	/**
	 * Create method.
	 *
	 * @param   integer  $p_objID
	 * @param   integer  $p_newRecStatus
	 * @param   integer  $p_connectedObjID
	 * @param   string   $p_description
	 * @param   integer  $p_licence
	 * @param   integer  $p_database_schemata_obj
	 * @param   integer  $p_it_service_obj
	 * @param   integer  $p_variant
	 * @return  mixed
	 * @author  Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function create ($p_objID, $p_newRecStatus, $p_connectedObjID, $p_description, $p_licence = null, $p_database_schemata_obj = null, $p_it_service_obj = null, $p_variant = null)
	{
		$l_connection = isys_factory::get_instance('isys_cmdb_dao_connection', $this->m_db);

		$l_sql = "INSERT INTO isys_catg_application_list SET
			isys_catg_application_list__isys_connection__id = " . $this->convert_sql_id($l_connection->add_connection($p_objID)) . ",
			isys_catg_application_list__isys_obj__id = " . $this->convert_sql_id($p_connectedObjID) . ",
			isys_catg_application_list__description = " . $this->convert_sql_text($p_description) . ",
			isys_catg_application_list__status = " . $this->convert_sql_id($p_newRecStatus) . ",
			isys_catg_application_list__isys_cats_app_variant_list__id = " . $this->convert_sql_id($p_variant) . ",
			isys_catg_application_list__isys_cats_lic_list__id = " . $this->convert_sql_id($p_licence) . ";";

		if ($this->update($l_sql) && $this->apply_update())
		{
			$l_last_id = $this->get_last_insert_id();

			// Handle software relation.
			$l_relation_dao = isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_relation', $this->get_database_component());

			$l_relation_dao->handle_relation($l_last_id, "isys_catg_application_list", C__RELATION_TYPE__SOFTWARE, null, $p_connectedObjID, $p_objID);

			if ($p_connectedObjID > 0)
			{
				$l_data = $this->get_data($l_last_id)->get_row();

				if ($l_data["isys_catg_application_list__isys_catg_relation_list__id"] != "")
				{
					$l_rel_data = $l_relation_dao->get_data($l_data["isys_catg_application_list__isys_catg_relation_list__id"])->get_row();

					if (is_numeric($p_database_schemata_obj) && $p_database_schemata_obj > 0)
					{
						isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_s_database_access', $this->get_database_component())
							->create($p_database_schemata_obj, $l_rel_data["isys_catg_relation_list__isys_obj__id"], C__RECORD_STATUS__NORMAL);
					} // if

					if (is_numeric($p_it_service_obj) && $p_it_service_obj > 0)
					{
						isys_factory_cmdb_category_dao::get_instance('isys_cmdb_dao_category_g_it_service_components', $this->get_database_component())
							->create($p_it_service_obj, C__RECORD_STATUS__NORMAL, $l_rel_data["isys_catg_relation_list__isys_obj__id"], "");
					} // if
				} // if
			} // if

			return $l_last_id;
		}
		else
		{
			return false;
		} // if
	} // function


	/**
	 * @param   $p_objects
	 * @param   $p_direction
	 * @param   $p_table
	 * @return  boolean
	 */
	public function rank_records($p_objects, $p_direction, $p_table)
	{
		$l_dao = new isys_cmdb_dao_category_g_application($this->m_db);

		switch ($_POST[C__GET__NAVMODE])
		{
			case C__NAVMODE__ARCHIVE:
				$l_status = C__RECORD_STATUS__ARCHIVED;
			break;

			case C__NAVMODE__DELETE:
				$l_status = C__RECORD_STATUS__DELETED;
			break;

			case C__NAVMODE__RECYCLE:
				if (intval(isys_glob_get_param("cRecStatus")) == C__RECORD_STATUS__ARCHIVED)
				{
					$l_status = C__RECORD_STATUS__NORMAL;
				}
				else if (intval(isys_glob_get_param("cRecStatus")) == C__RECORD_STATUS__DELETED)
				{
					$l_status = C__RECORD_STATUS__ARCHIVED;
				} // if
			break;

			case C__NAVMODE__QUICK_PURGE:
			case C__NAVMODE__PURGE:
				if (!empty($p_objects))
				{
					foreach ($p_objects AS $l_cat_id)
					{
						$l_dao->delete($l_cat_id);
					} // foreach
				} // if
				return true;
			break;
		} // switch

		foreach ($p_objects AS $l_cat_id)
		{
			$l_dao->set_status($l_cat_id, $l_status);
		} // foreach

		return true;
	} // function

	public function get_count($p_obj_id = null)
	{
		if (! empty($p_obj_id))
		{
			$l_obj_id = $p_obj_id;
		}
		else
		{
			$l_obj_id = $this->m_object_id;
		}

		$l_sql = "SELECT COUNT(isys_catg_application_list__id) AS count FROM isys_catg_application_list " .
			"INNER JOIN isys_connection ON isys_catg_application_list__isys_connection__id = isys_connection__id " .
			"WHERE TRUE ";

		if (! empty($l_obj_id))
		{
			$l_sql .= " AND (isys_connection__isys_obj__id = ".$this->convert_sql_id($l_obj_id).")";
		}

		$l_sql .= " AND (isys_catg_application_list__status = " . $this->convert_sql_int(C__RECORD_STATUS__NORMAL) . ")";

		$l_data = $this->retrieve($l_sql)->__to_array();

		return $l_data["count"];
	} // function


	/**
	 * Validates user data.
	 *
	 * @return  boolean
	 */
	public function validate_user_data ()
	{
		$l_arrTomAdditional = array();

		if (parent::validate_user_data() === false)
		{
			$l_arrTomAdditional = $this->get_additional_rules();
		} // if

		if (empty($_POST['C__CATS__APPLICATION_OBJ_APPLICATION__HIDDEN']))
		{
			$l_arrTomAdditional["C__CATS__APPLICATION_OBJ_APPLICATION"]["p_strInfoIconError"] = '<strong>'._L('LC__CMDB__BROWSER_OBJECT__PLEASE_CHOOSE').'</strong>';
		} // if

		if (count($l_arrTomAdditional) > 0)
		{
			$this->set_additional_rules($l_arrTomAdditional);
			$this->set_validation(false);

			return false;
		} // if

		$this->set_validation(true);
		return true;
	} // function
} // class

?>