<?php
/**
 * i-doit
 *
 * List DAO parent - Will be used for all object types without an own list DAO.
 *
 * @package     i-doit
 * @subpackage  CMDB_Category_lists
 * @author      Leonard Fischer <lfischer@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       0.9.9-9
 */
class isys_cmdb_dao_list_objects extends isys_cmdb_dao_list
{
	/**
	 * Variable for the DAO result.
	 * @var  isys_component_dao_result
	 */
	protected $m_dao_result;

	/**
	 * This variable defines how many pages of the list component shall be loaded with one request.
	 * @var  integer
	 */
	protected $m_preload_pages = 30;

	/**
	 * Variable which holds the user-defined object type list (if defined).
	 * @var  array
	 */
	protected $m_list_row = null;

	/**
	 * Variable which holds the current object-type row from isys_obj_type.
	 * @var  array
	 */
	protected $m_object_type = array();

	/**
	 * Variable which holds the current user ID.
	 * @var  integer
	 */
	protected $m_user = 0;


	/**
	 * Constructor method to retrieve and save the current user ID.
	 *
	 * @global  isys_component_session  $g_comp_session
	 * @param   isys_component_database  $p_db
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function __construct($p_db)
	{
		global $g_comp_session;

		$this->m_user = (int) $g_comp_session->get_user_id();

		parent::__construct($p_db);
	} // function


	/**
	 * Find out, if the current list shall receive the "row-click" feature.
	 *
	 * @return  boolean
	 */
	public function activate_row_click()
	{
		$l_user_config = $this->load_user_config();

		if ($l_user_config === null || ! is_array($l_user_config))
		{
			return true;
		} // if

		return ($l_user_config['isys_obj_type_list__row_clickable'] == 1) ? true : false;
	} // function


	/**
	 * Method for formating the results from the database and the dynamic callbacks.
	 *
	 * @param   isys_component_dao_result  $p_result
	 * @param   array                      $p_list_config array
	 * @return  array
	 * @author  Dennis Stücken <dstuecken@i-doit.org>
	 */
	public function format_result(isys_component_dao_result $p_result, $p_list_config = array())
	{
		global $g_comp_template_language_manager;
		$l_array = array();
		$i = 0;
		$l_rowarray = array();

		// We use this little trick to apply the ID as the first array element.
		$p_list_config = array_reverse($p_list_config);
		$p_list_config[] = array(
			C__PROPERTY_TYPE__STATIC,
			false,
			'isys_obj__id',
			'__id__',
			false,
			false
		);
		$p_list_config = array_reverse($p_list_config);

		while ($l_row = $p_result->get_row())
		{
			foreach ($p_list_config as $l_config)
			{
				list($l_property_type, , $l_rowfield, $l_title, , $l_dynamic_callback) = $l_config;
                $l_value = '';

				// Check which type of property we got.
				if ($l_property_type == C__PROPERTY_TYPE__STATIC)
				{
					// We look for fields with "__isys_obj_id" in the name, because we want to display objects instead of ID's.
					if (strpos($l_rowfield, '__isys_obj__id') && is_numeric($l_row[$l_rowfield]))
					{
						$l_value = isys_cmdb_dao_category::dynamic_property_callback_object($l_row[$l_rowfield]);
					}
					else
					{
						$l_value = $g_comp_template_language_manager->get($l_row[$l_rowfield]);
					} // if
				}
				else
				{
					if (method_exists($l_dynamic_callback[0], $l_dynamic_callback[1]))
					{
						$l_value = call_user_func(array($l_dynamic_callback[0], $l_dynamic_callback[1]), $l_row);
					} // if
				} // if

				if(empty($l_value))
				{
					// Check again with other key
					if(array_key_exists($l_title.'###'.$l_property_type, $l_row))
					{
						$l_value = $g_comp_template_language_manager->get($l_row[$l_title.'###'.$l_property_type]);
					} // if
				} // if

				// Fix for numeric sorting and for strings with a starting 0.
				if (is_numeric($l_value) && '48' != ord($l_value) && strpos($l_value, '.') === false)
				{
					$l_rowarray[$g_comp_template_language_manager->get($l_title)] = $l_value;
				}
				else
				{
					$l_rowarray[$g_comp_template_language_manager->get($l_title)] = $l_value;
				} // if

				unset($l_value, $l_key);
			} // foreach

			$l_array[$i] = $l_rowarray;
			unset($l_rowarray);
			$i ++;
		} // while

		return $l_array;
	} // function


	/**
	 * Method for retrieving additional conditions to a object type.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_additional_conditions()
	{
		return '';
	} // function


	/**
	 * Method for retrieving additional joins to a object type.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_additional_joins()
	{
		return '';
	} // function


	/**
	 * Will return a isys_component_dao_result or null.
	 *
	 * @return  mixed
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_dao_result()
	{
		return $this->m_dao_result;
	} // function


	/**
	 * Method for retrieving the default JSON encoded configuration array for all object types.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_default_list_config()
	{
		return '[[' . C__PROPERTY_TYPE__DYNAMIC . ',"_id",false,"LC__CMDB__OBJTYPE__ID","isys_cmdb_dao_category_g_global::get_dynamic_properties",["isys_cmdb_dao_category_g_global","dynamic_property_callback_id"]],' .
			'[' . C__PROPERTY_TYPE__DYNAMIC . ',"_title",false,"LC__UNIVERSAL__TITLE_LINK","isys_cmdb_dao_category_g_global::get_dynamic_properties",["isys_cmdb_dao_category_g_global","dynamic_property_callback_title"]],' .
			'[' . C__PROPERTY_TYPE__DYNAMIC . ',"_location_path",false,"LC__CMDB__CATG__LOCATION_PATH","isys_cmdb_dao_category_g_location::get_dynamic_properties",["isys_cmdb_dao_category_g_location","dynamic_property_callback_location_path"]],' .
			'[' . C__PROPERTY_TYPE__DYNAMIC . ',"_created",false,"LC__TASK__DETAIL__WORKORDER__CREATION_DATE","isys_cmdb_dao_category_g_global::get_dynamic_properties",["isys_cmdb_dao_category_g_global","dynamic_property_callback_created"]],' .
			'[' . C__PROPERTY_TYPE__DYNAMIC . ',"_changed",false,"LC__CMDB__LAST_CHANGE","isys_cmdb_dao_category_g_global::get_dynamic_properties",["isys_cmdb_dao_category_g_global","dynamic_property_callback_changed"]],' .
			'[' . C__PROPERTY_TYPE__STATIC . ',"purpose","isys_purpose__title","LC__CMDB__CATG__GLOBAL_PURPOSE","isys_cmdb_dao_category_g_global::get_properties",false],' .
			'[' . C__PROPERTY_TYPE__DYNAMIC . ',"_cmdb_status",false,"LC__UNIVERSAL__CMDB_STATUS","isys_cmdb_dao_category_g_global::get_dynamic_properties",["isys_cmdb_dao_category_g_global","dynamic_property_callback_cmdb_status"]]]';
	} // function


	/**
	 * Method for retrieving the default list query for all objects.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_default_list_query()
	{
		return "SELECT
			obj_main.*,
			obj_main.isys_obj__id AS '__id__',
			jn1.isys_purpose__title

			FROM isys_obj AS obj_main
			LEFT JOIN isys_cmdb_status AS obj_main_status ON obj_main_status.isys_cmdb_status__id = obj_main.isys_obj__isys_cmdb_status__id
			LEFT JOIN isys_catg_global_list AS j2 ON j2.isys_catg_global_list__isys_obj__id = obj_main.isys_obj__id
			LEFT JOIN isys_purpose AS jn1 ON jn1.isys_purpose__id = j2.isys_catg_global_list__isys_purpose__id

			WHERE (obj_main.isys_obj__isys_obj_type__id = " . $this->convert_sql_id($this->m_object_type['isys_obj_type__id']) . ")";
	} // function


	/**
	 * Method for retrieving the JSON encoded configuration array for the current object type.
	 *
	 * @param   boolean  $p_default
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_list_config($p_default = false)
	{
		$l_user_config = $this->load_user_config();

		if ($l_user_config === null || ! is_array($l_user_config) || $p_default)
		{
			// If the user didn't define his or her own list, we take the default one provided by the DAO.
			return $this->get_default_list_config();
		} // if

		return $l_user_config['isys_obj_type_list__config'];
	} // function


	/**
	 * This method will return the JSON encoded array, ready to be assigned to the TableOrderer component.
	 *
	 * @param   integer  $p_offset  May be an integer or false for no offset.
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_list_data($p_offset = 0)
	{
		// Retrieve the SQL and JSON.
		$l_sql = $this->get_list_query($p_offset);
		$l_list_config = $this->get_list_config();

		$this->m_dao_result = $this->retrieve($l_sql);

		return isys_format_json::encode(
			$this->format_result($this->m_dao_result, isys_format_json::decode($l_list_config, true))
		);
	} // function


	/**
	 * This method is used by an AJAX call to get more rows, once the defined limit (default 30 pages) is reached.
	 *
	 * @param   mixed  $p_offset  May be an integer or false to disable the offset.
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_list_offset($p_offset = 0)
	{
		if ($_GET['load_all'] || $p_offset === false)
		{
			return '';
		} // if

		return 'LIMIT ' . (isys_glob_get_pagelimit() * $this->m_preload_pages * $p_offset) . ', ' . (isys_glob_get_pagelimit() * $this->m_preload_pages);
	} // function


	/**
	 * This method will return a SQL query to select the desired data for the object type lists.
	 *
	 * @param   mixed    $p_offset      May be an integer or false for no offset.
	 * @param   integer  $p_cRecStatus
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_list_query($p_offset = 0, $p_cRecStatus = null)
	{
		$l_obj_status = ((!empty($p_cRecStatus)))  ? $p_cRecStatus : ($this->get_rec_status() ? $this->get_rec_status() : C__RECORD_STATUS__NORMAL);

		if (is_array($l_cmdb_stati = $this->get_cmdb_status()))
		{
			if (is_numeric(array_search(C__CMDB_STATUS__IDOIT_STATUS_TEMPLATE, $l_cmdb_stati)))
			{
				$l_obj_status = C__RECORD_STATUS__TEMPLATE;
			} // if
		} // if

		$l_user_config = $this->load_user_config();

		if ($l_user_config === null || ! is_array($l_user_config))
		{
			// If the user didn't define his or her own list, we take the default one provided by the DAO.
			$l_return = $this->get_default_list_query();
		}
		else
		{
			$l_return = $l_user_config['isys_obj_type_list__query'];
		} // if

		// We need to squish our additional joins before the WHERE statement.
		$l_return = str_replace('WHERE', ' ' . $this->get_additional_joins() . ' WHERE', $l_return);

		// We apply some conditions (for selected status, my-doit and an offset).
		$l_query = $l_return .
			' AND obj_main.isys_obj__status = ' . $this->convert_sql_int($l_obj_status) . ' ' .
			$this->get_allowed_objects_condition() . ' '.
			$this->get_additional_conditions() . ' ' .
			$this->prepare_status_filter() . ' ' .
			' GROUP BY obj_main.isys_obj__id ' .
			$this->get_list_sorting().
			$this->get_list_offset($p_offset) . ';';

		return $l_query;
	} // function


	/**
	 * Method for counting, how many objects this list instance is holding.
	 *
	 * @todo    Check, if the "new methode" works for everything.
	 * @return  integer
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_object_count()
	{
		$l_obj_status = ((!empty($p_cRecStatus)))  ? $p_cRecStatus : ($this->get_rec_status() ? $this->get_rec_status() : C__RECORD_STATUS__NORMAL);

		if (is_array($l_cmdb_stati = $this->get_cmdb_status()))
		{
			if (is_numeric(array_search(C__CMDB_STATUS__IDOIT_STATUS_TEMPLATE, $l_cmdb_stati)))
			{
				$l_obj_status = C__RECORD_STATUS__TEMPLATE;
			} // if
		} // if

		// New method for retrieving the "object count".
		$l_sql = 'SELECT COUNT(*) AS count
			FROM isys_obj AS obj_main
			' . $this->get_additional_joins() . '
			LEFT JOIN isys_obj_type ON isys_obj_type__id = isys_obj__isys_obj_type__id
			WHERE isys_obj_type__id = ' . $this->convert_sql_id($this->m_object_type['isys_obj_type__id']) . '
			AND obj_main.isys_obj__status = ' . $this->convert_sql_int($l_obj_status) . '
			' . $this->get_allowed_objects_condition() . '
			' . $this->get_additional_conditions() . '
			' . $this->prepare_status_filter() . ';';

		return (int) $this
			->retrieve($l_sql)
			->get_row_value('count');

		// We take the prepared SQL statement and strip all the selects.
		$l_sql = 'SELECT COUNT(*) AS count ' . strstr($this->get_list_query(false), 'FROM');

		// Also we need to strip the "GROUP BY".
		return $this->retrieve(substr($l_sql, 0, strpos($l_sql, 'GROUP BY')))->get_row_value('count');
	} // function


	/**
	 * Method for retrieving the number of pages to preload.
	 *
	 * @return  integer
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_preload_pages()
	{
		return $this->m_preload_pages;
	} // function


	/**
	 * Method for finding a user defined list config.
	 *
	 * @return  mixed  Might be an array, if the user has defined an own list. If not: null.
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	protected function load_user_config()
	{
		if ($this->m_list_row === null)
		{
			// SQL for finding out, if a user has created an own list configuration.
			$l_sql = "SELECT * FROM isys_obj_type_list
			LEFT JOIN isys_property_2_cat ON isys_obj_type_list__isys_property_2_cat__id = isys_property_2_cat__id
			WHERE isys_obj_type_list__isys_obj__id = " . $this->convert_sql_id($this->m_user) . "
			AND isys_obj_type_list__isys_obj_type__id = " . $this->convert_sql_id($this->m_object_type['isys_obj_type__id']) . ";";

			$l_res = $this->retrieve($l_sql);

			if ($l_res->num_rows() > 0)
			{
				$this->m_list_row = $l_res->get_row();
			} // if
		} // if

		return $this->m_list_row;
	} // function


	/**
	 * This method sets the object type of this instance.
	 *
	 * @param   mixed  $p_object_type  May be an ID (integer) or the row from isys_obj_type (array).
	 * @return  isys_cmdb_dao_list_objects
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function set_object_type($p_object_type)
	{
		if (is_array($p_object_type))
		{
			$this->m_object_type = $p_object_type;
		}
		else if (is_numeric($p_object_type))
		{
			$l_dao = new isys_cmdb_dao($this->get_database_component());
			$this->m_object_type = $l_dao->get_objtype($p_object_type)->get_row();
		} // if

		return $this;
	} // function

	/**
	 * This method gets the default sorting id.
	 *
	 * @return bool
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function get_default_sorting(){
		$l_user_config = $this->load_user_config();

		if ($l_user_config === null || ! is_array($l_user_config))
		{
			// If the user didn't define his or her own list, we take the default one provided by the DAO.
			return false;
		} // if

		return (empty($l_user_config['isys_obj_type_list__isys_property_2_cat__id']))? false: $l_user_config['isys_obj_type_list__isys_property_2_cat__id'];
	}

	/**
	 * This method gets the property title by the given id
	 *
	 * @return null|string
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function get_default_sorting_title(){
		$l_user_config = $this->load_user_config();

		if ($l_user_config === null || ! is_array($l_user_config))
		{
			// If the user didn't define his or her own list, we take the default one provided by the DAO.
			return null;
		} // if

		return (empty($l_user_config['isys_property_2_cat__prop_title']))? null: $l_user_config['isys_property_2_cat__prop_title'];
	}

	/**
	 * This method gets the sorting direction
	 *
	 * @return null|string
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function get_sorting_direction(){
		$l_user_config = $this->load_user_config();

		if ($l_user_config === null || ! is_array($l_user_config))
		{
			// If the user didn't define his or her own list, we take the default one provided by the DAO.
			return null;
		} // if

		return (empty($l_user_config['isys_obj_type_list__sorting_direction']))? null: $l_user_config['isys_obj_type_list__sorting_direction'];
	}

	/**
	 * Method which sets the order by part of the sql statement for the object list
	 *
	 * @return string
	 * @author Van Quyen Hoang <qhoang@i-doit.org>
	 */
	public function get_list_sorting(){
		if(($l_prop_id = $this->get_default_sorting()) && !empty($this->m_list_row)){
			$l_property = unserialize($this->m_list_row['isys_property_2_cat__prop_data']);

			if($l_property[C__PROPERTY__PROVIDES][C__PROPERTY__PROVIDES__LIST] &&
				($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DATE || $l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__TEXT ||
					(($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DIALOG ||
						(isset($l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]) && $l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]['p_strPopupType'] == 'dialog_plus')) &&
						isset($l_property[C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES][0])
					)))
			{
				if($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DIALOG
					|| ((isset($l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]) && $l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]['p_strPopupType'] == 'dialog_plus')))
				{
					$l_field = $l_property[C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES][0].'__title';
				}
				elseif(($l_property[C__PROPERTY__UI][C__PROPERTY__UI__TYPE] == C__PROPERTY__UI__TYPE__DATE
					&& $l_property[C__PROPERTY__PROVIDES][C__PROPERTY__PROVIDES__LIST]))
				{
					$l_field = $l_property[C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD];
				}
				else
				{
					if(!isset($l_property[C__PROPERTY__UI][C__PROPERTY__UI__PARAMS]['p_strPopupType']) &&
						!isset($l_property[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK]) &&
						!isset($l_property[C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES]))
					{
						$l_field = $l_property[C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD];
					}
				}
			}
			elseif($this->m_list_row['isys_property_2_cat__cat_const'] == 'C__CATG__GLOBAL')
			{
				// Extra for the global category of an object
				if($this->m_list_row['isys_property_2_cat__prop_key'] == '_id'){
					$l_field = 'isys_obj__id';
				} elseif($l_property[C__PROPERTY__PROVIDES][C__PROPERTY__PROVIDES__LIST] && isset($l_property[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK]) && is_object($l_property[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0])){
					$l_prop_obj = $l_property[C__PROPERTY__FORMAT][C__PROPERTY__FORMAT__CALLBACK][0];
					$l_props = $l_prop_obj->get_properties();
					$l_current_prop = null;
					foreach($l_props AS $l_key => $l_value){
						if(strstr($this->m_list_row['isys_property_2_cat__prop_key'], $l_key)){
							$l_current_prop = $l_value;
							continue;
						}
					}
					if(!empty($l_current_prop)){
						if(isset($l_current_prop[C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES])){
							$l_field = $l_current_prop[C__PROPERTY__DATA][C__PROPERTY__DATA__REFERENCES][0].'__title';
						} else{
							$l_field = $l_current_prop[C__PROPERTY__DATA][C__PROPERTY__DATA__FIELD];
						}
					}
				}
			}
			if(isset($l_field))
			{
				if($this->m_list_row['isys_obj_type_list__sorting_direction'] == 'desc')
				{
					$l_return = ' ORDER BY '.$l_field.' DESC ';
				}
				else
				{
					$l_return = ' ORDER BY '.$l_field.' ASC ';
				}
			}
		} else{
			$l_return = ' ORDER BY obj_main.isys_obj__title ASC ';
		}

		return $l_return;
	}

    public function get_rec_array() {
		global $g_comp_template_language_manager;
		$l_ltm = &$g_comp_template_language_manager;

        $l_cRecCounts = $this->get_rec_counts();
		$l_arData = array(
				C__RECORD_STATUS__NORMAL   => $l_ltm->{"LC__CMDB__RECORD_STATUS__NORMAL"}." (".$l_cRecCounts[C__RECORD_STATUS__NORMAL].")",
				C__RECORD_STATUS__ARCHIVED => $l_ltm->{"LC__CMDB__RECORD_STATUS__ARCHIVED"}." (".$l_cRecCounts[C__RECORD_STATUS__ARCHIVED].")",
				C__RECORD_STATUS__DELETED  => $l_ltm->{"LC__CMDB__RECORD_STATUS__DELETED"}." (".$l_cRecCounts[C__RECORD_STATUS__DELETED].")"
			);

		if (defined("C__TEMPLATE__STATUS") && C__TEMPLATE__STATUS == 1)
			$l_arData[C__RECORD_STATUS__TEMPLATE] = "Template (".$l_cRecCounts[C__RECORD_STATUS__TEMPLATE].")";

		return $l_arData;
	}

    /**
     * @desc Overwrite this for special count Handling
     * @return array Counts of several Status
     */
    public function get_rec_counts() {
        $l_array = array(
            C__RECORD_STATUS__NORMAL => $this->retrieve($this->get_list_query(false, C__RECORD_STATUS__NORMAL))->num_rows(),
            C__RECORD_STATUS__ARCHIVED => $this->retrieve($this->get_list_query(false, C__RECORD_STATUS__ARCHIVED))->num_rows(),
            C__RECORD_STATUS__DELETED => $this->retrieve($this->get_list_query(false, C__RECORD_STATUS__DELETED))->num_rows(),
        );

        if (defined("C__TEMPLATE__STATUS") && C__TEMPLATE__STATUS == 1)
            $l_array[C__RECORD_STATUS__TEMPLATE] = $this->retrieve($this->get_list_query(null, C__RECORD_STATUS__TEMPLATE))->num_rows();

        return $l_array;
    }


	/**
	 * Adds condition which objects are allowed for the list
	 *
	 * @return string
	 */
	public function get_allowed_objects_condition()
	{
		$l_allowed_objects = isys_auth::factory(C__MODULE__CMDB)->get_allowed_objects_by_type($this->m_object_type['isys_obj_type__id']);
		if(is_array($l_allowed_objects) && count($l_allowed_objects) > 0)
		{
			return ' AND obj_main.isys_obj__id IN ('.implode(',', $l_allowed_objects).') ';
		} // if
		return '';
	} // function
} // class