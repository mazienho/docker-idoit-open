<?php

/**
 * i-doit
 * DAO: ObjectType list for physical interfaces (subcategory of network).
 *
 * @package     i-doit
 * @subpackage  CMDB_Category_lists
 * @author      Niclas Potthast <npotthast@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_cmdb_dao_list_catg_network_interface extends isys_cmdb_dao_list
{
	/**
	 * Return constant of category.
	 *
	 * @return  integer
	 * @author  Niclas Potthast <npotthast@i-doit.org>
	 */
	public function get_category ()
	{
		return C__CATG__NETWORK;
	} // function


	/**
	 * Return constant of category type.
	 *
	 * @return  integer
	 * @author  Niclas Potthast <npotthast@i-doit.org>
	 */
	public function get_category_type ()
	{
		return C__CMDB__CATEGORY__TYPE_GLOBAL;
	} // function


	/**
	 * Returns array with table headers.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function get_fields ()
	{
		return array(
			'isys_catg_netp_list__title' => 'LC__CMDB__CATG__INTERFACE_L__TITLE',
			'isys_catg_netp_list__slotnumber' => 'LC__CMDB__CATG__INTERFACE_P_SLOTNUMBER',
			'isys_iface_manufacturer__title' => 'LC__CMDB__CATG__INTERFACE_P_MANUFACTURER',
			'isys_iface_model__title' => 'LC__CMDB__CATG__INTERFACE_P_MODEL',
		);
	} // function
} // class