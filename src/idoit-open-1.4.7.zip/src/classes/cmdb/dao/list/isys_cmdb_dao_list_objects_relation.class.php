<?php

/**
 * i-doit
 *
 * List DAO: Relations.
 *
 * @package     i-doit
 * @subpackage  CMDB_Category_lists
 * @author      Leonard Fischer <lfischer@i-doit.org>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       0.9.9-9
 */
class isys_cmdb_dao_list_objects_relation extends isys_cmdb_dao_list_objects
{
	/**
	 * Method for retrieving additional conditions to a object type.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_additional_conditions()
	{
		$l_return = '';

		switch ($_GET["view"])
		{
			case "explicit":
				$l_return .= " AND rel.isys_relation_type__type = '" . C__RELATION__EXPLICIT . "' ";
				break;
			case "implicit":
				$l_return .= " AND rel.isys_relation_type__type = '" . C__RELATION__IMPLICIT . "' ";
				break;
			case "equal":
				break;
		} // switch

		if (isset($_GET["type"]))
		{
			$l_return .= " AND rel.isys_relation_type__id = " . $this->convert_sql_id($_GET["type"]) . " ";
		} // if

		return $l_return;
	} // function


	/**
	 * Method for retrieving additional joins to an object type.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_additional_joins()
	{
		return 'LEFT JOIN isys_catg_relation_list AS cat_rel
			ON cat_rel.isys_catg_relation_list__isys_obj__id = obj_main.isys_obj__id
			LEFT JOIN isys_relation_type AS rel
			ON cat_rel.isys_catg_relation_list__isys_relation_type__id = rel.isys_relation_type__id';
	} // function


	/**
	 * Method for retrieving the default list query if not user defined.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_default_list_query()
	{
		return "SELECT
			obj_main.*,
			obj_main.isys_obj__id AS '__id__',
			jn1.isys_relation_type__title,
			jn3.isys_weighting__title

			FROM isys_obj AS obj_main
			LEFT JOIN isys_cmdb_status AS obj_main_status ON obj_main_status.isys_cmdb_status__id = obj_main.isys_obj__isys_cmdb_status__id
			INNER JOIN isys_catg_relation_list AS j4 ON j4.isys_catg_relation_list__isys_obj__id = obj_main.isys_obj__id
			LEFT JOIN isys_relation_type AS jn1 ON jn1.isys_relation_type__id = j4.isys_catg_relation_list__isys_relation_type__id
			LEFT JOIN isys_weighting AS jn3 ON jn3.isys_weighting__id = j4.isys_catg_relation_list__isys_weighting__id

			WHERE (obj_main.isys_obj__isys_obj_type__id = " . $this->convert_sql_id(C__OBJTYPE__RELATION) . ") ";
	} // function


	/**
	 * Method for retrieving the default JSON encoded array of the property-selector.
	 *
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.org>
	 */
	public function get_default_list_config()
	{
		return '[[' . C__PROPERTY_TYPE__DYNAMIC . ',"_relation",false,"LC__UNIVERSAL__RELATION","isys_cmdb_dao_category_g_relation::get_dynamic_properties",["isys_cmdb_dao_category_g_relation","dynamic_property_callback_relation"]],' .
			'[' . C__PROPERTY_TYPE__STATIC . ',"relation_type","isys_relation_type__title","LC__CATG__RELATION__RELATION_TYPE","isys_cmdb_dao_category_g_relation::get_properties_ng",false],' .
			'[' . C__PROPERTY_TYPE__DYNAMIC . ',"_type",false,"LC__CMDB__CATG__TYPE","isys_cmdb_dao_category_g_relation::get_dynamic_properties",["isys_cmdb_dao_category_g_relation","dynamic_property_callback_type"]],' .
			'[' . C__PROPERTY_TYPE__STATIC . ',"weighting","isys_weighting__title","LC__CATG__RELATION__WEIGHTING","isys_cmdb_dao_category_g_relation::get_properties_ng",false],' .
			'[' . C__PROPERTY_TYPE__DYNAMIC . ',"_itservice",false,"LC__CMDB__CATG__IT_SERVICE","isys_cmdb_dao_category_g_relation::get_dynamic_properties",["isys_cmdb_dao_category_g_relation","dynamic_property_callback_itservice"]]]';
	} // function
} // class