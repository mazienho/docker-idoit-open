<?php
/**
 * i-doit
 *
 * UI: global category for aircrafts.
 *
 * @package     i-doit
 * @subpackage  CMDB_Categories
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @version     1.0.0
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 * @since       i-doit 1.4.0
 */
class isys_cmdb_ui_category_g_aircraft extends isys_cmdb_ui_category_global
{
	// Nothing to do here.
} // class