<?php

/**
 * i-doit
 *
 * Auth: Class for Report module authorization rules.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @author      Selcuk Kekec <skekec@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_auth_module_search extends isys_auth
{
	/**
	 * Method for returning the available auth-methods. This will be used for the GUI.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function get_auth_methods ()
	{
		return array(
            'search' => array(
				'title' => _L('LC__MODULE__SEARCH__TITEL'),
				'type' => 'boolean',
				'rights' => array(isys_auth::VIEW),
				'defaults' => array(isys_auth::VIEW)
			),
		);
	} // function

    /**
	 * This method checks, if you are allowed to use the report editor.
	 *
	 * @throws  isys_exception_general
	 * @throws  isys_exception_auth
	 * @return  boolean
	 * @author  Selcuk Kekec <skekec@i-doit.com>
	 */
	public function search ()
	{
        return $this->generic_boolean('search', new isys_exception_auth(_L('LC__AUTH__REPORT_EXCEPTION__MISSING_RIGHT_FOR_SEARCH')));
	} // function
} // class
?>