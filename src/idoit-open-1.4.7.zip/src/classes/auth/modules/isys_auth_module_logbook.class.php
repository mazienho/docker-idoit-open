<?php

/**
 * i-doit
 *
 * Auth: Class for Notifications module authorization rules.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Van Quyen Hoang <qhoang@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_auth_module_logbook extends isys_auth
{
	/**
	 * Method for returning the available auth-methods. This will be used for the GUI.
	 *
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function get_auth_methods ()
	{
		return array(
			'logbook' => array(
				'title' => _L('LC__AUTH_GUI__LOGBOOK_CONDITION'),
				'type' => 'logbook'
			)
		);
	} // function


	/**
	 * Determines the rights for the logbook module.
	 *
	 * @param   integer  $p_right
	 * @param   mixed    $p_type
	 * @return  boolean
	 * @throws  isys_exception_auth
	 * @author  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function logbook ($p_right, $p_type)
	{
		switch($p_type){
			case C__MODULE__LOGBOOK . C__PAGE__LOGBOOK_VIEW:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__CMDB__LOGBOOK__LIST_CONTENT_TITLE')));
				break;
			case C__MODULE__LOGBOOK . C__PAGE__LOGBOOK_CONFIGURATION:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__MODULE__CMDB__LOGBOOK_CONFIGURATION')));
				break;
			case C__MODULE__LOGBOOK . C__PAGE__LOGBOOK_ARCHIVE:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__NAVIGATION__NAVBAR__ARCHIVE')));
				break;
			case C__MODULE__LOGBOOK . C__PAGE__LOGBOOK_RESTORE:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__UNIVERSAL__RESTORE')));
				break;
			default:
				$l_exception = _L('LC__AUTH__SYSTEM_EXCEPTION__MISSING_RIGHT_FOR_LOGBOOK');
				break;
		}
		return $this->check_module_rights($p_right, 'logbook', $p_type, new isys_exception_auth($l_exception));
	} // function
} // class
?>