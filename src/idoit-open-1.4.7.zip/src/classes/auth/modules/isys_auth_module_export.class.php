<?php

/**
 * i-doit
 *
 * Auth: Class for Notifications module authorization rules.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Van Quyen Hoang <qhoang@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_auth_module_export extends isys_auth
{
	/**
	 * Method for returning the available auth-methods. This will be used for the GUI.
	 *
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function get_auth_methods ()
	{
		return array(
			'export' => array(
				'title' => _L('LC__AUTH_GUI__EXPORT_CONDITION'),
				'type' => 'export'
			)
		);
	} // function


	/**
	 * Determines the rights for the export module.
	 *
	 * @param   integer  $p_right
	 * @param   mixed    $p_type
	 * @return  boolean
	 * @throws  isys_exception_auth
	 * @author  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function export ($p_right, $p_type)
	{
		switch($p_type){
			case C__MODULE__EXPORT.'1':
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__MODULE__EXPORT__EXPORT_WIZARD')));
				break;
			default:
				$l_exception = _L('LC__AUTH__SYSTEM_EXCEPTION__MISSING_RIGHT_FOR_EXPORT');
				break;
		}

		return $this->check_module_rights($p_right, 'export', $p_type, new isys_exception_auth($l_exception));
	} // function
} // class
?>