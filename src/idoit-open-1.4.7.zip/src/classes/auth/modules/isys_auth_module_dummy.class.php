<?php

/**
 * i-doit
 *
 * Auth: Dummy class for module authorization.
 * This class will be used for all modules, which do not own a specific auth-class.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_auth_module_dummy extends isys_auth
{
	/**
	 * Dummy "check()" method, for modules without an own auth-class.
	 *
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function check ()
	{
		return true;
	} // function


	/**
	 * Method for returning the available auth-methods. This will be used for the GUI.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function get_auth_methods ()
	{
		return array();
	} // function


	/**
	 * Checks if there exists any path for the current module.
	 *
	 * @return  boolean
	 * @authro  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function has_any_rights_in_module()
	{
		return true;
	}


	/**
	 * This method will process the exact same code as "check()" but will return a boolean value without any exceptions.
	 *
	 * @param   integer  $p_right
	 * @param   string   $p_path
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function is_allowed_to ($p_right, $p_path)
	{
		return true;
	} // function


    /**
	 * Constructor, will load all necessary paths.
	 *
	 * @param   array  $p_module_row
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function __construct ($p_module_row=NULL)
	{
		$this->m_module_row = $p_module_row;
	} // function


    /**
     * Universal check method: Used for basic rights mode. This way we do not have to implement each existing method of the other isys_auth_modules.
     *
     * @param   string  $p_method
     * @param   mixed   $p_arguments
     * @return  boolean
     * @author  Selcuk Kekec <skekec@i-doit.com>
     */
	public function __call ($p_method, $p_arguments)
	{
		return true;
	} // function
} // class