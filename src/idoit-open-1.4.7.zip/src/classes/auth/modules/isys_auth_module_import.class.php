<?php

/**
 * i-doit
 *
 * Auth: Class for Notifications module authorization rules.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Van Quyen Hoang <qhoang@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_auth_module_import extends isys_auth
{
	/**
	 * Method for returning the available auth-methods. This will be used for the GUI.
	 *
	 * @return  array
	 * @author  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function get_auth_methods ()
	{
		return array(
			'import' => array(
				'title' => _L('LC__AUTH_GUI__IMPORT_CONDITION'),
				'type' => 'import'
			)
		);
	} // function


	/**
	 * Determines the rights for the import module.
	 *
	 * @param   integer  $p_right
	 * @param   mixed    $p_type
	 * @return  boolean
	 * @throws  isys_exception_auth
	 * @author  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function import ($p_right, $p_type)
	{
		switch($p_type){
			case C__MODULE__IMPORT . C__IMPORT__GET__LDAP:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__MODULE__IMPORT__LDAP')));
				break;
			case C__MODULE__IMPORT . C__IMPORT__GET__IMPORT:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__UNIVERSAL__FILE_IMPORT')));
				break;
			case C__MODULE__IMPORT . C__IMPORT__GET__CABLING:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__MODULE__IMPORT__CABLING')));
				break;
			case C__MODULE__IMPORT . C__IMPORT__GET__OCS_OBJECTS:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__MODULE__IMPORT__OCS')));
				break;
			case C__MODULE__IMPORT . C__IMPORT__GET__JDISC:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__MODULE__JDISC')));
				break;
			case C__MODULE__IMPORT . C__IMPORT__GET__SHAREPOINT:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array(_L('LC__MODULE__IMPORT__SHAREPOINT')));
				break;
			case C__MODULE__IMPORT . C__IMPORT__GET__LOGINVENTORY:
				$l_exception = _L('LC__AUTH__EXCEPTION__MISSING_ACTION_RIGHT', array('LOGINventory'));
				break;
			default:
				$l_exception = _L('LC__AUTH__SYSTEM_EXCEPTION__MISSING_RIGHT_FOR_IMPORT');
				break;
		}
		return $this->check_module_rights($p_right, 'import', $p_type, new isys_exception_auth($l_exception));
	} // function
} // class
?>