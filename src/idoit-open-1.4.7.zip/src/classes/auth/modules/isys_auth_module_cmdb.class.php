<?php

/**
 * i-doit
 *
 * Auth: Class for CMDB module authorization rules.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class isys_auth_module_cmdb extends
    isys_auth
{
    /**
     * This is a helper-array for the "categories in objects" path.
     *
     * @var  array
     */
    private $m_categories_in_objects = array();

    /**
     * This is a helper-array for the "categories in locations" path.
     *
     * @var  array
     */
    private $m_categories_in_locations = array();


    /**
     * Constructor, will load all necessary paths.
     *
     * @param   array $p_module_row
     *
     * @author  Leonard Fischer <lficsher@i-doit.com>
     */
    protected function __construct(array $p_module_row)
    {
        parent::__construct($p_module_row);

        // After the constructor is called, we can prepare some of the loaded paths.
        if (isset($this->m_paths['category_in_object']))
        {
            foreach ($this->m_paths['category_in_object'] as $l_param => $l_rights)
            {
                list($l_category, $l_ids) = explode('+', strtolower($l_param));

                if (is_numeric($l_ids))
                {
                    $l_ids = array($l_ids);
                }
                else
                {
                    if (isys_format_json::is_json_array($l_ids))
                    {
                        $l_ids = isys_format_json::decode($l_ids);
                    }
                    else
                    {
                        // How about nope?
                        continue;
                    } // if
                } // if

                if (!isset($this->m_categories_in_objects[$l_category]))
                {
                    $this->m_categories_in_objects[$l_category] = array();
                } // if

                if (count($l_ids) > 0)
                {
                    foreach ($l_ids as $l_id)
                    {
                        $this->m_categories_in_objects[$l_category][$l_id] = array_merge((array)$this->m_categories_in_objects[$l_category][$l_id],
                                                                                         $l_rights);
                    } // foreach
                } // if
            } // foreach
        } // if

        if (isset($this->m_paths['category_in_location']))
        {
            foreach ($this->m_paths['category_in_location'] as $l_param => $l_rights)
            {
                list($l_category, $l_ids) = explode('+', strtolower($l_param));

                if (is_numeric($l_ids))
                {
                    $l_ids = array($l_ids);
                }
                else
                {
                    if (isys_format_json::is_json_array($l_ids))
                    {
                        $l_ids = isys_format_json::decode($l_ids);
                    }
                    else
                    {
                        // How about nope?
                        continue;
                    } // if
                } // if

                if (!isset($this->m_categories_in_locations[$l_category]))
                {
                    $this->m_categories_in_locations[$l_category] = array();
                } // if

                if (count($l_ids) > 0)
                {
                    foreach ($l_ids as $l_id)
                    {
                        $this->m_categories_in_locations[$l_category][$l_id] = array_merge((array)$this->m_categories_in_locations[$l_category][$l_id],
                                                                                           $l_rights);
                    } // foreach
                } // if
            } // foreach
        } // if
    } // function


    /**
     * Method for returning the available auth-methods. This will be used for the GUI.
     *
     * @return  array
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function get_auth_methods()
    {
        return array(
            'obj_id'               => array(
                'title' => _L('LC__AUTH_GUI__OBJ_ID_CONDITION'),
                'type'  => 'object'
            ),
            'obj_in_type'          => array(
                'title' => _L('LC__AUTH_GUI__OBJ_IN_TYPE_CONDITION'),
                'type'  => 'object_type'
            ),
            'obj_type'             => array(
                'title' => _L('LC__AUTH_GUI__OBJ_TYPE_CONDITION'),
                'type'  => 'object_type'
            ),
            'location'             => array(
                'title' => _L('LC__AUTH_GUI__LOCATION_CONDITION'),
                'type'  => 'location'
            ),
            'category'             => array(
                'title' => _L('LC__AUTH_GUI__CATEGORY_CONDITION'),
                'type'  => 'category'
            ),
            'category_in_obj_type' => array(
                'title' => _L('LC__AUTH_GUI__CATEGORY_IN_OBJ_TYPE_CONDITION'),
                'type'  => 'category_in_obj_type'
            ),
            'category_in_object'   => array(
                'title' => _L('LC__AUTH_GUI__CATEGORY_IN_OBJECT_CONDITION'),
                'type'  => 'category_in_object'
            ),
            'category_in_location' => array(
                'title' => _L('LC__AUTH_GUI__CATEGORY_IN_LOCATION_CONDITION'),
                'type'  => 'category_in_location'
            ),
            'multiedit'            => array(
                'title'  => _L('LC__AUTH_GUI__MULTIEDIT_CONDITION'),
                'type'   => 'boolean',
                'rights' => array(isys_auth::VIEW, isys_auth::EXECUTE)
            )
        );
    } // function


    /**
     * Method for checking, if a certain OBJ-ID inherits the given rights. If these could not be found, it will be
     * checked for the OBJ-IN-TYPE.
     *
     * @param   integer $p_right
     * @param   integer $p_id
     *
     * @return  boolean
     * @throws  isys_exception_auth
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function obj_id($p_right, $p_id)
    {
        if (isset($this->m_paths['obj_id']))
        {
            // Check for wildchars.
            if (isset($this->m_paths['obj_id'][isys_auth::WILDCHAR]) && in_array($p_right,
                                                                                 $this->m_paths['obj_id'][isys_auth::WILDCHAR])
            )
            {
                return true;
            } // if

            // Check for actual rights on the given OBJ-ID.
            if (isset($this->m_paths['obj_id'][$p_id]) && in_array($p_right, $this->m_paths['obj_id'][$p_id]))
            {
                return true;
            } // if
        } // if

        // Retrieve object.
        $l_obj = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', self::$m_dao->get_database_component())
                                      ->get_object($p_id, false, 1)
                                      ->get_row();

        // If we could find no rights for this object, we look if the object-type is allowed in general.
        try
        {
            return $this->obj_in_type($p_right, strtolower($l_obj['isys_obj_type__const']));
        }
        catch (isys_exception_auth $e)
        {
            ; // Do nothing here. The method will throw his own exception.
        } // try

        // If we could find no rights for this object, we look if the location is allowed in general.
        try
        {
            return $this->location($p_right, $p_id);
        }
        catch (isys_exception_auth $e)
        {
            ; // Do nothing here. The method will throw his own exception.
        } // try

        // Get some data for the upcoming checks and exceptions.
        $l_right_name = isys_auth::get_right_name($p_right);

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_OBJ_ID',
                                         array($l_right_name, $l_obj['isys_obj__title'])));
    } // function


    /**
     * This method checks, if you are allowed to process an action for objects of a given type.
     *
     * @param   integer $p_right
     * @param   string  $p_id
     *
     * @throws  isys_exception_general
     * @throws  isys_exception_auth
     * @return  boolean
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function obj_in_type($p_right, $p_id)
    {
        $l_constant = strtoupper(trim($p_id));

        if (!defined($l_constant))
        {
            throw new isys_exception_general(_L('LC__EXCEPTION__CONSTANT_COULD_NOT_BE_FOUND', $l_constant));
        } // if


        if (isset($this->m_paths['obj_in_type']))
        {
            // Check for wildchars.
            if (isset($this->m_paths['obj_in_type'][isys_auth::WILDCHAR]) && in_array($p_right,
                                                                                      $this->m_paths['obj_in_type'][isys_auth::WILDCHAR])
            )
            {
                return true;
            } // if

            // Check for actual rights on the given OBJ-TYPE.
            if (isset($this->m_paths['obj_in_type'][$p_id]) && in_array($p_right, $this->m_paths['obj_in_type'][$p_id]))
            {
                return true;
            } // if
        } // if

        // Get some translations for the exception.
        $l_type_id       = constant($l_constant);
        $l_right_name    = isys_auth::get_right_name($p_right);
        $l_obj_type_name = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', self::$m_dao->get_database_component())
                                                ->get_objtype_name_by_id_as_string($l_type_id);

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_OBJ_IN_TYPE',
                                         array($l_right_name, _L($l_obj_type_name))));
    } // function


    /**
     * This method checks, if you are allowed to process an action for a certain OBJ-TYPE (used for object-type
     * configuration).
     *
     * @param   integer $p_right
     * @param   string  $p_id
     *
     * @throws  isys_exception_general
     * @throws  isys_exception_auth
     * @return  boolean
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function obj_type($p_right, $p_id)
    {
        $l_constant = strtoupper(trim($p_id));

        if (isset($this->m_paths['obj_type']))
        {
            // This checks for paths like "CMDB/OBJ_TYPE" without IDs (will be used to check, if the "new" button shall be displayed in the list-view).
            if (empty($l_constant) && isset($this->m_paths['obj_type'][isys_auth::EMPTY_ID_PARAM]) && in_array($p_right,
                                                                                                               $this->m_paths['obj_type'][isys_auth::EMPTY_ID_PARAM])
            )
            {
                return true;
            } // if

            if (!defined($l_constant))
            {
                throw new isys_exception_general(_L('LC__EXCEPTION__CONSTANT_COULD_NOT_BE_FOUND', $l_constant));
            } // if

            // Check for wildchars.
            if (isset($this->m_paths['obj_type'][isys_auth::WILDCHAR]) && in_array($p_right,
                                                                                   $this->m_paths['obj_type'][isys_auth::WILDCHAR])
            )
            {
                return true;
            } // if

            // Check for actual rights on the given OBJ-TYPE.
            if (isset($this->m_paths['obj_type'][$p_id]) && in_array($p_right, $this->m_paths['obj_type'][$p_id]))
            {
                return true;
            } // if
        } // if

        // Get some translations for the exception.
        $l_right_name = isys_auth::get_right_name($p_right);

        if (empty($l_constant))
        {
            $l_obj_type_name = C__GUI_VALUE__NA;
        }
        else
        {
            $l_obj_type_name = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                   self::$m_dao->get_database_component())
                                                    ->get_objtype_name_by_id_as_string(constant($l_constant));
        } // if

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_OBJ_TYPE',
                                         array($l_right_name, _L($l_obj_type_name))));
    } // function


    /**
     * This method checks, if the user has right to see a certain category in a certain object type.
     *
     * @param   integer $p_right
     * @param   string  $p_id
     *
     * @return  boolean
     * @throws  isys_exception_auth
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function category_in_obj_type($p_right, $p_id)
    {
        $p_id = strtolower(trim($p_id));
        list (, $l_obj_type) = explode('+', $p_id);

        if (isset($this->m_paths['category_in_obj_type']))
        {
            if (isset($this->m_paths['category_in_obj_type'][isys_auth::WILDCHAR . '+' . $l_obj_type]) &&
                in_array($p_right, $this->m_paths['category_in_obj_type'][isys_auth::WILDCHAR . '+' . $l_obj_type])
            )
            {
                return true;
            } // if

            if (isset($this->m_paths['category_in_obj_type'][$p_id]) && in_array($p_right,
                                                                                 $this->m_paths['category_in_obj_type'][$p_id])
            )
            {
                return true;
            } // if
        } // if

        // Get some data for the upcoming checks and exceptions.
        $l_right_name = isys_auth::get_right_name($p_right);

        // We don't know, whether the category is global|specific|custom.
        list($l_category_title) = array_values(isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                                   self::$m_dao->get_database_component())
                                                                    ->get_cat_by_const(strstr($p_id, '+', true),
                                                                                       array('title')));

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_CATEGORY',
                                         array($l_right_name, _L($l_category_title))));
    } // function


    /**
     * This method checks, if the user has right to see a certain category in a certain object.
     *
     * @param   integer $p_right
     * @param   string  $p_id
     *
     * @return  boolean
     * @throws  isys_exception_auth
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function category_in_object($p_right, $p_id)
    {
        list($l_category, $l_id) = explode('+', strtolower($p_id));

        if (isset($this->m_categories_in_objects[$l_category]))
        {
            if (isset($this->m_categories_in_objects[isys_auth::WILDCHAR][$l_id]) && in_array($p_right,
                                                                                              $this->m_categories_in_objects[isys_auth::WILDCHAR][$l_id])
            )
            {
                return true;
            } // if

            if (isset($this->m_categories_in_objects[$l_category][$l_id]) && in_array($p_right,
                                                                                      $this->m_categories_in_objects[$l_category][$l_id])
            )
            {
                return true;
            } // if
        } // if

        // Get some data for the upcoming checks and exceptions.
        $l_right_name = isys_auth::get_right_name($p_right);

        // We don't know, whether the category is global|specific|custom.
        list($l_category_title) = array_values(isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                                   self::$m_dao->get_database_component())
                                                                    ->get_cat_by_const($l_category,
                                                                                       array('title')) ?: array());

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_CATEGORY',
                                         array($l_right_name, _L($l_category_title))));
    } // function


    /**
     * This method checks, if the user has right to see a certain category underneath certain location.
     *
     * @param   integer $p_right
     * @param   string  $p_id
     *
     * @return  boolean
     * @throws  isys_exception_auth
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function category_in_location($p_right, $p_id)
    {
        list($l_category, $l_id) = explode('+', strtolower($p_id));

        if (isset($this->m_categories_in_locations[isys_auth::WILDCHAR]) || isset($this->m_categories_in_locations[$l_category]))
        {
            if (isset($this->m_categories_in_locations[isys_auth::WILDCHAR][$l_id]) && in_array($p_right,
                                                                                                $this->m_categories_in_locations[isys_auth::WILDCHAR][$l_id])
            )
            {
                return true;
            } // if

            if (isset($this->m_categories_in_locations[$l_category][$l_id]) && in_array($p_right,
                                                                                        $this->m_categories_in_locations[$l_category][$l_id])
            )
            {
                return true;
            } // if

            // The given ID could not be found directly, now we check the location path.
            $l_dao_location = isys_factory::get_instance('isys_cmdb_dao_location',
                                                         self::$m_dao->get_database_component());

            if (is_array($this->m_categories_in_locations[isys_auth::WILDCHAR]))
            {
                foreach ($this->m_categories_in_locations[isys_auth::WILDCHAR] as $l_location_id => $l_rights)
                {
                    // Get child locations of the location auth-paths.
                    $l_child_locations = $l_dao_location->get_child_locations_recursive($l_location_id);

                    // Are you allowed to view/read/write?
                    if (isset($l_child_locations[$l_id]) && in_array($p_right, $l_rights))
                    {
                        return true;
                    } // if
                } // foreach
            } // if

            if (is_array($this->m_categories_in_locations[$l_category]))
            {
                foreach ($this->m_categories_in_locations[$l_category] as $l_location_id => $l_rights)
                {
                    // Get child locations of the location auth-paths.
                    $l_child_locations = $l_dao_location->get_child_locations_recursive($l_location_id);

                    // Are you allowed to view/read/write?
                    if (isset($l_child_locations[$l_id]) && in_array($p_right, $l_rights))
                    {
                        return true;
                    } // if
                } // foreach
            } // if
        } // if

        // Get some data for the upcoming checks and exceptions.
        $l_right_name = isys_auth::get_right_name($p_right);

        // We don't know, whether the category is global|specific|custom.
        list($l_category_title) = array_values(isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                                   self::$m_dao->get_database_component())
                                                                    ->get_cat_by_const($l_category, array('title')));

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_CATEGORY',
                                         array($l_right_name, _L($l_category_title))));
    } // function


    /**
     * Returns an array of allowed categories (as constants) for the given object type - Can also return the
     * "isys_auth::WILDCHAR" or "isys_auth::EMPTY_ID_PARAM".
     *
     * @param   string $p_type
     *
     * @return  array
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function get_allowed_categories_by_obj_type($p_type)
    {
        $l_return = array();

        if (isset($this->m_paths['category_in_obj_type']) && is_array($this->m_paths['category_in_obj_type']))
        {
            foreach ($this->m_paths['category_in_obj_type'] as $l_param => $l_right)
            {
                list($l_category, $l_obj_type) = explode('+', strtoupper($l_param));

                if ($l_obj_type == $p_type)
                {
                    $l_return[] = $l_category;
                } // if
            } // foreach
        } // if

        // Let us merge object type specific category rights with global ones
        $l_global_category_rights = array_keys($this->m_paths['category']);

        if (is_array($l_global_category_rights))
        {
            $l_return = array_merge($l_return, $l_global_category_rights);
        } // if

        return $l_return;
    } // function


    /**
     * This method checks, if you are allowed to precess an action for a certain location node.
     *
     * @param   integer $p_right
     * @param   integer $p_id
     *
     * @throws  isys_exception_auth
     * @return  boolean
     * @author  Selcuk Kekec <skekec@i-doit.com>
     */
    public function location($p_right, $p_id)
    {
        global $g_comp_database;

        if (isset($this->m_paths['location']))
        {
            if (isset($this->m_paths['location'][isys_auth::WILDCHAR]) && in_array($p_right,
                                                                                   $this->m_paths['location'][isys_auth::WILDCHAR])
            )
            {
                return true;
            }
            else
            {
                if (isset($this->m_paths['location'][$p_id]) && in_array($p_right, $this->m_paths['location'][$p_id]))
                {
                    return true;
                }
                else
                {
                    // The given ID could not be found directly, now we check the location path.

                    /** @var isys_cmdb_dao_location $l_dao_location */
                    $l_dao_location = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao_location', $g_comp_database);

                    foreach ($this->m_paths['location'] as $l_location_id => $l_rights)
                    {
                        // Get child locations of the location auth-paths.
                        $l_child_locations = $l_dao_location->get_child_locations_recursive($l_location_id);

                        // Are you allowed to view/read/write?
                        if (isset($l_child_locations[$p_id]) && in_array($p_right,
                                                                         $this->m_paths['location'][$l_location_id])
                        )
                        {
                            return true;
                        } // if
                    } // foreach
                } // if
            } // if
        } // if

        // Get some data for the upcoming checks and exceptions.
        $l_right_name = isys_auth::get_right_name($p_right);
        $l_obj        = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', self::$m_dao->get_database_component())
                                             ->get_object($p_id, false, 1)
                                             ->get_row();

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_LOCATION',
                                         array($l_right_name, $l_obj['isys_obj__title'])));
    } // function


    /**
     * This method checks, if you are allowed to process an action for a category.
     *
     * @param   integer $p_right
     * @param   string  $p_id
     *
     * @throws  isys_exception_general
     * @throws  isys_exception_auth
     * @return  boolean
     * @author  Leonard Fischer <lfischer@i-doit.com>
     * @author  Selcuk Kekec <skekec@i-doit.com>
     */
    public function category($p_right, $p_id)
    {
        $l_constant = strtoupper(trim($p_id));

        if (!defined($l_constant))
        {
            throw new isys_exception_general(_L('LC__EXCEPTION__CONSTANT_COULD_NOT_BE_FOUND', $l_constant));
        } // if

        if (isset($this->m_paths['category']))
        {
            // Check for wildchars.
            if (isset($this->m_paths['category'][isys_auth::WILDCHAR]) && in_array($p_right,
                                                                                   $this->m_paths['category'][isys_auth::WILDCHAR])
            )
            {
                return true;
            } // if

            // Check for actual rights on the given OBJ-TYPE.
            if (isset($this->m_paths['category'][$p_id]) && in_array($p_right, $this->m_paths['category'][$p_id]))
            {
                return true;
            } // if
        } // if

        // Get some data for the upcoming checks and exceptions.
        $l_right_name = isys_auth::get_right_name($p_right);

        // We don't know, whether the category is global|specific|custom.
        list($l_category_title) = array_values(isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                                   self::$m_dao->get_database_component())
                                                                    ->get_cat_by_const($l_constant, array('title')));

        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_CATEGORY',
                                         array($l_right_name, _L($l_category_title))));
    } // function


    /**
     * Determines the rights for multiedit in extras menu.
     *
     * @param   integer $p_right
     *
     * @return  boolean
     * @author  Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function multiedit($p_right)
    {
        return $this->generic_boolean('multiedit',
                                      new isys_exception_auth(_L('LC__AUTH__SYSTEM_EXCEPTION__MISSING_RIGHT_FOR_MULTIEDIT')),
                                      $p_right);
    } // function


    /**
     * Checks permission to see the object type
     *
     * @param $p_objecttype
     *
     * @throws isys_exception_auth
     */
    public function check_in_allowed_objecttypes($p_objecttype)
    {
        if (!$this->is_allowed_in_objecttype($p_objecttype))
        {
            throw new isys_exception_auth(_L(
                                              'LC__AUTH__EXCEPTION__MISSING_RIGHTS_TO_VIEW_OBJECT_LIST',
                                              _L(isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                                     self::$m_dao->get_database_component())
                                                                      ->get_objtype_name_by_id_as_string($p_objecttype))
                                          ));
        } // if
    } // function


    /**
     * This method checks the rights for categories and checks the rights from the object.
     *
     * @param   integer $p_right
     * @param   integer $p_object_id
     * @param   string  $p_category_const
     *
     * @throws  isys_exception_auth
     * @return  boolean
     * @author  Van Quyen Hoang <qhoang@i-doit.com>
     * @author  Leonard Fischer <lfischer@i-doit.com>
     */
    public function check_rights_obj_and_category($p_right, $p_object_id,
                                                  $p_category_const)  // If errors occur, change back to "$p_category_const = null".
    {
        if ($p_category_const !== NULL && isset($this->m_paths['category']))
        {
            if ($this->is_allowed_to(isys_auth::VIEW, 'OBJ_ID/' . $p_object_id))
            {
                if (strtoupper($p_category_const) == 'C__CATG__GLOBAL' || strtoupper($p_category_const) == 'C__CATG__OVERVIEW')
                {
                    if ($this->is_allowed_to($p_right, 'OBJ_ID/' . $p_object_id) && $this->is_allowed_to($p_right,
                                                                                                         'CATEGORY/' . strtoupper($p_category_const))
                    )
                    {
                        return true;
                    } // if
                }
                else
                {
                    if ($this->is_allowed_to($p_right, 'CATEGORY/' . strtoupper($p_category_const)))
                    {
                        return true;
                    } // if
                } // if
            } // if
        } // if

        if ($p_category_const !== NULL)
        {
            if ($this->is_allowed_to($p_right,
                                     'OBJ_ID/' . $p_object_id) && (strtoupper($p_category_const) == 'C__CATG__GLOBAL' || strtoupper($p_category_const) == 'C__CATG__OVERVIEW')
            )
            {
                return true;
            } // if

            // We still got a few last chances to permit the user...
            if ($this->m_paths['category_in_obj_type'])
            {
                $l_obj_type = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                  self::$m_dao->get_database_component())
                                                   ->get_type_by_object_id($p_object_id)
                                                   ->get_row();

                try
                {
                    return $this->category_in_obj_type($p_right,
                                                       $p_category_const . '+' . $l_obj_type['isys_obj_type__const']);
                }
                catch (isys_exception_auth $e)
                {
                    $e->write_log(); // We don't want to throw an error here.
                } // try
            } // if

            if (count($this->m_categories_in_objects) > 0)
            {
                try
                {
                    return $this->category_in_object($p_right, $p_category_const . '+' . $p_object_id);
                }
                catch (isys_exception_auth $e)
                {
                    $e->write_log(); // We don't want to throw an error here.
                } // try
            } // if

            if (count($this->m_categories_in_locations) > 0)
            {
                // No need to catch the exception, because this is the last check (for now).
                return $this->category_in_location($p_right, $p_category_const . '+' . $p_object_id);
            } // if

            $l_category       = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao',
                                                                    self::$m_dao->get_database_component())
                                                     ->get_cat_by_const($p_category_const, array('title'));
            $l_category_title = $p_category_const;

            if ($l_category)
            {
                list($l_category_title) = array_values($l_category);
            } // if

            throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_CATEGORY',
                                             array($this->get_right_name($p_right), _L($l_category_title))));
        }
        else
        {
            // check rights in object
            if ($this->is_allowed_to($p_right, 'OBJ_ID/' . $p_object_id))
            {
                return true;
            } // if
        } // if

        $l_obj_title = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', self::$m_dao->get_database_component())
                                            ->get_obj_name_by_id_as_string($p_object_id);
        throw new isys_exception_auth(_L('LC__AUTH__CMDB_EXCEPTION__MISSING_RIGHT_FOR_OBJ_ID',
                                         array($this->get_right_name($p_right), $l_obj_title)));
    } // function


    /**
     * Gets all allowed object types
     *
     * @return array|bool
     * @author Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function get_allowed_objecttypes()
    {
        global $g_comp_database, $g_comp_session;

        $l_return   = array();
        $l_wildcard = false;

        $l_cache_obj = isys_caching::factory('auth-' . $g_comp_session->get_user_id());

        $l_cache = $l_cache_obj->get('allowed_objecttypes');

        if ($l_cache === false || (is_array($l_cache) && count($l_cache) == 0))
        {
            // Get object types from object in type rights.
            if (isset($this->m_paths['obj_in_type']))
            {
                if (isset($this->m_paths['obj_in_type'][isys_auth::WILDCHAR]))
                {
                    $l_wildcard = true;
                    $l_return   = true;
                }
                else
                {
                    if (!isset($this->m_paths['obj_in_type'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        foreach ($this->m_paths['obj_in_type'] AS $l_key => $l_rights)
                        {
                            $l_key = strtoupper($l_key);
                            if (defined($l_key))
                            {
                                $l_key_constant            = constant($l_key);
                                $l_return[$l_key_constant] = $l_key_constant;
                            } // if
                        } // foreach
                    } // if
                } // if
            } // if

            /** @var isys_cmdb_dao $l_dao */
            $l_dao = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', $g_comp_database);

            // Get object types from object id rights.
            if (!$l_wildcard && isset($this->m_paths['obj_id']))
            {
                if (isset($this->m_paths['obj_id'][isys_auth::WILDCHAR]))
                {
                    $l_wildcard = true;
                    $l_return   = true;
                }
                else
                {
                    if (!isset($this->m_paths['obj_id'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        foreach ($this->m_paths['obj_id'] AS $l_key => $l_rights)
                        {
                            $l_objtype_id = $l_dao->get_objTypeID($l_key);
                            if (!isset($l_return[$l_objtype_id]))
                            {
                                $l_return[$l_objtype_id] = $l_objtype_id;
                            } // if
                        } // foreach
                    } // if
                } // if
            } // if

            // Get object types from location rights.
            if (!$l_wildcard && isset($this->m_paths['location']))
            {
                if (isset($this->m_paths['location'][isys_auth::WILDCHAR]))
                {
                    $l_wildcard = true;
                    $l_return   = true;
                }
                else
                {
                    if (!isset($this->m_paths['location'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        // The given ID could not be found directly, now we check the location path.

                        /** @var isys_cmdb_dao_location $l_dao_location */
                        $l_dao_location = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao_location',
                                                                              $g_comp_database);

                        foreach ($this->m_paths['location'] as $l_location_id => $l_rights)
                        {
                            // Get child locations of the location auth-paths.
                            $l_child_locations       = array_keys($l_dao_location->get_child_locations_recursive($l_location_id));
                            $l_objtype_id            = $l_dao->get_objTypeID($l_location_id);
                            $l_return[$l_objtype_id] = $l_objtype_id;
                            foreach ($l_child_locations AS $l_obj_id)
                            {
                                $l_objtype_id = $l_dao->get_objTypeID($l_obj_id);
                                if (!isset($l_return[$l_objtype_id]))
                                {
                                    $l_return[$l_objtype_id] = $l_objtype_id;
                                } // if
                            } // foreach
                        } // foreach
                    } // if
                } // if
            } // if

            if (!$l_wildcard)
            {
                $l_return = (count($l_return) > 0) ? $l_return : false;
            } // if

            $l_cache_obj->set('allowed_objecttypes', $l_return)->save();
        }
        else
        {
            $l_return = $l_cache;
        } // if

        return $l_return;
    } // function


    /**
     * Checks if object type is allowed.
     *
     * @param   mixed $p_obj_type
     *
     * @return  boolean
     * @throws  isys_exception_general
     * @author  Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function is_allowed_in_objecttype($p_obj_type)
    {
        if (!is_numeric($p_obj_type))
        {
            if (defined($p_obj_type))
            {
                $p_obj_type = constant($p_obj_type);
            }
            else
            {
                throw new isys_exception_general('Object type constant does not exists.');
            } // if
        } // if

        $l_objtypes = $this->get_allowed_objecttypes();

        if (is_array($l_objtypes))
        {
            if (count($l_objtypes) > 0)
            {
                return isset($l_objtypes[$p_obj_type]);
            }
            else
            {
                // WILDCARD
                return true;
            } // if
        }
        else
        {
            if ($l_objtypes === true)
            {
                return true;
            } // if
        } // if

        return false;
    } // function


    /**
     * This method checks the rights for categories and checks the rights from the object. Without exception.
     *
     * @param        $p_right
     * @param        $p_object_id
     * @param        $p_category_const
     *
     * @return        bool
     * @author        Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function has_rights_in_obj_and_category($p_right, $p_object_id,
                                                   $p_category_const) // If errors occur, change back to "$p_category_const = null".
    {
        try
        {
            return $this->check_rights_obj_and_category($p_right, $p_object_id, $p_category_const);
        }
        catch (isys_exception_auth $e)
        {
            return false;
        } // try
    } // function


    /**
     * Gets all allowed objects ordered by object types which will be cached in the auth cache file.
     *
     * @return  mixed
     * @author  Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function get_allowed_objects()
    {
        global $g_comp_database, $g_comp_session;

        $l_return   = $l_object_types = array();
        $l_wildcard = false;

        $l_cache_obj = isys_caching::factory('auth-' . $g_comp_session->get_user_id());
        $l_cache     = $l_cache_obj->get('allowed_objects');

        if ($l_cache === false || (is_array($l_cache) && count($l_cache) == 0))
        {
            /** @var isys_cmdb_dao $l_dao */
            $l_dao = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', $g_comp_database);

            // Get object types from object in type rights
            if (isset($this->m_paths['obj_in_type']))
            {
                if (isset($this->m_paths['obj_in_type'][isys_auth::WILDCHAR]))
                {
                    $l_wildcard = true;
                    $l_return   = true;
                }
                else
                {
                    if (!isset($this->m_paths['obj_in_type'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        foreach ($this->m_paths['obj_in_type'] AS $l_key => $l_rights)
                        {
                            $l_key = strtoupper($l_key);
                            if (defined($l_key))
                            {
                                $l_key_constant                  = constant($l_key);
                                $l_object_types[$l_key_constant] = $l_key_constant;
                            } // if
                        } // foreach
                    } // if
                } // if
            } // if

            // Get object types from object id rights
            if (!$l_wildcard && isset($this->m_paths['obj_id']))
            {
                if (isset($this->m_paths['obj_id'][isys_auth::WILDCHAR]))
                {
                    $l_wildcard = true;
                    $l_return   = true;
                }
                else
                {
                    if (!isset($this->m_paths['obj_id'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        foreach ($this->m_paths['obj_id'] AS $l_key => $l_rights)
                        {
                            $l_type_id                    = $l_dao->get_objTypeID($l_key);
                            $l_return[$l_type_id][$l_key] = $l_key;
                        } // foreach
                    } // if
                } // if
            } // if

            // Get object types from location rights
            if (!$l_wildcard && isset($this->m_paths['location']))
            {
                if (isset($this->m_paths['location'][isys_auth::WILDCHAR]))
                {
                    $l_wildcard = true;
                    $l_return   = true;
                }
                else
                {
                    if (!isset($this->m_paths['location'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        // The given ID could not be found directly, now we check the location path.

                        /** @var isys_cmdb_dao_location $l_dao_location */
                        $l_dao_location = isys_factory_cmdb_dao::get_instance('isys_cmdb_dao_location',
                                                                              $g_comp_database);

                        foreach ($this->m_paths['location'] as $l_location_id => $l_rights)
                        {
                            // Get child locations of the location auth-paths.
                            $l_child_locations = array_keys($l_dao_location->get_child_locations_recursive($l_location_id));
                            foreach ($l_child_locations AS $l_obj_id)
                            {
                                $l_objtype_id = $l_dao_location->get_objTypeID($l_obj_id);
                                if (!isset($l_object_types[$l_objtype_id]))
                                {
                                    $l_return[$l_objtype_id][$l_obj_id] = $l_obj_id;
                                } // if
                            } // foreach
                        } // foreach
                    } // if
                } // if
            } // if

            if (count($l_object_types) > 0 && !$l_wildcard)
            {
                $l_res = $l_dao->get_objects_by_type(array_keys($l_object_types));

                // $l_return needs to be an array here!
                $l_return = (is_array($l_return)) ? $l_return : array();

                while ($l_row = $l_res->get_row())
                {
                    $l_return[$l_row['isys_obj__isys_obj_type__id']][$l_row['isys_obj__id']] = $l_row['isys_obj__id'];
                } // while
            } // if

            if (!$l_wildcard)
            {
                $l_return = (count($l_return) > 0) ? $l_return : false;
            } // if

            $l_cache_obj->set('allowed_objects', $l_return)->save();
        }
        else
        {
            $l_return = $l_cache;
        } // if

        return $l_return;
    } // function


    /**
     * Gets all or by object type allowed objects.
     *
     * @param   integer $p_type_id
     *
     * @return  mixed
     * @author  Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function get_allowed_objects_by_type($p_type_id = NULL)
    {
        $l_allowed_objects = $this->get_allowed_objects();

        if (is_array($l_allowed_objects))
        {
            if (!empty($p_type_id))
            {
                if (isset($l_allowed_objects[$p_type_id]))
                {
                    return array_keys($l_allowed_objects[$p_type_id]);
                } // if
            }
            else
            {
                if (count($l_allowed_objects) > 0)
                {
                    $l_return = array();
                    foreach ($l_allowed_objects as $l_obj_content)
                    {
                        $l_return = array_merge($l_return, array_keys($l_obj_content));
                    } // foreach

                    return $l_return;
                }
                else
                {
                    // In case of wildcard.
                    return true;
                } // if
            } // if
        }
        else
        {
            if ($l_allowed_objects === true)
            {
                return true;
            } // if
        } // if

        return false;
    } // function


    /**
     * Gets all allowed categories.
     *
     * @return  mixed  Normally you'll get an array of allowed categories. If ALL categories are allowed, you'll simply
     *                 receive boolean TRUE.
     * @author  Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function get_allowed_categories()
    {
        global $g_comp_session;
        $l_return = array('C__CATG__GLOBAL');

        $l_cache_obj = isys_caching::factory('auth-' . $g_comp_session->get_user_id());
        $l_cache     = $l_cache_obj->get('allowed_categories');

        if ($l_cache === false || (is_array($l_cache) && count($l_cache) == 0))
        {
            if (isset($this->m_paths['category']) && is_array($this->m_paths['category']))
            {
                if (isset($this->m_paths['category'][isys_auth::WILDCHAR]))
                {
                    $l_return = true;
                }
                else
                {
                    if (!isset($this->m_paths['category'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        foreach (array_keys($this->m_paths['category']) as $l_cat_const)
                        {
                            $l_return[] = strtoupper($l_cat_const);
                        } // foreach

                        $l_cache_obj->set('allowed_categories', $l_return)->save();
                    } // if
                } // if
            } // if

            if ($l_return !== true && count($this->m_paths['category_in_obj_type']) > 0)
            {
                $l_categories = array_keys($this->m_paths['category_in_obj_type']);

                foreach ($l_categories as $l_category)
                {
                    $l_return[] = strtoupper(strstr($l_category, '+', true));
                } // foreach
            } // if

            if ($l_return !== true && count($this->m_categories_in_objects) > 0)
            {
                if (isset($this->m_categories_in_objects[isys_auth::WILDCHAR]))
                {
                    $l_return = true;
                }
                else
                {
                    $l_return = array_merge($l_return, array_keys($this->m_categories_in_objects));
                } // if
            } // if

            if ($l_return !== true && count($this->m_categories_in_locations) > 0)
            {
                if (isset($this->m_categories_in_locations[isys_auth::WILDCHAR]))
                {
                    $l_return = true;
                }
                else
                {
                    $l_return = array_merge($l_return, array_keys($this->m_categories_in_locations));
                } // if
            } // if
        }
        else
        {
            $l_return = $l_cache;
        } // if

        return $l_return;
    } // function


    /**
     * This method gets all allowed object type groups
     *
     * @global isys_component_database $g_comp_database
     * @return array|bool|mixed
     * @author Van Quyen Hoang <qhoang@i-doit.com>
     */
    public function get_allowed_objtype_groups()
    {
        /** @var isys_component_database $g_comp_database */
        global $g_comp_session, $g_comp_database;

        $l_cache_obj = isys_caching::factory('auth-' . $g_comp_session->get_user_id());
        $l_cache     = $l_cache_obj->get('allowed_objtype_groups');

        $l_return = false;

        if ($l_cache === false || (is_array($l_cache) && count($l_cache) == 0))
        {
            $l_allowed_objtypes = $this->get_allowed_objecttypes();
            $l_sql              = 'SELECT DISTINCT(isys_obj_type_group__const) FROM isys_obj_type_group ' .
                'INNER JOIN isys_obj_type ON isys_obj_type__isys_obj_type_group__id = isys_obj_type_group__id ';

            if (is_array($l_allowed_objtypes) && count($l_allowed_objtypes) > 0)
            {
                $l_sql .= 'WHERE isys_obj_type__id IN (' . implode(',', $l_allowed_objtypes) . ')';
            } // if

            $l_res = $g_comp_database->query($l_sql);

            if (count($g_comp_database->num_rows($l_res)) > 0)
            {
                while ($l_row = $g_comp_database->fetch_array($l_res))
                {
                    $l_return[] = $l_row['isys_obj_type_group__const'];
                } // while
            } // if
            $l_cache_obj->set('allowed_objtype_groups', $l_return)->save();
        }
        else
        {
            $l_return = $l_cache;
        } // if
        return $l_return;
    } // function


    /**
     * Gets all object types for object type configuration list
     *
     * @return array|bool|mixed
     * @author Van Quyen Hoang <qhoang@i-doit.con>
     */
    public function get_allowed_objecttype_configs()
    {
        global $g_comp_session;

        $l_cache_obj = isys_caching::factory('auth-' . $g_comp_session->get_user_id());
        $l_cache     = $l_cache_obj->get('allowed_objtype_configs');

        $l_return = false;

        if ($l_cache === false || (is_array($l_cache) && count($l_cache) == 0))
        {

            $l_wildcard = false;
            // Get object types from object in type rights
            if (isset($this->m_paths['obj_type']))
            {
                if (isset($this->m_paths['obj_type'][isys_auth::WILDCHAR]))
                {
                    $l_wildcard = true;
                    $l_return   = true;
                }
                else
                {
                    if (!isset($this->m_paths['obj_type'][isys_auth::EMPTY_ID_PARAM]))
                    {
                        $l_return = array();
                        foreach ($this->m_paths['obj_type'] AS $l_key => $l_rights)
                        {
                            $l_key = strtoupper($l_key);
                            if (defined($l_key))
                            {
                                $l_key_constant            = constant($l_key);
                                $l_return[$l_key_constant] = $l_key_constant;
                            } // if
                        } // foreach
                    } // if
                } // if
            } // if

            if (!$l_wildcard)
            {
                $l_return = (count($l_return) > 0) ? $l_return : false;
            } // if

            $l_cache_obj->set('allowed_objtype_configs', $l_return)->save();
        }
        else
        {
            $l_return = $l_cache;
        } // if
        return $l_return;
    } // function


    /**
     * Gets all object type groups for the object type configuration
     *
     * @return  mixed
     * @author  Van Quyen Hoang <qhoang@i-doit.con>
     */
    public function get_allowed_objecttype_group_configs()
    {
        global $g_comp_database;

        $l_objecttypes = $this->get_allowed_objecttype_configs();

        if (is_array($l_objecttypes))
        {
            return isys_factory_cmdb_dao::get_instance('isys_cmdb_dao', $g_comp_database)
                                        ->get_objtype_group_const_by_type_id($l_objecttypes);
        }
        else
        {
            if (is_bool($l_objecttypes))
            {
                return $l_objecttypes;
            } // if
        } // if

        return false;
    } // function
} // class