<?php

/**
 * i-doit
 *
 * Auth: abstract class for module authorization.
 *
 * @package     i-doit
 * @subpackage  auth
 * @author      Leonard Fischer <lfischer@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
abstract class isys_auth
{
	/**
	 * The almighty wildchar.
	 * @var  string
	 */
	const WILDCHAR = '*';

	/**
	 * This constant will be used for paths like "CMDB/OBJ_TYPE" (without ID).
	 * @var  string
	 */
	const EMPTY_ID_PARAM = 'empty-id';

	/**
	 * Holds the value for viewing-right.
	 * @var  integer
	 */
	const VIEW = 1;

	/**
	 * Holds the value for edit-right (includes "view").
	 * @var  integer
	 */
	const EDIT = 2;

	/**
	 * Holds the value for delete-right (includes "view").
	 * @var  integer
	 */
	const DELETE = 4;

	/**
	 * Holds the value for execute-right (includes "view").
	 * @var  integer
	 */
	const EXECUTE = 8;

	/**
	 * Holds the value for edit-right (includes "view", "edit", "delete" and every right to come...).
	 * @var  integer
	 */
	const SUPERVISOR = 2048;

	/**
	 * Static instance cache.
	 * @var  array
	 */
	private static $m_instances = array();

	/**
	 * Holds all module path-instances in an array.
	 * @var  array
	 */
	protected $m_paths = array();

	/**
	 * Holds an instance of "isys_auth_dao" for all database queries.
	 * @var  isys_auth_dao
	 */
	protected static $m_dao = null;

    /**
	 * Contains the module row.
	 * @var  array
	 */
	protected $m_module_row = array();

	/**
	 * Method for returning the available auth-methods. This will be used for the GUI.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	abstract public function get_auth_methods();


	/**
	 * Generic "check()" method, may be overwritten by "isys_auth_module_*" classes.
	 *
	 * @param   integer  $p_right
	 * @param   string   $p_path
	 * @return  boolean
	 * @throws  isys_exception_auth
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function check ($p_right, $p_path)
	{
		list($l_method, $l_id) = explode('/', strtolower($p_path));

		if (! method_exists($this, $l_method))
		{
			throw new isys_exception_auth(_L('LC__AUTH__EXCEPTION__MISSING_METHOD', array($l_method, _L($this->m_module_row['isys_module__title']))));
		} // if

		return call_user_func(array($this, $l_method), $p_right, $l_id);
	} // function


	/**
	 * This method will process the exact same code as "check()" but will return a boolean value without any exceptions.
	 *
	 * @param   integer  $p_right
	 * @param   string   $p_path
	 * @return  boolean
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function is_allowed_to ($p_right, $p_path)
	{
		try
		{
			return $this->check($p_right, $p_path);
		}
		catch (Exception $e)
		{
			return false;
		} // try
	} // function


	/**
	 * Factory method, for resource gentle class instantiation.
	 *
	 * @global  isys_component_database
	 * @param   mixed  $p_module
	 * @return  isys_auth
	 * @throws  isys_exception_general
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public static function factory ($p_module)
	{
		global $g_config;

		if (! $g_config['use_auth'])
		{
			return new isys_auth_module_dummy;
		} // if

		if (!is_numeric($p_module))
		{
			if (!defined($p_module))
			{
				throw new isys_exception_general(_L('LC__EXCEPTION__CONSTANT_COULD_NOT_BE_FOUND', $p_module));
			} // if

			$p_module = constant($p_module);
		} // if

		// Check for existing instance.
		if (isset(self::$m_instances[$p_module]))
		{
			return self::$m_instances[$p_module];
		}
		else
		{
			// If the DAO has not been loaded yet, we initialize it now.
			if (self::$m_dao === null)
			{
				global $g_comp_database;

				self::$m_dao = new isys_auth_dao($g_comp_database);
			} // if

			// No instance was found, we need to create one.
			$l_module_row = isys_module_manager::instance()->get_modules($p_module)->get_row();

			$l_module_auth = @constant($l_module_row['isys_module__class'] . '::AUTH_CLASS_NAME');

			if ($l_module_auth !== false && class_exists($l_module_auth))
			{
				return self::$m_instances[$p_module] = new $l_module_auth($l_module_row);
			}
			else
			{
				return new isys_auth_module_dummy;
			} // if
		} // if
	} // function


	/**
	 * Method for preparing the single "path" objects
	 *
	 * @param   integer  $p_person_id
	 * @param   integer  $p_module_id
	 * @return  isys_auth
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	protected function load_auth_paths ($p_person_id = null, $p_module_id = null)
	{
		// If "$p_person_id" equals "null", we load the currently logged in user via session.
		if ($p_person_id === null)
		{
			global $g_comp_session;

			$p_person_id = $g_comp_session->get_user_id();
		} // if

		// If "$p_module_id" equals "null", we use the current module.
		if ($p_module_id === null)
		{
			$p_module_id = $this->m_module_row['isys_module__id'];
		} // if

		$l_cache = isys_caching::factory('auth-' . $p_person_id)->get($p_module_id);

		if ($l_cache === false)
		{
			$l_person_paths = self::$m_dao->get_paths($p_person_id, $p_module_id);
			$l_group_paths = self::$m_dao->get_group_paths_by_person($p_person_id, $p_module_id);

			if ($l_group_paths !== false && count($l_group_paths) > 0)
			{
				$this->m_paths = self::$m_dao->build_paths_by_result($l_group_paths);
			} // if

			if ($l_person_paths !== false && count($l_person_paths) > 0)
			{
				$l_paths_person = self::$m_dao->build_paths_by_result($l_person_paths);

				if (count($l_paths_person) > 0)
				{
					// We tried to merge the two arrays, but that didn't work out - So we need a foreach.
					foreach ($l_paths_person as $l_method => $l_params)
					{
						if (! isset($this->m_paths[$l_method]))
						{
							$this->m_paths[$l_method] = array();
						} // if

						foreach ($l_params as $l_param => $l_rights)
						{
							if (! isset($this->m_paths[$l_method][$l_param]))
							{
								$this->m_paths[$l_method][$l_param] = array();
							} // if

							// Even at this level the merging does not work properly...
							foreach ($l_rights as $l_right)
							{
								if (! in_array($l_right, $this->m_paths[$l_method][$l_param]))
								{
									$this->m_paths[$l_method][$l_param][] = $l_right;
								} // if
							} // foreach
						} // foreach
					} // foreach
				} // if
			} // if

			isys_caching::factory('auth-' . $p_person_id)->set($p_module_id, $this->m_paths)->save();
		}
		else
		{
			$this->m_paths = $l_cache;
		} // if

		return $this;
	} // function


	/**
	 * Simply returns the module data from "isys_module".
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public function get_module_data()
	{
		return $this->m_module_row;
	} // function


	/**
	 * Method for retrieving the "human-readable" right name.
	 *
	 * @param   integer  $p_right
	 * @return  string
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public static function get_right_name ($p_right = null)
	{
		$l_rights = array(
			self::VIEW => _L('LC__AUTH__RIGHT_VIEW'),
			self::EDIT => _L('LC__AUTH__RIGHT_EDIT'),
			self::DELETE => _L('LC__AUTH__RIGHT_DELETE'),
			self::EXECUTE => _L('LC__AUTH__RIGHT_EXECUTE'),
			self::SUPERVISOR => _L('LC__AUTH__RIGHT_SUPERVISOR')
		);

		if ($p_right !== null)
		{
			return $l_rights[$p_right];
		} // if

		return $l_rights;
	} // function


	/**
	 * Method for retrieving the "rights" including some additional data.
	 *
	 * @return  array
	 * @author  Leonard Fischer <lfischer@i-doit.com>
	 */
	public static function get_rights ()
	{
		return array(
			self::VIEW => array(
				'title' => _L('LC__AUTH__RIGHT_VIEW'),
				'icon' => 'icons/eye.png'),
			self::EDIT => array(
				'title' => _L('LC__AUTH__RIGHT_EDIT'),
				'icon' => 'icons/silk/page_white_edit.png'),
			self::DELETE => array(
				'title' => _L('LC__AUTH__RIGHT_DELETE'),
				'icon' => 'icons/silk/page_white_delete.png'),
			self::EXECUTE => array(
				'title' => _L('LC__AUTH__RIGHT_EXECUTE'),
				'icon' => 'icons/silk/page_white_gear.png'),
			self::SUPERVISOR => array(
				'title' => _L('LC__AUTH__RIGHT_SUPERVISOR'),
				'icon' => 'icons/silk/user_gray.png')
		);
	} // function


	/**
	 * Generic boolean checker. We can use this for yes/no rights.
	 *
	 * @see     You can find a isys_auth_module_report->editor(); or isys_auth_module_auth->overview();
	 * @param   mixed                $p_key
	 * @param   isys_exception_auth  $p_exception
	 * @param   integer              $p_right
	 * @throws  isys_exception_auth
	 * @return  boolean
	 * @author  Selcuk Kekec <skekec@i-doit.com>
	 */
	protected function generic_boolean ($p_key, isys_exception_auth $p_exception, $p_right = null)
	{
		if (is_array($this->m_paths[$p_key]))
		{
			if (!empty($p_right))
			{
				if(in_array($p_right, $this->m_paths[$p_key][self::EMPTY_ID_PARAM]))
				{
					return true;
				}
			}
			else
			{
				return true;
			}
		} // if

		throw $p_exception;
	} // function


	/**
	 * Generic right checker.
	 *
	 * @param   integer              $p_right      Right to check.
	 * @param   string               $p_method     Usally the method name.
	 * @param   mixed                $p_param      Identifier (CONSTANT|ID|ETC).
	 * @param   isys_exception_auth  $p_exception  The exception which shall be thrown.
	 * @return  boolean
	 * @throws  isys_exception_auth
	 * @author  Selcuk Kekec <skekec@i-doit.com>
	 */
	protected function generic_right ($p_right, $p_method, $p_param, isys_exception_auth $p_exception)
	{
		if (is_array($this->m_paths[$p_method]))
		{
			// Check for wildchars.
			if (isset($this->m_paths[$p_method][self::WILDCHAR]) && in_array($p_right, $this->m_paths[$p_method][self::WILDCHAR]))
			{
				return true;
			} // if

			if (isset($this->m_paths[$p_method][$p_param]) && in_array($p_right, $this->m_paths[$p_method][$p_param]))
			{
				return true;
			} // if
		} // if

		throw $p_exception;
	} // function


    /**
     * Check, if user has a baseright.
     *
     * @param   string  $p_master_right
     * @return  boolean
     * @author  Selcuk Kekec <skekec@i-doit.com>
     */
	public function has ($p_master_right)
	{
		return (is_array($this->m_paths) && isset($this->m_paths[$p_master_right]) && is_array($this->m_paths[$p_master_right]));
	} // function


	/**
	 * Checks if there exists any path for the current module.
	 *
	 * @return  boolean
	 * @authro  Van Quyen Hoang <qhoang@i-doit.com>
	 */
	public function has_any_rights_in_module()
	{
		return (count($this->m_paths) > 0);
	} // function


	/**
	 * Checks if any rights for the specified path exist.
	 *
	 * @param	integer              $p_right
	 * @param	string               $p_method
	 * @param	string               $p_param
	 * @param	isys_exception_auth  $p_exception
	 * @return 	boolean
	 * @author	Van Quyen Hoang <qhoang@i-doit.com>
	 */
	protected function check_module_rights($p_right, $p_method, $p_param, isys_exception_auth $p_exception)
	{
		if (is_array($this->m_paths[$p_method]) && empty($p_param))
		{
			return true;
		}
		else
		{
			return $this->generic_right($p_right, $p_method, $p_param, $p_exception);
		} // if
	} // function


	/**
	 * Constructor, will load all necessary paths.
	 *
	 * @param   array  $p_module_row
	 * @author  Leonard Fischer <lficsher@i-doit.com>
	 * @author  Selcuk Kekec <skekec@i-doit.com>
	 */
	protected function __construct (array $p_module_row)
	{
		$this->m_module_row = $p_module_row;

		// Load the CMDB specific paths.
		$this->load_auth_paths();
	} // function
} // class