<?php
/**
 * i-doit
 *
 * Index / Front Controller
 *
 * @package     i-doit
 * @subpackage  General
 * @version     1.0.1
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 *
 * - http://i-doit.org
 * - http://doc.i-doit.org
 * - http://i-doit.org/forum
 */
/**
 * index.php/Front controller - program sequence:
 * ---------------------------------------------------------------------------
 * 1. Determine current directory (for absolute path references)
 * 2. Load Configuration
 * (3. Check directories (we have to make this UNIX-compatible at first))
 * 4. Load globals and surrounding function libraries
 * 5. If external request is wanted, do it.
 * 6. If i-doit internal request, forward to hypergate.inc.php
 * ---------------------------------------------------------------------------
 */
// Set the current start time for detecting the php processing time.
$g_start_time = microtime(true);

// Determine our directory.
$g_absdir = dirname(__FILE__);

function gettime()
{
	global $g_start_time;
	return (microtime(true)-$g_start_time);
} // function

// Set error reporting.
$l_errorReporting = E_ALL & ~E_NOTICE;
if (defined('E_DEPRECATED')) $l_errorReporting &= ~E_DEPRECATED;
if (defined('E_STRICT')) $l_errorReporting &= ~E_STRICT;
error_reporting($l_errorReporting);

/* Set default charset to utf-8 */
ini_set('default_charset', 'utf-8');

// Set maximal execution time.
if (ini_get("max_execution_time") < 600)
{
	set_time_limit(600);
} // if

/**
 * Dies with a preformatted monospace message.
 *
 * @param string $p_message
 */
function startup_die($p_message)
{
	echo "<pre>" . $p_message . "</pre>\n";
	die();
} // function

if ((int) ini_get("memory_limit") < 128)
{
	ini_set("memory_limit", "128M");
} // if

if ((int) ini_get("upload_max_filesize") < 8)
{
	ini_set("upload_max_filesize", "8M");
} // if

// Check configuration parameters of php.ini

// Allow FOPEN Wrapper for URLs.
ini_set("allow_url_fopen", "1");

try
{
	// Initialize framework.
	if (file_exists("src/config.inc.php") && include_once("src/config.inc.php"))
	{
        // Include globals.
        if (!include_once "src/globals.inc.php")
        {
            startup_die("Could not find globals.inc.php");
        } // if

        // Include caching implementation.
        if (!include_once "src/caching.inc.php")
        {
            startup_die("Could not find caching.inc.php");
        } // if

        // Temp cleanup.
        if (isset($_GET["IDOIT_DELETE_TEMPLATES_C"]))
        {
            $g_clear_temp = true;
            $l_directory = $g_dirs["smarty"] . "templates_c/";
        }

        if (isset($_GET["IDOIT_DELETE_TEMP"]))
        {
            $g_clear_temp = true;
            $l_directory = $g_dirs["temp"];
        }
        else if (isset($_POST["IDOIT_DELETE_TEMP"]))
        {
            isys_glob_delete_recursive($g_dirs["temp"], $l_deleted, $l_undeleted);
        } // if

        if ($g_clear_temp)
        {
            echo "Deleting temporary files ...<br>\n";

            $l_deleted = 0;
            $l_undeleted = 0;
            isys_glob_delete_recursive($l_directory, $l_deleted, $l_undeleted);
            echo "Success: $l_deleted files - Failure: $l_undeleted files!<br />\n";

            unset($l_directory);

            if (isset($_GET["ajax"]))
            {
                die();
            } // if
        } // if

        // Process ajax requests.
        if (isset($_GET["ajax"]))
        {

            if ($g_comp_session->is_logged_in())
            {
                require_once("src/ajax.inc.php");
            }
            else
            {
                echo "<script type=\"text/javascript\">document.location='?logout';</script>";
                die();
            } // if
        } // if

        // Process api requests.
        if (isset($_GET['api']))
        {
            try
            {
                switch($_GET['api'])
                {
                    case 'jsonrpc':
                        include_once('src/jsonrpc.php');
                    break;
                } // switch
            }
            catch (Exception $e)
            {
                echo $e->getMessage();
            } // try

            die;
        } // if

        // Main request handler.
        switch($_GET["load"])
        {
	        case "test":
				if (isset($_GET['type']))
		        {
			        $_GET['type'] = str_replace(chr(0), '', addslashes($_GET['type']));

			        if (file_exists("src/tests/i-doit/" . strtolower($_GET['type']) . ".php"))
			        {
			            include_once("src/tests/i-doit/" . strtolower($_GET['type']) . ".php");
			        }
		        }
		        break;
	        case "api_properties":
                include_once("src/tools/php/properties.inc.php");
            break;

			case "property_infos":
				include_once("src/tools/php/property_infos.inc.php");
				break;

            case "css":
                include_once("src/tools/css/css.php");
            break;

            default:
            // The hypergate is the i-doit-internal entrypoint, in which all i-doit internal requests are running.
            include_once "src/hypergate.inc.php";
        } // switch
	}
	else
	{
		if (!require_once "setup/install.inc.php")
		{
			startup_die("Could not start installer. Setup files not found.");
		} // if
	} // if

	// Get PHP processing time.
	if (isset($g_config["show_proc_time"]))
	{
		if ($g_config["show_proc_time"] == true)
		{
			echo "\n<!-- i-doit processing time: ".gettime()." -->";
		} // if
	} // if
}
catch (Exception $e)
{
	die($e->getMessage());
} // try
